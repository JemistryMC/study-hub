import React from 'react';
import { useApp } from '../../context/AppContext';
import { PomodoroTimer } from './PomodoroTimer';
import { WeeklyEvaluations } from './WeeklyEvaluations';
import { BarChart3, Plus, Clock, Star, Trash2, Calendar, FileText, Flame } from 'lucide-react';

export const TrackerView: React.FC = () => {
  const { studyLogs, setLogSessionModalOpen, deleteStudyLog, language, t } = useApp();

  return (
    <div className="space-y-6 pb-20 md:pb-12 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-[#10192d] to-slate-900 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-5 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-teal-500/10 text-teal-300 border border-teal-500/30 flex items-center gap-1.5">
                <BarChart3 className="w-3.5 h-3.5 text-teal-400" />
                <span>{t('trackerTitle')}</span>
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white mb-2">
              {t('trackerTitle')}
            </h1>
            <p className="text-sm text-slate-400 max-w-xl leading-relaxed">
              {t('trackerSubtitle')}
            </p>
          </div>

          <button
            onClick={() => setLogSessionModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-400 hover:to-teal-500 text-slate-950 font-bold text-sm shadow-lg shadow-teal-500/25 transition-all transform hover:-translate-y-0.5"
          >
            <Plus className="w-4 h-4" />
            <span>{t('logStudySession')}</span>
          </button>
        </div>
      </div>

      {/* Grid: Pomodoro Timer & Weekly Intelligence */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5">
          <PomodoroTimer />
        </div>
        <div className="lg:col-span-7">
          <WeeklyEvaluations />
        </div>
      </div>

      {/* Study Logs History Table */}
      <div className="bg-[#101726] border border-slate-800 rounded-3xl p-5 sm:p-7 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-teal-400" />
            <h3 className="text-base font-extrabold text-white">{t('recentLogs')}</h3>
            <span className="text-xs text-slate-500">({studyLogs.length})</span>
          </div>

          <button
            onClick={() => setLogSessionModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-500/10 text-teal-300 hover:bg-teal-500/20 border border-teal-500/30 text-xs font-bold transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{t('logStudySession')}</span>
          </button>
        </div>

        {studyLogs.length === 0 ? (
          <div className="text-center py-12 text-slate-500 text-xs italic">{t('noLogsYet')}</div>
        ) : (
          <div className="space-y-2.5">
            {studyLogs.map(log => {
              const formattedDate = new Date(log.date).toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US', {
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              });

              return (
                <div
                  key={log.id}
                  className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800/80 hover:border-slate-700 transition"
                >
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-teal-400">{log.subjectName}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-md bg-slate-800 text-slate-400 uppercase font-bold">
                        {log.type}
                      </span>
                    </div>

                    {log.lectureTitle && (
                      <h4 className="text-sm font-semibold text-white truncate">{log.lectureTitle}</h4>
                    )}

                    <div className="flex items-center gap-3 text-xs text-slate-400">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-slate-500" />
                        <span>
                          {log.durationMinutes} {t('minutes')}
                        </span>
                      </span>

                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-slate-500" />
                        <span>{formattedDate}</span>
                      </span>

                      {log.rating && (
                        <div className="flex items-center gap-0.5">
                          {[...Array(log.rating)].map((_, i) => (
                            <Star key={i} className="w-3 h-3 text-amber-400 fill-amber-400" />
                          ))}
                        </div>
                      )}
                    </div>

                    {log.notes && (
                      <p className="text-xs text-slate-400 bg-slate-950/40 p-2 rounded-xl border border-slate-800/40 mt-1 line-clamp-2">
                        {log.notes}
                      </p>
                    )}
                  </div>

                  <button
                    onClick={() => {
                      if (window.confirm(t('confirmDelete'))) {
                        deleteStudyLog(log.id);
                      }
                    }}
                    className="p-2 rounded-xl text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition self-end sm:self-center shrink-0"
                    title={t('delete')}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
