import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Play, Pause, RotateCcw, Flame, Bell, Sparkles } from 'lucide-react';

export const PomodoroTimer: React.FC = () => {
  const { addStudyLog, subjects, language, t } = useApp();

  const [mode, setMode] = useState<'focus' | 'short_break' | 'long_break'>('focus');
  const [secondsLeft, setSecondsLeft] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [selectedSubjectId, setSelectedSubjectId] = useState<number | undefined>(undefined);

  const modeDurations = {
    focus: 25 * 60,
    short_break: 5 * 60,
    long_break: 15 * 60
  };

  useEffect(() => {
    let interval: ReturnType<typeof setInterval> | undefined;
    if (isRunning) {
      interval = setInterval(() => {
        setSecondsLeft(prev => {
          if (prev <= 1) {
            setIsRunning(false);
            // If focus session completed, auto log
            if (mode === 'focus') {
              const sub = subjects.find(s => s.id === selectedSubjectId);
              addStudyLog({
                subjectId: selectedSubjectId,
                subjectName: sub ? sub.name : language === 'ar' ? 'جلسة تركيز بومودورو' : 'Pomodoro Focus Session',
                date: new Date().toISOString(),
                durationMinutes: 25,
                type: 'pomodoro',
                rating: 5,
                notes: 'جلسة تركيز كاملة عبر مؤقت بومودورو الذكي'
              });
            }
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning, mode, selectedSubjectId, subjects]);

  const switchMode = (newMode: 'focus' | 'short_break' | 'long_break') => {
    setIsRunning(false);
    setMode(newMode);
    setSecondsLeft(modeDurations[newMode]);
  };

  const resetTimer = () => {
    setIsRunning(false);
    setSecondsLeft(modeDurations[mode]);
  };

  const minutes = Math.floor(secondsLeft / 60);
  const seconds = secondsLeft % 60;
  const progressPct = ((modeDurations[mode] - secondsLeft) / modeDurations[mode]) * 100;

  return (
    <div className="bg-gradient-to-b from-[#10192e] to-[#0c1322] border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-2xl flex flex-col items-center text-center relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Mode Switcher Tabs */}
      <div className="flex items-center gap-1.5 bg-slate-900/90 p-1 rounded-2xl border border-slate-800 mb-6">
        <button
          onClick={() => switchMode('focus')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
            mode === 'focus' ? 'bg-teal-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          {t('focusSession')}
        </button>

        <button
          onClick={() => switchMode('short_break')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
            mode === 'short_break' ? 'bg-sky-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          {t('shortBreak')}
        </button>

        <button
          onClick={() => switchMode('long_break')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
            mode === 'long_break' ? 'bg-indigo-500 text-white shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          {t('longBreak')}
        </button>
      </div>

      {/* Circular Progress & Digital Display */}
      <div className="relative w-48 h-48 sm:w-56 sm:h-56 flex items-center justify-center my-2">
        <svg className="w-full h-full -rotate-90">
          <circle cx="50%" cy="50%" r="42%" className="stroke-slate-800 fill-none stroke-[8px]" />
          <circle
            cx="50%"
            cy="50%"
            r="42%"
            className="stroke-teal-400 fill-none stroke-[8px] transition-all duration-1000 ease-linear stroke-linecap-round"
            strokeDasharray="264%"
            strokeDashoffset={`${264 - (264 * progressPct) / 100}%`}
          />
        </svg>

        <div className="absolute flex flex-col items-center">
          <span className="text-4xl sm:text-5xl font-black font-mono tracking-tighter text-white">
            {minutes < 10 ? `0${minutes}` : minutes}:{seconds < 10 ? `0${seconds}` : seconds}
          </span>
          <span className="text-xs font-bold text-teal-400 mt-1 flex items-center gap-1">
            <Flame className="w-3.5 h-3.5 text-amber-400" />
            <span>{mode === 'focus' ? (language === 'ar' ? 'تركيز عميق' : 'Deep Focus') : (language === 'ar' ? 'استراحة' : 'Break')}</span>
          </span>
        </div>
      </div>

      {/* Target Subject Selector */}
      {mode === 'focus' && (
        <div className="w-full max-w-xs mt-3 mb-5">
          <select
            value={selectedSubjectId || ''}
            onChange={e => setSelectedSubjectId(e.target.value ? Number(e.target.value) : undefined)}
            className="w-full bg-slate-900 border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none"
          >
            <option value="">{language === 'ar' ? 'ربط المذاكرة بمادة دراسية...' : 'Link to a course...'}</option>
            {subjects.map(s => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </div>
      )}

      {/* Controls */}
      <div className="flex items-center gap-4 mt-2">
        <button
          onClick={resetTimer}
          className="p-3 rounded-2xl bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition"
          title={t('resetTimer')}
        >
          <RotateCcw className="w-5 h-5" />
        </button>

        <button
          onClick={() => setIsRunning(!isRunning)}
          className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-400 hover:to-teal-500 text-slate-950 font-black text-sm shadow-xl shadow-teal-500/25 flex items-center gap-2 transition-transform transform active:scale-95"
        >
          {isRunning ? (
            <>
              <Pause className="w-5 h-5" />
              <span>{t('pauseTimer')}</span>
            </>
          ) : (
            <>
              <Play className="w-5 h-5 translate-x-0.5" />
              <span>{t('startTimer')}</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
