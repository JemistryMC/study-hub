import React from 'react';
import { useApp } from '../../context/AppContext';
import { Award, TrendingUp, AlertCircle, Sparkles, CheckCircle2 } from 'lucide-react';

export const WeeklyEvaluations: React.FC = () => {
  const { studyLogs, scheduleEvents, language, t } = useApp();

  const totalStudyMinutes = studyLogs.reduce((acc, l) => acc + (l.durationMinutes || 0), 0);
  const totalStudyHours = (totalStudyMinutes / 60).toFixed(1);

  // Review sessions count
  const reviewLogs = studyLogs.filter(l => l.notes?.includes('مراجعة') || l.type === 'pomodoro');
  const reviewMinutes = reviewLogs.reduce((acc, l) => acc + (l.durationMinutes || 0), 0);
  const reviewRatio = totalStudyMinutes > 0 ? Math.round((reviewMinutes / totalStudyMinutes) * 100) : 0;

  // Grade calculation
  let grade = 'A';
  let adviceArabic = 'أداء ممتاز والتزام متوازن بين المذاكرة الذاتية والمراجعة التكرارية.';
  let adviceEnglish = 'Excellent performance with a balanced ratio of self-study and spaced review.';

  if (Number(totalStudyHours) < 3) {
    grade = 'C';
    adviceArabic = 'ساعات المذاكرة منخفضة هذا الأسبوع، يُنصح بتخصيص فترات تركيز بومودورو إضافية.';
    adviceEnglish = 'Study hours are lower than expected, try adding focused pomodoro slots.';
  } else if (reviewRatio < 20) {
    grade = 'B+';
    adviceArabic = 'الإنتاجية جيدة ولكن نسبة المراجعة الذكية منخفضة، خصص وقتاً لمراجعة المحاضرات السابقة.';
    adviceEnglish = 'Good study volume, but review ratio is low. Schedule quick review sessions.';
  } else if (Number(totalStudyHours) >= 8 && reviewRatio >= 25) {
    grade = 'A+';
    adviceArabic = 'استثنائي! أنت في أعلى مستويات التركيز والجاهزية للامتحانات.';
    adviceEnglish = 'Exceptional! You are at peak focus and optimal exam readiness.';
  }

  return (
    <div className="bg-[#101726] border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-xl space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
        <div>
          <h3 className="text-base sm:text-lg font-extrabold text-white flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400" />
            <span>{language === 'ar' ? 'مركز التقييم الأسبوعي والذكاء الدراسي' : 'Weekly Evaluation & Study Intelligence'}</span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            {language === 'ar' ? 'تحليل ذكي لنمط المذاكرة ونسبة الاستيعاب والالتزام' : 'Performance assessment and learning curve insights'}
          </p>
        </div>

        <div className="flex items-center gap-3 bg-slate-900/80 px-4 py-2 rounded-2xl border border-slate-800 self-start sm:self-auto">
          <span className="text-xs text-slate-400 font-semibold">{language === 'ar' ? 'التقييم العام:' : 'Overall Grade:'}</span>
          <span className="text-2xl font-black bg-gradient-to-r from-amber-400 to-teal-400 bg-clip-text text-transparent">
            {grade}
          </span>
        </div>
      </div>

      {/* Highlights Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-slate-900/60 p-3.5 rounded-2xl border border-slate-800/60">
          <span className="text-[11px] text-slate-400 block mb-1">{t('totalStudyTime')}</span>
          <span className="text-lg font-extrabold text-teal-400">
            {totalStudyHours} {t('hours')}
          </span>
        </div>

        <div className="bg-slate-900/60 p-3.5 rounded-2xl border border-slate-800/60">
          <span className="text-[11px] text-slate-400 block mb-1">{t('smartReviewRatio')}</span>
          <span className="text-lg font-extrabold text-indigo-400">{reviewRatio}%</span>
        </div>

        <div className="bg-slate-900/60 p-3.5 rounded-2xl border border-slate-800/60">
          <span className="text-[11px] text-slate-400 block mb-1">{language === 'ar' ? 'إجمالي الجلسات' : 'Total Sessions'}</span>
          <span className="text-lg font-extrabold text-slate-200">{studyLogs.length}</span>
        </div>
      </div>

      {/* Advice Box */}
      <div className="bg-slate-900/90 border border-teal-500/30 rounded-2xl p-4 flex items-start gap-3">
        <Sparkles className="w-5 h-5 text-teal-400 shrink-0 mt-0.5" />
        <div>
          <h4 className="text-xs font-bold text-teal-300 mb-1">
            {language === 'ar' ? 'توصيات الذكاء الدراسي المخصصة:' : 'Personalized Study Advice:'}
          </h4>
          <p className="text-xs text-slate-300 leading-relaxed">
            {language === 'ar' ? adviceArabic : adviceEnglish}
          </p>
        </div>
      </div>
    </div>
  );
};
