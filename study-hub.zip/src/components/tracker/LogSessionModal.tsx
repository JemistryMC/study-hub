import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Clock, Star, BookOpen, FileText } from 'lucide-react';
import { LogType } from '../../types/academic';

export const LogSessionModal: React.FC = () => {
  const { logSessionModalOpen, setLogSessionModalOpen, addStudyLog, subjects, language, t } = useApp();

  const [subjectId, setSubjectId] = useState<number>(subjects[0]?.id || 101);
  const [lectureTitle, setLectureTitle] = useState('');
  const [durationMinutes, setDurationMinutes] = useState(45);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [type, setType] = useState<LogType>('manual');
  const [rating, setRating] = useState(5);
  const [notes, setNotes] = useState('');

  if (!logSessionModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const sub = subjects.find(s => s.id === subjectId);
    addStudyLog({
      subjectId,
      subjectName: sub ? sub.name : 'مذاكرة عامة',
      lectureTitle: lectureTitle.trim() || undefined,
      durationMinutes: Number(durationMinutes) || 30,
      date: new Date(date).toISOString(),
      type,
      rating,
      notes: notes.trim()
    });
    setLogSessionModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-[#0e1626] border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center border border-teal-500/20">
              <Clock className="w-4 h-4" />
            </div>
            <h3 className="text-base font-extrabold text-white">{t('logStudySession')}</h3>
          </div>

          <button
            onClick={() => setLogSessionModalOpen(false)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {language === 'ar' ? 'المادة الدراسية *' : 'Course *'}
            </label>
            <select
              value={subjectId}
              onChange={e => setSubjectId(Number(e.target.value))}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
            >
              {subjects.map(s => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {language === 'ar' ? 'عنوان المحاضرة أو الموضوع' : 'Lecture / Topic'}
            </label>
            <input
              type="text"
              placeholder={language === 'ar' ? 'مثال: Lec 2 Beta Blockers' : 'e.g. Lec 2 Beta Blockers'}
              value={lectureTitle}
              onChange={e => setLectureTitle(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {language === 'ar' ? 'المدة (بالدقائق) *' : 'Duration (Minutes) *'}
              </label>
              <input
                type="number"
                min="5"
                max="360"
                step="5"
                required
                value={durationMinutes}
                onChange={e => setDurationMinutes(parseInt(e.target.value) || 30)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {language === 'ar' ? 'تاريخ الجلسة' : 'Date'}
              </label>
              <input
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          {/* Rating */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {language === 'ar' ? 'تقييم التركيز والفهم:' : 'Focus Rating:'}
            </label>
            <div className="flex items-center gap-1.5">
              {[1, 2, 3, 4, 5].map(star => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  className="p-1 text-slate-600 hover:text-amber-400 transition"
                >
                  <Star className={`w-5 h-5 ${rating >= star ? 'text-amber-400 fill-amber-400' : ''}`} />
                </button>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {language === 'ar' ? 'ملاحظات الإنجاز' : 'Session Notes'}
            </label>
            <textarea
              rows={2}
              placeholder={language === 'ar' ? 'ما تم إنجازه في هذه الجلسة...' : 'What did you cover in this session...'}
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none"
            />
          </div>

          <div className="pt-2 border-t border-slate-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setLogSessionModalOpen(false)}
              className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-semibold"
            >
              {t('cancel')}
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold rounded-xl text-xs shadow-md"
            >
              {t('save')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
