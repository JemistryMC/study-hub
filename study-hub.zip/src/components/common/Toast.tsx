import React from 'react';
import { useApp } from '../../context/AppContext';
import { CheckCircle2, AlertCircle, Info } from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const { toasts, language } = useApp();

  if (toasts.length === 0) return null;

  return (
    <div
      className="fixed bottom-20 md:bottom-6 z-50 flex flex-col gap-2 pointer-events-none transition-all rtl:left-6 ltr:right-6 max-w-sm w-full"
      dir={language === 'ar' ? 'rtl' : 'ltr'}
    >
      {toasts.map((toast) => {
        let borderAndBg = 'bg-slate-900 border-slate-700 text-white';
        let icon = <Info className="w-4 h-4 text-blue-400 shrink-0" />;

        if (toast.type === 'success') {
          borderAndBg = 'bg-emerald-950/90 border-emerald-700/60 text-emerald-100';
          icon = <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />;
        } else if (toast.type === 'error') {
          borderAndBg = 'bg-rose-950/90 border-rose-700/60 text-rose-100';
          icon = <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />;
        }

        return (
          <div
            key={toast.id}
            className={`flex items-center gap-2.5 px-4 py-3 rounded-2xl border shadow-xl backdrop-blur-md text-xs font-semibold animate-slideUp pointer-events-auto ${borderAndBg}`}
          >
            {icon}
            <span className="flex-1 leading-snug">{toast.message}</span>
          </div>
        );
      })}
    </div>
  );
};
