import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  HelpCircle,
  BookOpen,
  Calendar,
  Clock,
  Sparkles,
  FileText,
  Keyboard,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';

export const HelpModal: React.FC = () => {
  const { isHelpModalOpen, setIsHelpModalOpen, currentLang, t } = useApp();

  if (!isHelpModalOpen) return null;

  const shortcuts = [
    { key: 'Space', descAr: 'تشغيل / إيقاف التسجيل الصوتي مؤقتاً', descEn: 'Play / Pause audio lecture' },
    { key: '← / →', descAr: 'التنقل بين صفحات الـ PDF', descEn: 'Previous / Next PDF page' },
    { key: 'Ctrl + S', descAr: 'حفظ الملاحظات التوضيحية', descEn: 'Quick save notes' },
    { key: 'Esc', descAr: 'إغلاق النوافذ المنبثقة', descEn: 'Close active modal' }
  ];

  const features = [
    {
      icon: <BookOpen className="w-5 h-5 text-blue-400" />,
      titleAr: 'إدارة المواد والمحاضرات الذكية',
      titleEn: 'Smart Course & Lecture Management',
      descAr: 'تصنيف الوحدات الدراسية، تتبع نسب الإنجاز، وإدارة ملفات الـ PDF والتسجيلات المدمجة.',
      descEn: 'Organize clinical units, track completion rates, and manage PDF lecture decks with synced audio.'
    },
    {
      icon: <Calendar className="w-5 h-5 text-purple-400" />,
      titleAr: 'المخطط الزمني الذكي',
      titleEn: 'Dynamic Study Scheduler',
      descAr: 'جدولة الساعات الدراسية، استعراض المخطط اليومي والأسبوعي، وقفل ساعات المراجعة المركزة.',
      descEn: 'Schedule study slots, view daily timeline & weekly grid, with balanced active review ratios.'
    },
    {
      icon: <Clock className="w-5 h-5 text-emerald-400" />,
      titleAr: 'مؤقت بومودورو وسجل الإنتاجية',
      titleEn: 'Pomodoro Timer & Study Analytics',
      descAr: 'جلسات تركيز 25/5 دقيقة مع توثيق آلي للساعات، تقييمات ذكية، ورادار العد التنازلي للاختبارات.',
      descEn: '25/5 focus intervals with automatic logging, personalized academic evaluations, and exam radar.'
    },
    {
      icon: <Sparkles className="w-5 h-5 text-amber-400" />,
      titleAr: 'أكاديمية الاستذكار المتباعد',
      titleEn: 'Interactive Spaced Repetition Academy',
      descAr: 'بطاقات تقليب ثلاثية الأبعاد، اختبارات تفاعلية بتفسيرات سريرية، وحاسبة الجرعات الطبية.',
      descEn: 'Interactive 3D flashcards, clinical quizzes with rationale, and IV dosage sandbox.'
    }
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-slate-950/80 backdrop-blur-sm animate-fadeIn"
      dir={currentLang === 'ar' ? 'rtl' : 'ltr'}
    >
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <HelpCircle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white flex items-center gap-2">
                {t('helpGuide')}
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-900/40 text-blue-300 border border-blue-700/50">
                  Exo Documentation
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                {currentLang === 'ar' ? 'دليل الاستخدام الشامل للمنصة واختصارات لوحة المفاتيح' : 'Comprehensive platform guide and keyboard shortcuts'}
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsHelpModalOpen(false)}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Core Modules Grid */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              {currentLang === 'ar' ? 'أبرز مميزات منصة Exo' : 'Key Platform Capabilities'}
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {features.map((f, idx) => (
                <div key={idx} className="p-4 bg-slate-950/50 border border-slate-800 rounded-2xl flex items-start gap-3">
                  <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 shrink-0">
                    {f.icon}
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-sm mb-1">
                      {currentLang === 'ar' ? f.titleAr : f.titleEn}
                    </h4>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      {currentLang === 'ar' ? f.descAr : f.descEn}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Keyboard Shortcuts */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Keyboard className="w-4 h-4 text-purple-400" />
              {currentLang === 'ar' ? 'اختصارات سريعة للوحة المفاتيح' : 'Keyboard Shortcuts'}
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {shortcuts.map((sc, i) => (
                <div key={i} className="p-3 bg-slate-950/50 border border-slate-800 rounded-xl flex items-center justify-between">
                  <span className="text-xs text-slate-300">
                    {currentLang === 'ar' ? sc.descAr : sc.descEn}
                  </span>
                  <kbd className="px-2 py-1 bg-slate-800 border border-slate-700 text-slate-300 font-mono text-[11px] rounded-md shadow">
                    {sc.key}
                  </kbd>
                </div>
              ))}
            </div>
          </div>

          {/* Privacy & Isolation Note */}
          <div className="p-4 bg-blue-950/30 border border-blue-900/40 rounded-2xl flex items-center gap-3">
            <ShieldCheck className="w-6 h-6 text-emerald-400 shrink-0" />
            <p className="text-xs text-blue-200 leading-relaxed">
              {currentLang === 'ar'
                ? 'بياناتك وملاحظاتك الدراسية تُعالج محلياً بأقصى معايير التشفير (PBKDF2 / Web Crypto API) دون أي مشاركة خارجية، مع إمكانية التصدير الكامل في أي لحظة.'
                : 'Your study materials and progress are cryptographically secured using standard Web Crypto PBKDF2 with strict account isolation.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
