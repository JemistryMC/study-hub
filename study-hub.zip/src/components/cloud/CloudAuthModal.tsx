import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  ShieldCheck,
  Cloud,
  Download,
  Upload,
  User,
  KeyRound,
  LogOut,
  Users,
  CheckCircle2,
  Lock,
  Database
} from 'lucide-react';

export const CloudAuthModal: React.FC = () => {
  const {
    isCloudModalOpen,
    setIsCloudModalOpen,
    currentAccount,
    accounts,
    loginUser,
    signupUser,
    switchAccount,
    logoutUser,
    exportWorkspaceJson,
    importWorkspaceJson,
    t,
    currentLang,
    showToast
  } = useApp();

  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isCloudModalOpen) return null;

  const handleSubmitAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      showToast(currentLang === 'ar' ? 'يرجى إدخال اسم المستخدم وكلمة المرور' : 'Please fill all required fields', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      if (authMode === 'signup') {
        const success = await signupUser(username.trim(), password, displayName.trim() || username.trim());
        if (success) {
          setUsername('');
          setPassword('');
          setDisplayName('');
        }
      } else {
        const success = await loginUser(username.trim(), password);
        if (success) {
          setUsername('');
          setPassword('');
        }
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleExport = () => {
    const dataStr = exportWorkspaceJson();
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `exo-workspace-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast(currentLang === 'ar' ? 'تم تصدير النسخة الاحتياطية بنجاح' : 'Backup exported successfully', 'success');
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const ok = importWorkspaceJson(content);
      if (ok) {
        showToast(currentLang === 'ar' ? 'تم استيراد البيانات وتحديث مساحة العمل' : 'Data imported successfully', 'success');
      } else {
        showToast(currentLang === 'ar' ? 'ملف النسخة الاحتياطية غير صالح' : 'Invalid backup JSON file', 'error');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-slate-950/80 backdrop-blur-sm animate-fadeIn"
      dir={currentLang === 'ar' ? 'rtl' : 'ltr'}
    >
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Cloud className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white flex items-center gap-2">
                {t('cloudSync')}
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-900/40 text-blue-300 border border-blue-700/50 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-emerald-400" /> PBKDF2 Encrypted
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                {currentLang === 'ar' ? 'المزامنة السحابية، العزل الأمني للحسابات، وحفظ واسترجاع البيانات' : 'Cloud sync, cryptographically isolated multi-accounts, and workspace backup'}
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsCloudModalOpen(false)}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Current Active Account Card */}
          {currentAccount ? (
            <div className="p-5 bg-gradient-to-r from-blue-950/40 to-slate-900 border border-blue-800/40 rounded-2xl flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white font-black text-lg flex items-center justify-center shadow-lg">
                  {currentAccount.displayName.charAt(0).toUpperCase()}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-base">{currentAccount.displayName}</span>
                    <span className="text-[10px] px-2 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-800 rounded-full flex items-center gap-1 font-semibold">
                      <CheckCircle2 className="w-2.5 h-2.5" /> {t('connected')}
                    </span>
                  </div>
                  <span className="text-xs text-slate-400 font-mono">@{currentAccount.username || currentAccount.email}</span>
                </div>
              </div>

              <button
                onClick={() => logoutUser()}
                className="px-4 py-2 bg-rose-950/40 hover:bg-rose-900 border border-rose-800 text-rose-300 text-xs font-semibold rounded-xl transition-all flex items-center gap-1.5"
              >
                <LogOut className="w-3.5 h-3.5" />
                {t('logout')}
              </button>
            </div>
          ) : (
            /* Auth Form */
            <div className="p-6 bg-slate-950/50 border border-slate-800 rounded-2xl">
              <div className="flex items-center justify-between mb-4">
                <div className="flex gap-2">
                  <button
                    onClick={() => setAuthMode('login')}
                    className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      authMode === 'login' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {t('login')}
                  </button>
                  <button
                    onClick={() => setAuthMode('signup')}
                    className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      authMode === 'signup' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {t('signup')}
                  </button>
                </div>
                <span className="text-xs text-slate-500 flex items-center gap-1">
                  <Lock className="w-3 h-3 text-slate-400" /> Web Crypto API
                </span>
              </div>

              <form onSubmit={handleSubmitAuth} className="space-y-3">
                {authMode === 'signup' && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      {currentLang === 'ar' ? 'الاسم الظاهر' : 'Display Name'}
                    </label>
                    <input
                      type="text"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder="e.g. Dr. Ahmed"
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white placeholder-slate-500 outline-none focus:border-blue-500"
                    />
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {t('username')}
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-500 absolute left-3 top-3 rtl:right-3 rtl:left-auto" />
                    <input
                      type="text"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder="username"
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-9 py-2 text-sm text-white placeholder-slate-500 outline-none focus:border-blue-500 font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {t('password')}
                  </label>
                  <div className="relative">
                    <KeyRound className="w-4 h-4 text-slate-500 absolute left-3 top-3 rtl:right-3 rtl:left-auto" />
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-9 py-2 text-sm text-white placeholder-slate-500 outline-none focus:border-blue-500 font-mono"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full mt-2 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-xl font-bold text-sm shadow-lg transition-all"
                >
                  {isSubmitting
                    ? (currentLang === 'ar' ? 'جارٍ التحقق والتشفير...' : 'Verifying & Hashing...')
                    : authMode === 'signup'
                    ? t('signup')
                    : t('login')}
                </button>
              </form>
            </div>
          )}

          {/* Accounts Switcher (Isolated Local Accounts) */}
          {accounts.length > 0 && (
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
                <Users className="w-3.5 h-3.5 text-blue-400" />
                {t('switchAccount')} ({accounts.length})
              </label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {accounts.map((acc) => {
                  const isActive = currentAccount?.id === acc.id;
                  return (
                    <button
                      key={acc.id}
                      onClick={() => switchAccount(acc.id)}
                      className={`p-3 rounded-xl border text-right rtl:text-right ltr:text-left flex items-center justify-between transition-all ${
                        isActive
                          ? 'bg-blue-950/40 border-blue-500/50 text-blue-200'
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-lg bg-slate-800 text-white text-xs font-bold flex items-center justify-center">
                          {acc.displayName.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <p className="text-xs font-bold text-white leading-none">{acc.displayName}</p>
                          <span className="text-[10px] text-slate-500 font-mono">@{acc.username || acc.email}</span>
                        </div>
                      </div>
                      {isActive && <CheckCircle2 className="w-4 h-4 text-blue-400" />}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Backup & Restore Section */}
          <div className="p-5 bg-slate-950/60 border border-slate-800 rounded-2xl space-y-3">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-emerald-400" />
              <h3 className="font-bold text-white text-sm">
                {currentLang === 'ar' ? 'النسخ الاحتياطي والاستعادة' : 'Workspace Backup & Restore'}
              </h3>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              {currentLang === 'ar'
                ? 'يمكنك تصدير كامل بياناتك (المواد، المحاضرات، الجدول الدراسي، سجلات الإنتاجية، والبطاقات) كملف JSON مشفر ومحمي، أو استعادة نسخة سابقة في أي وقت.'
                : 'Export all courses, lectures, schedules, study logs, and flashcards to a local JSON backup file, or restore existing data at any time.'}
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
              <button
                onClick={handleExport}
                className="py-2.5 px-4 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all"
              >
                <Download className="w-4 h-4 text-blue-400" />
                {t('backupData')}
              </button>

              <label className="py-2.5 px-4 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 rounded-xl text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition-all">
                <Upload className="w-4 h-4 text-emerald-400" />
                <span>{t('restoreData')}</span>
                <input
                  type="file"
                  accept=".json,application/json"
                  onChange={handleImportFile}
                  className="hidden"
                />
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
