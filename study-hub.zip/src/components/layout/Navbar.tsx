import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  GraduationCap,
  BookOpen,
  CalendarDays,
  BarChart3,
  Sparkles,
  Cloud,
  Maximize2,
  Minimize2,
  HelpCircle,
  Sun,
  Moon,
  Eye,
  Languages,
  User,
  PanelLeftClose,
  PanelLeftOpen,
  Search
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    currentView,
    setCurrentView,
    subjects,
    scheduleEvents,
    studyLogs,
    sidebarCollapsed,
    toggleSidebar,
    language,
    toggleLanguage,
    theme,
    setTheme,
    setCloudAuthModalOpen,
    setHelpModalOpen,
    setAcademyModalOpen,
    activeAccount,
    t
  } = useApp();

  const [isFullscreen, setIsFullscreen] = useState(false);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
      }
      setIsFullscreen(false);
    }
  };

  const cycleTheme = () => {
    if (theme === 'dark') setTheme('light');
    else if (theme === 'light') setTheme('eye_comfort');
    else setTheme('dark');
  };

  // Count active stats
  const totalLectures = subjects.reduce((acc, s) => acc + s.groups.reduce((gAcc, g) => gAcc + g.lectures.length, 0), 0);
  const todayDay = new Date().getDay();
  const todaySlots = scheduleEvents.filter(e => e.day === todayDay);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-[#090d16]/90 backdrop-blur-md px-3 sm:px-6 py-2.5 transition-colors">
      <div className="flex items-center justify-between gap-2 sm:gap-4">
        {/* Left / Start: Logo & Sidebar Toggle */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={toggleSidebar}
            title={t('toggleSidebar')}
            className="hidden lg:flex p-2 rounded-xl text-slate-400 hover:text-teal-400 hover:bg-slate-800/60 transition"
          >
            {sidebarCollapsed ? <PanelLeftOpen className="w-5 h-5" /> : <PanelLeftClose className="w-5 h-5" />}
          </button>

          <div
            onClick={() => setCurrentView('subjects')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-teal-500 to-sky-500 p-0.5 shadow-lg shadow-teal-500/20 group-hover:scale-105 transition-transform flex items-center justify-center">
              <div className="w-full h-full bg-[#090d16] rounded-[10px] flex items-center justify-center">
                <GraduationCap className="w-5 h-5 text-teal-400 group-hover:rotate-12 transition-transform" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-lg sm:text-xl tracking-tight bg-gradient-to-r from-teal-400 via-sky-400 to-indigo-300 bg-clip-text text-transparent">
                  {t('brandName')}
                </span>
                <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-teal-500/10 text-teal-300 border border-teal-500/20">
                  Pro
                </span>
              </div>
              <p className="hidden md:block text-[11px] text-slate-400 truncate max-w-[200px]">
                {t('platformSubtitle')}
              </p>
            </div>
          </div>
        </div>

        {/* Center: Main Navigation Tabs */}
        <nav className="hidden md:flex items-center gap-1 bg-slate-900/90 p-1 rounded-2xl border border-slate-800 shadow-inner">
          <button
            onClick={() => setCurrentView('subjects')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
              currentView === 'subjects'
                ? 'bg-gradient-to-r from-teal-500 to-teal-600 text-slate-950 shadow-md shadow-teal-500/20'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>{t('navSubjects')}</span>
            <span
              className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                currentView === 'subjects' ? 'bg-slate-950/20 text-slate-950' : 'bg-slate-800 text-slate-400'
              }`}
            >
              {subjects.length}
            </span>
          </button>

          <button
            onClick={() => setCurrentView('schedule')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
              currentView === 'schedule'
                ? 'bg-gradient-to-r from-teal-500 to-teal-600 text-slate-950 shadow-md shadow-teal-500/20'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <CalendarDays className="w-4 h-4" />
            <span>{t('navSchedule')}</span>
            <span
              className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                currentView === 'schedule' ? 'bg-slate-950/20 text-slate-950' : 'bg-slate-800 text-slate-400'
              }`}
            >
              {todaySlots.length}
            </span>
          </button>

          <button
            onClick={() => setCurrentView('tracker')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
              currentView === 'tracker'
                ? 'bg-gradient-to-r from-teal-500 to-teal-600 text-slate-950 shadow-md shadow-teal-500/20'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>{t('navTracker')}</span>
            <span
              className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                currentView === 'tracker' ? 'bg-slate-950/20 text-slate-950' : 'bg-slate-800 text-slate-400'
              }`}
            >
              {studyLogs.length}
            </span>
          </button>
        </nav>

        {/* Right / End: Tools & Account Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Academy & Cards */}
          <button
            onClick={() => setAcademyModalOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-indigo-500/10 text-indigo-300 hover:bg-indigo-500/20 border border-indigo-500/30 transition shadow-sm"
            title={t('navAcademy')}
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden xl:inline">{t('navAcademy')}</span>
          </button>

          {/* Cloud Sync Status */}
          <button
            onClick={() => setCloudAuthModalOpen(true)}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold border transition ${
              activeAccount
                ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/20'
                : 'bg-slate-800/60 text-slate-300 border-slate-700 hover:bg-slate-800'
            }`}
            title={t('navCloud')}
          >
            <Cloud className={`w-3.5 h-3.5 ${activeAccount ? 'text-emerald-400' : 'text-slate-400'}`} />
            <span className="hidden lg:inline">{activeAccount ? activeAccount.displayName : t('navCloud')}</span>
          </button>

          {/* Language Switcher */}
          <button
            onClick={toggleLanguage}
            className="p-2 rounded-xl text-slate-300 hover:text-teal-400 hover:bg-slate-800/60 border border-slate-800 transition"
            title={language === 'ar' ? 'Switch to English' : 'التحويل للعربية'}
          >
            <Languages className="w-4 h-4" />
          </button>

          {/* Theme Switcher */}
          <button
            onClick={cycleTheme}
            className="p-2 rounded-xl text-slate-300 hover:text-teal-400 hover:bg-slate-800/60 border border-slate-800 transition"
            title={theme === 'dark' ? t('themeDark') : theme === 'light' ? t('themeLight') : t('themeEyeComfort')}
          >
            {theme === 'dark' && <Moon className="w-4 h-4 text-sky-400" />}
            {theme === 'light' && <Sun className="w-4 h-4 text-amber-400" />}
            {theme === 'eye_comfort' && <Eye className="w-4 h-4 text-amber-500" />}
          </button>

          {/* Fullscreen */}
          <button
            onClick={toggleFullscreen}
            className="hidden sm:flex p-2 rounded-xl text-slate-300 hover:text-teal-400 hover:bg-slate-800/60 border border-slate-800 transition"
            title={isFullscreen ? t('exitFullscreen') : t('fullscreen')}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          {/* Guide / Help */}
          <button
            onClick={() => setHelpModalOpen(true)}
            className="p-2 rounded-xl text-slate-300 hover:text-teal-400 hover:bg-slate-800/60 border border-slate-800 transition"
            title={t('navHelp')}
          >
            <HelpCircle className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
