import React from 'react';
import { useApp } from '../../context/AppContext';
import { BookOpen, CalendarDays, BarChart3, Sparkles, Cloud } from 'lucide-react';

export const MobileBottomNav: React.FC = () => {
  const { currentView, setCurrentView, setAcademyModalOpen, setCloudAuthModalOpen, t } = useApp();

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#090d16]/95 backdrop-blur-lg border-t border-slate-800/80 px-2 py-1.5 flex items-center justify-around shadow-2xl">
      <button
        onClick={() => setCurrentView('subjects')}
        className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition ${
          currentView === 'subjects' ? 'text-teal-400 font-bold' : 'text-slate-400 hover:text-slate-200'
        }`}
      >
        <BookOpen className="w-5 h-5" />
        <span className="text-[10px]">{t('navSubjects')}</span>
      </button>

      <button
        onClick={() => setCurrentView('schedule')}
        className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition ${
          currentView === 'schedule' ? 'text-teal-400 font-bold' : 'text-slate-400 hover:text-slate-200'
        }`}
      >
        <CalendarDays className="w-5 h-5" />
        <span className="text-[10px]">{t('navSchedule')}</span>
      </button>

      <button
        onClick={() => setCurrentView('tracker')}
        className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition ${
          currentView === 'tracker' ? 'text-teal-400 font-bold' : 'text-slate-400 hover:text-slate-200'
        }`}
      >
        <BarChart3 className="w-5 h-5" />
        <span className="text-[10px]">{t('navTracker')}</span>
      </button>

      <button
        onClick={() => setAcademyModalOpen(true)}
        className="flex flex-col items-center gap-1 py-1 px-3 rounded-xl text-indigo-400 hover:text-indigo-300 transition"
      >
        <Sparkles className="w-5 h-5" />
        <span className="text-[10px]">{t('navAcademy')}</span>
      </button>

      <button
        onClick={() => setCloudAuthModalOpen(true)}
        className="flex flex-col items-center gap-1 py-1 px-3 rounded-xl text-slate-400 hover:text-slate-200 transition"
      >
        <Cloud className="w-5 h-5" />
        <span className="text-[10px]">{t('navCloud')}</span>
      </button>
    </div>
  );
};
