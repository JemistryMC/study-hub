import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  BookOpen,
  CalendarDays,
  BarChart3,
  Sparkles,
  Plus,
  Flame,
  Clock,
  Compass,
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  GraduationCap
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const {
    currentView,
    setCurrentView,
    sidebarCollapsed,
    subjects,
    selectedSubjectId,
    setSelectedSubjectId,
    setSmartSubjectModalOpen,
    setExamRadarModalOpen,
    setAcademyModalOpen,
    studyLogs,
    language,
    t
  } = useApp();

  if (sidebarCollapsed) {
    return (
      <aside className="hidden lg:flex flex-col items-center py-4 w-16 border-r border-slate-800 bg-[#0c121e]/95 backdrop-blur-md gap-4 select-none shrink-0">
        <button
          onClick={() => setCurrentView('subjects')}
          className={`p-3 rounded-xl transition ${
            currentView === 'subjects' ? 'bg-teal-500 text-slate-950 shadow-md shadow-teal-500/20' : 'text-slate-400 hover:bg-slate-800/80 hover:text-teal-400'
          }`}
          title={t('navSubjects')}
        >
          <BookOpen className="w-5 h-5" />
        </button>

        <button
          onClick={() => setCurrentView('schedule')}
          className={`p-3 rounded-xl transition ${
            currentView === 'schedule' ? 'bg-teal-500 text-slate-950 shadow-md shadow-teal-500/20' : 'text-slate-400 hover:bg-slate-800/80 hover:text-teal-400'
          }`}
          title={t('navSchedule')}
        >
          <CalendarDays className="w-5 h-5" />
        </button>

        <button
          onClick={() => setCurrentView('tracker')}
          className={`p-3 rounded-xl transition ${
            currentView === 'tracker' ? 'bg-teal-500 text-slate-950 shadow-md shadow-teal-500/20' : 'text-slate-400 hover:bg-slate-800/80 hover:text-teal-400'
          }`}
          title={t('navTracker')}
        >
          <BarChart3 className="w-5 h-5" />
        </button>

        <button
          onClick={() => setAcademyModalOpen(true)}
          className="p-3 rounded-xl text-indigo-400 hover:bg-indigo-500/20 transition"
          title={t('navAcademy')}
        >
          <Sparkles className="w-5 h-5" />
        </button>

        <div className="w-8 h-px bg-slate-800 my-1" />

        <button
          onClick={() => setSmartSubjectModalOpen(true)}
          className="p-3 rounded-xl bg-teal-500/10 text-teal-400 hover:bg-teal-500/20 border border-teal-500/30 transition"
          title={t('addSubject')}
        >
          <Plus className="w-5 h-5" />
        </button>

        <button
          onClick={() => setExamRadarModalOpen(true)}
          className="p-3 rounded-xl bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 border border-rose-500/30 transition"
          title={t('examRadar')}
        >
          <Compass className="w-5 h-5" />
        </button>
      </aside>
    );
  }

  // Calculate stats
  const totalLectures = subjects.reduce((acc, s) => acc + s.groups.reduce((gAcc, g) => gAcc + g.lectures.length, 0), 0);
  const completedLectures = subjects.reduce(
    (acc, s) => acc + s.groups.reduce((gAcc, g) => gAcc + g.lectures.filter(l => l.completed).length, 0),
    0
  );
  const completionRate = totalLectures > 0 ? Math.round((completedLectures / totalLectures) * 100) : 0;
  const totalStudyMinutes = studyLogs.reduce((acc, l) => acc + (l.durationMinutes || 0), 0);
  const studyHours = (totalStudyMinutes / 60).toFixed(1);

  return (
    <aside className="hidden lg:flex flex-col w-64 border-r border-slate-800 bg-[#0c121e]/95 backdrop-blur-md p-4 select-none shrink-0 overflow-y-auto max-h-[calc(100vh-65px)]">
      {/* Top Quick Actions */}
      <div className="grid grid-cols-2 gap-2 mb-4">
        <button
          onClick={() => setSmartSubjectModalOpen(true)}
          className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-teal-500/10 text-teal-300 hover:bg-teal-500/20 border border-teal-500/30 text-xs font-semibold transition"
        >
          <Plus className="w-4 h-4" />
          <span>{t('addSubject')}</span>
        </button>

        <button
          onClick={() => setExamRadarModalOpen(true)}
          className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-rose-500/10 text-rose-300 hover:bg-rose-500/20 border border-rose-500/30 text-xs font-semibold transition"
        >
          <Compass className="w-4 h-4" />
          <span>{t('examRadar')}</span>
        </button>
      </div>

      {/* Main Navigation links */}
      <div className="space-y-1 mb-5">
        <button
          onClick={() => setCurrentView('subjects')}
          className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-semibold transition ${
            currentView === 'subjects'
              ? 'bg-gradient-to-r from-teal-500/20 to-teal-500/10 text-teal-300 border border-teal-500/30'
              : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <BookOpen className="w-4 h-4 text-teal-400" />
            <span>{t('navSubjects')}</span>
          </div>
          <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-bold">
            {subjects.length}
          </span>
        </button>

        <button
          onClick={() => setCurrentView('schedule')}
          className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-semibold transition ${
            currentView === 'schedule'
              ? 'bg-gradient-to-r from-teal-500/20 to-teal-500/10 text-teal-300 border border-teal-500/30'
              : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <CalendarDays className="w-4 h-4 text-sky-400" />
            <span>{t('navSchedule')}</span>
          </div>
        </button>

        <button
          onClick={() => setCurrentView('tracker')}
          className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-semibold transition ${
            currentView === 'tracker'
              ? 'bg-gradient-to-r from-teal-500/20 to-teal-500/10 text-teal-300 border border-teal-500/30'
              : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <BarChart3 className="w-4 h-4 text-indigo-400" />
            <span>{t('navTracker')}</span>
          </div>
          <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-bold">
            {studyLogs.length}
          </span>
        </button>

        <button
          onClick={() => setAcademyModalOpen(true)}
          className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-semibold text-slate-300 hover:bg-indigo-500/10 hover:text-indigo-300 border border-transparent hover:border-indigo-500/20 transition"
        >
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-4 h-4 text-indigo-400" />
            <span>{t('navAcademy')}</span>
          </div>
        </button>
      </div>

      {/* Progress & Productivity Widget */}
      <div className="bg-gradient-to-b from-slate-900 to-[#101726] border border-slate-800/80 rounded-2xl p-3.5 mb-5 shadow-lg">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold text-slate-400">{t('progressRate')}</span>
          <span className="text-xs font-extrabold text-teal-400">{completionRate}%</span>
        </div>
        <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden mb-3">
          <div
            className="h-full bg-gradient-to-r from-teal-500 to-sky-400 rounded-full transition-all duration-500"
            style={{ width: `${completionRate}%` }}
          />
        </div>

        <div className="grid grid-cols-2 gap-2 text-center pt-1 border-t border-slate-800/60">
          <div className="bg-slate-900/60 p-2 rounded-xl border border-slate-800/40">
            <div className="flex items-center justify-center gap-1 text-[11px] text-slate-400 mb-0.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>{t('completedCount')}</span>
            </div>
            <span className="text-sm font-extrabold text-slate-100">
              {completedLectures} / {totalLectures}
            </span>
          </div>

          <div className="bg-slate-900/60 p-2 rounded-xl border border-slate-800/40">
            <div className="flex items-center justify-center gap-1 text-[11px] text-slate-400 mb-0.5">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>{t('totalStudyTime')}</span>
            </div>
            <span className="text-sm font-extrabold text-slate-100">
              {studyHours} {t('hours')}
            </span>
          </div>
        </div>
      </div>

      {/* Subjects Quick Jump List */}
      <div className="flex-1">
        <div className="flex items-center justify-between mb-2.5 px-1">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">{t('totalSubjects')}</span>
          <span className="text-[11px] text-slate-500 font-semibold">{subjects.length}</span>
        </div>

        <div className="space-y-1.5">
          {subjects.map(subject => {
            const isSelected = selectedSubjectId === subject.id && currentView === 'subjects';
            const subLecs = subject.groups.reduce((acc, g) => acc + g.lectures.length, 0);
            const subDone = subject.groups.reduce((acc, g) => acc + g.lectures.filter(l => l.completed).length, 0);

            return (
              <button
                key={subject.id}
                onClick={() => {
                  setSelectedSubjectId(subject.id);
                  setCurrentView('subjects');
                }}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition text-start ${
                  isSelected
                    ? 'bg-teal-500/15 text-teal-300 border border-teal-500/30'
                    : 'text-slate-300 hover:bg-slate-800/50 hover:text-white border border-transparent'
                }`}
              >
                <div className="flex items-center gap-2 min-w-0">
                  <div
                    className="w-2.5 h-2.5 rounded-full shrink-0 shadow-sm"
                    style={{ backgroundColor: subject.color || '#2dd4bf' }}
                  />
                  <span className="truncate">{subject.name}</span>
                </div>
                <span className="text-[10px] text-slate-500 shrink-0 font-semibold">
                  {subDone}/{subLecs}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </aside>
  );
};
