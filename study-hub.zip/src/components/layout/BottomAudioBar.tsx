import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Play, Pause, RotateCcw, RotateCw, Volume2, FastForward, X, FileText, Music2 } from 'lucide-react';

export const BottomAudioBar: React.FC = () => {
  const {
    mergedStudioSubjectId,
    setMergedStudioSubjectId,
    mergedAudioPlaying,
    setMergedAudioPlaying,
    mergedAudioSpeed,
    setMergedAudioSpeed,
    mergedAudioVolume,
    setMergedAudioVolume,
    subjects,
    openLectureStudio,
    t
  } = useApp();

  const [currentTime, setCurrentTime] = useState(145); // simulated playback seconds
  const totalDuration = 2700; // 45 min

  const subject = subjects.find(s => s.id === mergedStudioSubjectId);

  useEffect(() => {
    let interval: ReturnType<typeof setInterval> | undefined;
    if (mergedAudioPlaying) {
      interval = setInterval(() => {
        setCurrentTime(prev => (prev < totalDuration ? prev + 1 : 0));
      }, 1000 / mergedAudioSpeed);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [mergedAudioPlaying, mergedAudioSpeed]);

  if (!subject) return null;

  const allLecs = subject.groups.flatMap(g => g.lectures);
  const activeLec = allLecs[0] || null;

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const speedOptions = [0.75, 1, 1.25, 1.5, 1.75, 2, 2.5];

  return (
    <div className="fixed bottom-14 md:bottom-3 left-3 right-3 md:left-6 md:right-6 z-30 bg-gradient-to-r from-slate-900/95 via-[#0f182a]/95 to-slate-900/95 border border-teal-500/30 rounded-2xl p-3 shadow-2xl backdrop-blur-xl animate-in fade-in slide-in-from-bottom-4 duration-300">
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Left: Info & Open Studio */}
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-teal-500 to-sky-500 flex items-center justify-center text-slate-950 shrink-0 shadow-md">
            <Music2 className="w-5 h-5 animate-pulse" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-teal-400 truncate">{subject.name}</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-teal-500/10 text-teal-300 border border-teal-500/20">
                {t('mergedAudioStudio')}
              </span>
            </div>
            <p className="text-xs text-slate-300 font-semibold truncate">
              {activeLec ? activeLec.title : 'تسجيل المحاضرات المدمجة'}
            </p>
          </div>
        </div>

        {/* Center: Playback Controls */}
        <div className="flex items-center gap-2 sm:gap-4 mx-auto">
          <button
            onClick={() => setCurrentTime(prev => Math.max(0, prev - 15))}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            title="-15s"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            onClick={() => setMergedAudioPlaying(!mergedAudioPlaying)}
            className="w-10 h-10 rounded-full bg-teal-400 hover:bg-teal-300 text-slate-950 flex items-center justify-center shadow-lg shadow-teal-500/20 transition-transform hover:scale-105 active:scale-95"
          >
            {mergedAudioPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 translate-x-0.5" />}
          </button>

          <button
            onClick={() => setCurrentTime(prev => Math.min(totalDuration, prev + 15))}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            title="+15s"
          >
            <RotateCw className="w-4 h-4" />
          </button>

          <div className="text-[11px] font-mono text-slate-400 min-w-[70px] text-center">
            {formatTime(currentTime)} / {formatTime(totalDuration)}
          </div>
        </div>

        {/* Right: Speed, Volume Boost & Actions */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Speed Selector */}
          <div className="flex items-center gap-1 bg-slate-800/80 p-1 rounded-xl border border-slate-700/60">
            <FastForward className="w-3.5 h-3.5 text-teal-400 hidden sm:inline" />
            <select
              value={mergedAudioSpeed}
              onChange={e => setMergedAudioSpeed(parseFloat(e.target.value))}
              className="bg-transparent text-xs text-slate-200 font-semibold focus:outline-none cursor-pointer"
            >
              {speedOptions.map(spd => (
                <option key={spd} value={spd} className="bg-slate-900 text-white">
                  {spd}x
                </option>
              ))}
            </select>
          </div>

          {/* Volume / Boost */}
          <div className="hidden sm:flex items-center gap-1.5 bg-slate-800/80 px-2 py-1 rounded-xl border border-slate-700/60">
            <Volume2 className="w-3.5 h-3.5 text-teal-400" />
            <input
              type="range"
              min="50"
              max="250"
              value={mergedAudioVolume}
              onChange={e => setMergedAudioVolume(parseInt(e.target.value))}
              className="w-16 accent-teal-400 cursor-pointer h-1"
              title={`${t('audioVolumeBoost')}: ${mergedAudioVolume}%`}
            />
            <span className="text-[10px] text-slate-400 font-mono">{mergedAudioVolume}%</span>
          </div>

          {/* Open in PDF Studio if lecture available */}
          {activeLec && (
            <button
              onClick={() => openLectureStudio(subject, activeLec)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-teal-500/10 text-teal-300 hover:bg-teal-500/20 border border-teal-500/30 text-xs font-semibold transition"
              title={t('openDocument')}
            >
              <FileText className="w-3.5 h-3.5" />
              <span className="hidden md:inline">{t('openDocument')}</span>
            </button>
          )}

          {/* Close bar */}
          <button
            onClick={() => {
              setMergedStudioSubjectId(null);
              setMergedAudioPlaying(false);
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            title={t('cancel')}
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
