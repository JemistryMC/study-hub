import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Maximize2,
  Minimize2,
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  Pen,
  Highlighter,
  Eraser,
  Undo2,
  Trash2,
  FileText,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  CheckCircle2,
  Plus,
  StickyNote
} from 'lucide-react';
import { CanvasStroke, TextAnnotation } from '../../types/academic';

export const PdfStudioModal: React.FC = () => {
  const {
    activePdfLecture,
    setActivePdfLecture,
    t,
    currentLang,
    activeSubject,
    updateLectureStatus,
    audioState,
    playAudio,
    pauseAudio,
    togglePlayPause,
    seekAudio,
    setAudioSpeed,
    showToast
  } = useApp();

  const [isFullscreen, setIsFullscreen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const totalPages = activePdfLecture?.totalPages || 24;
  const [zoomLevel, setZoomLevel] = useState(100);

  // Drawing Tools
  const [activeTool, setActiveTool] = useState<'pen' | 'highlighter' | 'eraser' | 'note'>('pen');
  const [activeColor, setActiveColor] = useState('#2563eb');
  const [strokeWidth, setStrokeWidth] = useState(3);
  const [isDrawing, setIsDrawing] = useState(false);

  // In-memory strokes & annotations per page
  const [pageStrokes, setPageStrokes] = useState<Record<number, CanvasStroke[]>>({});
  const [pageAnnotations, setPageAnnotations] = useState<Record<number, TextAnnotation[]>>({});
  const [newNoteText, setNewNoteText] = useState('');
  const [isAddingNote, setIsAddingNote] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  if (!activePdfLecture) return null;

  // Initialize or change lecture audio when opened
  useEffect(() => {
    if (activePdfLecture?.audioUrl && (!audioState.lecture || audioState.lecture.id !== activePdfLecture.id)) {
      playAudio(activePdfLecture);
    }
  }, [activePdfLecture]);

  // Redraw canvas whenever page or strokes change
  const redrawCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const currentStrokes = pageStrokes[currentPage] || [];
    currentStrokes.forEach((stroke) => {
      if (stroke.points.length < 2) return;
      ctx.beginPath();
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.lineWidth = stroke.width;

      if (stroke.type === 'highlighter') {
        ctx.globalAlpha = 0.35;
        ctx.strokeStyle = stroke.color;
      } else {
        ctx.globalAlpha = 1.0;
        ctx.strokeStyle = stroke.color;
      }

      ctx.moveTo(stroke.points[0].x, stroke.points[0].y);
      for (let i = 1; i < stroke.points.length; i++) {
        ctx.lineTo(stroke.points[i].x, stroke.points[i].y);
      }
      ctx.stroke();
      ctx.globalAlpha = 1.0;
    });
  }, [currentPage, pageStrokes]);

  useEffect(() => {
    redrawCanvas();
  }, [redrawCanvas]);

  // Setup canvas size
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    if (canvas.width !== rect.width || canvas.height !== rect.height) {
      canvas.width = rect.width || 800;
      canvas.height = rect.height || 1100;
      redrawCanvas();
    }
  }, [zoomLevel, isFullscreen]);

  // Handle Drawing events
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (activeTool === 'note') return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (activeTool === 'eraser') {
      // Erase strokes near click
      const currentList = pageStrokes[currentPage] || [];
      const filtered = currentList.filter((s) => {
        return !s.points.some((p) => Math.hypot(p.x - x, p.y - y) < 15);
      });
      setPageStrokes((prev) => ({ ...prev, [currentPage]: filtered }));
      return;
    }

    setIsDrawing(true);
    const newStroke: CanvasStroke = {
      type: activeTool,
      color: activeColor,
      width: activeTool === 'highlighter' ? 14 : strokeWidth,
      points: [{ x, y }]
    };

    setPageStrokes((prev) => {
      const list = prev[currentPage] || [];
      return { ...prev, [currentPage]: [...list, newStroke] };
    });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || activeTool === 'note' || activeTool === 'eraser') return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setPageStrokes((prev) => {
      const list = [...(prev[currentPage] || [])];
      if (list.length === 0) return prev;
      const lastStroke = { ...list[list.length - 1] };
      lastStroke.points = [...lastStroke.points, { x, y }];
      list[list.length - 1] = lastStroke;
      return { ...prev, [currentPage]: list };
    });
  };

  const handleMouseUp = () => {
    setIsDrawing(false);
  };

  const handleUndo = () => {
    setPageStrokes((prev) => {
      const list = prev[currentPage] || [];
      if (list.length === 0) return prev;
      return { ...prev, [currentPage]: list.slice(0, -1) };
    });
  };

  const handleClearPage = () => {
    setPageStrokes((prev) => ({ ...prev, [currentPage]: [] }));
    setPageAnnotations((prev) => ({ ...prev, [currentPage]: [] }));
    showToast(currentLang === 'ar' ? 'تم مسح محتويات الصفحة' : 'Page cleared', 'info');
  };

  const handleAddNote = () => {
    if (!newNoteText.trim()) return;
    const newNote: TextAnnotation = {
      id: 'note_' + Date.now(),
      page: currentPage,
      x: 60,
      y: 80 + (pageAnnotations[currentPage]?.length || 0) * 90,
      text: newNoteText.trim(),
      color: activeColor
    };
    setPageAnnotations((prev) => ({
      ...prev,
      [currentPage]: [...(prev[currentPage] || []), newNote]
    }));
    setNewNoteText('');
    setIsAddingNote(false);
    showToast(currentLang === 'ar' ? 'تمت إضافة الملاحظة' : 'Note added', 'success');
  };

  const handleDeleteNote = (id: string) => {
    setPageAnnotations((prev) => ({
      ...prev,
      [currentPage]: (prev[currentPage] || []).filter((n) => n.id !== id)
    }));
  };

  const colorPalette = [
    { label: 'Blue', hex: '#2563eb' },
    { label: 'Red', hex: '#ef4444' },
    { label: 'Green', hex: '#10b981' },
    { label: 'Yellow', hex: '#f59e0b' },
    { label: 'Purple', hex: '#8b5cf6' },
    { label: 'Dark', hex: '#0f172a' }
  ];

  return (
    <div
      ref={containerRef}
      className={`fixed inset-0 z-50 flex flex-col bg-slate-950/95 backdrop-blur-md transition-all ${
        isFullscreen ? 'p-0' : 'p-2 md:p-6'
      }`}
      dir={currentLang === 'ar' ? 'rtl' : 'ltr'}
    >
      <div className="flex-1 flex flex-col bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Top Studio Toolbar */}
        <header className="px-4 py-3 bg-slate-900/90 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-sm">
          {/* Title & Info */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center font-bold">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-white text-base flex items-center gap-2">
                {activePdfLecture.title}
                <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
                  {activeSubject ? (currentLang === 'ar' ? activeSubject.nameAr : activeSubject.name) : 'Exo'}
                </span>
              </h2>
              <div className="text-xs text-slate-400 flex items-center gap-3 mt-0.5">
                <span>{t('page')} {currentPage} / {totalPages}</span>
                <span>•</span>
                <span>{activePdfLecture.durationMin} {t('minutes')}</span>
                <span>•</span>
                <button
                  onClick={() => {
                    const next = activePdfLecture.status === 'completed' ? 'in_progress' : 'completed';
                    updateLectureStatus(activePdfLecture.id, next);
                  }}
                  className={`flex items-center gap-1 font-semibold ${
                    activePdfLecture.status === 'completed' ? 'text-emerald-400' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {activePdfLecture.status === 'completed' ? t('completed') : t('markCompleted')}
                </button>
              </div>
            </div>
          </div>

          {/* Drawing Tools Palette */}
          <div className="flex items-center gap-1.5 bg-slate-950/80 p-1.5 rounded-xl border border-slate-800">
            {/* Pen Tool */}
            <button
              onClick={() => setActiveTool('pen')}
              className={`p-2 rounded-lg transition-all ${
                activeTool === 'pen' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
              title={t('pen')}
            >
              <Pen className="w-4 h-4" />
            </button>

            {/* Highlighter Tool */}
            <button
              onClick={() => setActiveTool('highlighter')}
              className={`p-2 rounded-lg transition-all ${
                activeTool === 'highlighter' ? 'bg-amber-500 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
              title={t('highlighter')}
            >
              <Highlighter className="w-4 h-4" />
            </button>

            {/* Eraser Tool */}
            <button
              onClick={() => setActiveTool('eraser')}
              className={`p-2 rounded-lg transition-all ${
                activeTool === 'eraser' ? 'bg-rose-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
              title={t('eraser')}
            >
              <Eraser className="w-4 h-4" />
            </button>

            {/* Sticky Note */}
            <button
              onClick={() => setIsAddingNote(!isAddingNote)}
              className={`p-2 rounded-lg transition-all ${
                isAddingNote ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
              title={t('addNote')}
            >
              <StickyNote className="w-4 h-4" />
            </button>

            <div className="w-[1px] h-6 bg-slate-800 mx-1" />

            {/* Color circles */}
            <div className="flex items-center gap-1">
              {colorPalette.map((c) => (
                <button
                  key={c.hex}
                  onClick={() => setActiveColor(c.hex)}
                  className={`w-5 h-5 rounded-full transition-transform ${
                    activeColor === c.hex ? 'scale-125 ring-2 ring-white ring-offset-1 ring-offset-slate-900' : 'opacity-70 hover:opacity-100'
                  }`}
                  style={{ backgroundColor: c.hex }}
                  title={c.label}
                />
              ))}
            </div>

            <div className="w-[1px] h-6 bg-slate-800 mx-1" />

            {/* Stroke Width Selector */}
            <select
              value={strokeWidth}
              onChange={(e) => setStrokeWidth(Number(e.target.value))}
              className="bg-slate-900 border border-slate-700 text-slate-300 text-xs rounded-lg px-2 py-1 outline-none focus:border-blue-500"
            >
              <option value={2}>2px</option>
              <option value={4}>4px</option>
              <option value={8}>8px</option>
            </select>

            <button
              onClick={handleUndo}
              className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-all"
              title={t('undo')}
            >
              <Undo2 className="w-4 h-4" />
            </button>

            <button
              onClick={handleClearPage}
              className="p-2 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 transition-all"
              title={t('clearCanvas')}
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>

          {/* Navigation & Zoom controls */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800 text-xs">
              <button
                onClick={() => setZoomLevel((z) => Math.max(50, z - 10))}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg"
                title={t('zoomOut')}
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="px-2 font-mono text-slate-300">{zoomLevel}%</span>
              <button
                onClick={() => setZoomLevel((z) => Math.min(200, z + 10))}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg"
                title={t('zoomIn')}
              >
                <ZoomIn className="w-4 h-4" />
              </button>
            </div>

            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl transition-all"
              title={t('fullscreen')}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            <button
              onClick={() => setActivePdfLecture(null)}
              className="p-2 bg-rose-950/50 hover:bg-rose-900 border border-rose-800/50 text-rose-300 rounded-xl transition-all"
              title={t('close')}
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* Note Editor Banner if active */}
        {isAddingNote && (
          <div className="bg-slate-950 px-4 py-3 border-b border-purple-900/40 flex items-center gap-3">
            <StickyNote className="w-5 h-5 text-purple-400 shrink-0" />
            <input
              type="text"
              value={newNoteText}
              onChange={(e) => setNewNoteText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAddNote()}
              placeholder={currentLang === 'ar' ? 'اكتب ملاحظتك التوضيحية لهذه الصفحة...' : 'Type sticky annotation note for this page...'}
              className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-sm text-white placeholder-slate-500 outline-none focus:border-purple-500"
              autoFocus
            />
            <button
              onClick={handleAddNote}
              className="px-4 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              {t('addNote')}
            </button>
          </div>
        )}

        {/* Studio Document Workspace */}
        <div className="flex-1 overflow-auto bg-slate-950 flex items-center justify-center p-4 relative select-none">
          {/* Document Sheet Simulation */}
          <div
            className="relative bg-white text-slate-900 rounded-lg shadow-2xl transition-transform"
            style={{
              width: `${(800 * zoomLevel) / 100}px`,
              minHeight: `${(1100 * zoomLevel) / 100}px`,
              transformOrigin: 'top center'
            }}
          >
            {/* Document Header Representation */}
            <div className="p-8 border-b border-slate-200">
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-xs font-bold tracking-wider text-blue-600 uppercase">
                    {activeSubject ? (currentLang === 'ar' ? activeSubject.nameAr : activeSubject.name) : 'Medical Faculty'}
                  </span>
                  <h1 className="text-2xl font-black text-slate-900 mt-1">{activePdfLecture.title}</h1>
                  <p className="text-xs text-slate-500 mt-1">
                    Exo Smart Academic Lecture Document • {t('page')} {currentPage} of {totalPages}
                  </p>
                </div>
                <div className="text-right">
                  <div className="w-12 h-12 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-700 font-extrabold text-lg">
                    {currentPage}
                  </div>
                </div>
              </div>
            </div>

            {/* Simulated Medical/Academic Content */}
            <div className="p-8 space-y-6 text-sm text-slate-700 leading-relaxed font-sans select-text">
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <h3 className="font-bold text-slate-900 text-base mb-2">
                  1. {currentLang === 'ar' ? 'المفاهيم السريرية الأساسية والأهداف التعليمية' : 'Primary Clinical Objectives & Concepts'}
                </h3>
                <p>
                  {currentLang === 'ar'
                    ? 'تركز هذه الوحدة على فهم الآليات الفيزيولوجية المرضية واستيعاب خوارزميات التشخيص التفريقي وربطها بالتدبير العلاجي السريري الدقيق.'
                    : 'This module emphasizes understanding underlying pathophysiological mechanisms, differential diagnostic algorithms, and evidence-based therapeutic clinical management.'}
                </p>
              </div>

              <div>
                <h4 className="font-bold text-slate-900 mb-2">
                  2. {currentLang === 'ar' ? 'التحليل التفصيلي والآلية الحيوية' : 'Detailed Analysis & Molecular Dynamics'}
                </h4>
                <p className="mb-3">
                  {currentLang === 'ar'
                    ? 'تنشط المسارات الاستقلابية عبر مستقبلات نوعية تضمن التوازن الداخلي. يتم فحص المعايير الحيوية دورياً لقياس الاستجابة الدوائية وتقليل الآثار الجانبية.'
                    : 'Specific membrane receptors regulate intracellular cascade pathways maintaining homeostatic balance. Biochemical markers are routinely monitored to verify drug response and minimize adverse events.'}
                </p>
                <div className="grid grid-cols-2 gap-4 my-4">
                  <div className="p-3 bg-blue-50/60 border border-blue-200 rounded-lg">
                    <span className="font-semibold text-blue-900 block text-xs">
                      {currentLang === 'ar' ? 'المؤشر المخبري A' : 'Biomarker Reference A'}
                    </span>
                    <span className="text-slate-600 text-xs">
                      {currentLang === 'ar' ? 'المعدل الطبيعي: 12.5 - 18.0 mmol/L' : 'Normal Reference: 12.5 - 18.0 mmol/L'}
                    </span>
                  </div>
                  <div className="p-3 bg-emerald-50/60 border border-emerald-200 rounded-lg">
                    <span className="font-semibold text-emerald-900 block text-xs">
                      {currentLang === 'ar' ? 'مؤشر الكفاءة B' : 'Efficacy Marker B'}
                    </span>
                    <span className="text-slate-600 text-xs">
                      {currentLang === 'ar' ? 'معدل الحساسية النوعية > 94.2%' : 'Specific Sensitivity > 94.2%'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-amber-50/80 rounded-xl border border-amber-200">
                <h4 className="font-bold text-amber-900 mb-1">
                  ⚡ {currentLang === 'ar' ? 'نقطة حرجة للامتحان' : 'High-Yield Exam Focus'}
                </h4>
                <p className="text-xs text-amber-800">
                  {currentLang === 'ar'
                    ? 'انتبه جيداً إلى موانع الاستعمال المطلقة والتداخلات الدوائية التثبيطية مع إنزيمات السيتوكروم P450 أثناء التقييم السريري.'
                    : 'Carefully note absolute contraindications and cytochrome P450 inhibitor drug interactions during bedside clinical assessment.'}
                </p>
              </div>

              <p className="text-xs text-slate-400 italic text-center pt-8">
                — {currentLang === 'ar' ? 'نهاية محتوى الصفحة' : 'End of page contents'} —
              </p>
            </div>

            {/* Real Interactive Drawing Canvas Overlay */}
            <canvas
              ref={canvasRef}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
              className={`absolute inset-0 z-20 w-full h-full ${
                activeTool === 'eraser' ? 'cursor-crosshair' : activeTool === 'note' ? 'cursor-default' : 'cursor-crosshair'
              }`}
            />

            {/* Text Annotations Floating on Document */}
            {(pageAnnotations[currentPage] || []).map((note) => (
              <div
                key={note.id}
                style={{ top: `${note.y}px`, left: `${note.x}px` }}
                className="absolute z-30 p-2.5 bg-yellow-100 border-2 border-yellow-300 text-yellow-950 rounded-lg shadow-lg text-xs max-w-xs group transition-all"
              >
                <div className="flex items-center justify-between gap-2 pb-1 border-b border-yellow-200 mb-1">
                  <span className="font-bold flex items-center gap-1 text-[10px] text-yellow-800">
                    <StickyNote className="w-3 h-3" /> Note
                  </span>
                  <button
                    onClick={() => handleDeleteNote(note.id)}
                    className="text-yellow-700 hover:text-rose-600 opacity-60 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
                <p className="leading-snug">{note.text}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom Audio & Page Bar */}
        <footer className="px-4 py-2.5 bg-slate-900 border-t border-slate-800 flex flex-wrap items-center justify-between gap-4">
          {/* Synchronized Audio Player */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => togglePlayPause()}
              className="w-10 h-10 rounded-full bg-blue-600 hover:bg-blue-500 text-white flex items-center justify-center shadow-lg transition-transform hover:scale-105"
            >
              {audioState.isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
            </button>

            <button
              onClick={() => seekAudio(Math.max(0, audioState.currentTime - 10))}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg"
              title="Jump back 10s"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            {/* Time / scrubber */}
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-slate-400 min-w-10">
                {Math.floor(audioState.currentTime / 60)}:
                {String(Math.floor(audioState.currentTime % 60)).padStart(2, '0')}
              </span>
              <input
                type="range"
                min={0}
                max={audioState.duration || 100}
                value={audioState.currentTime}
                onChange={(e) => seekAudio(Number(e.target.value))}
                className="w-32 md:w-48 accent-blue-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
              <span className="text-xs font-mono text-slate-500 min-w-10">
                {Math.floor((audioState.duration || 2400) / 60)}:
                {String(Math.floor((audioState.duration || 2400) % 60)).padStart(2, '0')}
              </span>
            </div>

            {/* Playback Speed selector */}
            <select
              value={audioState.playbackRate}
              onChange={(e) => setAudioSpeed(Number(e.target.value))}
              className="bg-slate-950 border border-slate-800 text-slate-300 text-xs rounded-lg px-2 py-1 outline-none font-mono"
            >
              <option value={0.75}>0.75x</option>
              <option value={1.0}>1.0x</option>
              <option value={1.25}>1.25x</option>
              <option value={1.5}>1.5x</option>
              <option value={1.75}>1.75x</option>
              <option value={2.0}>2.0x</option>
            </select>
          </div>

          {/* Page Navigation */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage <= 1}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 rounded-lg transition-all"
            >
              <ChevronRight className={`w-4 h-4 ${currentLang === 'ar' ? '' : 'rotate-180'}`} />
            </button>
            <div className="flex items-center gap-1 text-xs text-slate-300">
              <input
                type="number"
                min={1}
                max={totalPages}
                value={currentPage}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  if (val >= 1 && val <= totalPages) setCurrentPage(val);
                }}
                className="w-12 bg-slate-950 border border-slate-700 text-center py-1 rounded-lg outline-none font-bold text-white focus:border-blue-500"
              />
              <span className="text-slate-500">/ {totalPages}</span>
            </div>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage >= totalPages}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 rounded-lg transition-all"
            >
              <ChevronLeft className={`w-4 h-4 ${currentLang === 'ar' ? '' : 'rotate-180'}`} />
            </button>
          </div>
        </footer>
      </div>
    </div>
  );
};
