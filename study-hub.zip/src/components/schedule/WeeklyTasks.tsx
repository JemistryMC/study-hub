import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CheckSquare, Plus, Trash2, CheckCircle2, Clock, Sparkles } from 'lucide-react';

export const WeeklyTasks: React.FC = () => {
  const { weeklyTasks, addWeeklyTask, toggleWeeklyTask, deleteWeeklyTask, subjects, language, t } = useApp();

  const [title, setTitle] = useState('');
  const [targetHours, setTargetHours] = useState(2);
  const [subjectId, setSubjectId] = useState<number | undefined>(undefined);
  const [addingTask, setAddingTask] = useState(false);

  const totalTargetHours = weeklyTasks.reduce((acc, t) => acc + t.targetHours, 0);
  const totalCompletedHours = weeklyTasks.reduce((acc, t) => acc + (t.completed ? t.targetHours : t.completedHours), 0);
  const taskProgress = totalTargetHours > 0 ? Math.round((totalCompletedHours / totalTargetHours) * 100) : 0;

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    addWeeklyTask({
      title: title.trim(),
      targetHours: Number(targetHours) || 1,
      completedHours: 0,
      completed: false,
      subjectId
    });
    setTitle('');
    setTargetHours(2);
    setSubjectId(undefined);
    setAddingTask(false);
  };

  return (
    <div className="space-y-5">
      {/* Target Hours Summary Card */}
      <div className="bg-[#101726] border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
          <div>
            <h3 className="text-base sm:text-lg font-extrabold text-white flex items-center gap-2">
              <CheckSquare className="w-5 h-5 text-teal-400" />
              <span>{t('subviewTasks')}</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              {language === 'ar' ? 'تتبع أهداف المذاكرة الأسبوعية والمهام المحددة بساعات الإنجاز' : 'Weekly study targets and task checklist'}
            </p>
          </div>

          <div className="flex items-center gap-4 bg-slate-900/80 px-4 py-2.5 rounded-2xl border border-slate-800">
            <div>
              <span className="text-[10px] text-slate-500 font-semibold block">{t('targetHours')}</span>
              <span className="text-base font-extrabold text-slate-200">{totalTargetHours} {t('hours')}</span>
            </div>
            <div className="w-px h-6 bg-slate-800" />
            <div>
              <span className="text-[10px] text-slate-500 font-semibold block">{t('achievedHours')}</span>
              <span className="text-base font-extrabold text-teal-400">{totalCompletedHours} {t('hours')}</span>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-xs font-bold">
            <span className="text-slate-400">{t('progressRate')}</span>
            <span className="text-teal-400">{taskProgress}%</span>
          </div>
          <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-teal-500 to-sky-400 rounded-full transition-all duration-500"
              style={{ width: `${taskProgress}%` }}
            />
          </div>
        </div>
      </div>

      {/* Task List Header */}
      <div className="flex items-center justify-between">
        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
          {language === 'ar' ? 'قائمة الأهداف والمهام' : 'Tasks Checklist'} ({weeklyTasks.length})
        </span>

        <button
          onClick={() => setAddingTask(!addingTask)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-500/10 text-teal-300 hover:bg-teal-500/20 border border-teal-500/30 text-xs font-bold transition"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{language === 'ar' ? 'إضافة هدف أسبوعي' : 'Add Weekly Goal'}</span>
        </button>
      </div>

      {/* Add Task Inline Form */}
      {addingTask && (
        <form onSubmit={handleAddSubmit} className="bg-slate-900/90 border border-teal-500/40 rounded-2xl p-4 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <input
                type="text"
                required
                placeholder={language === 'ar' ? 'عنوان الهدف (مثلاً: إنهاء تلخيص الفصل الأول)' : 'Task Title'}
                value={title}
                onChange={e => setTitle(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <input
                type="number"
                min="0.5"
                step="0.5"
                max="20"
                value={targetHours}
                onChange={e => setTargetHours(parseFloat(e.target.value) || 1)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-teal-500"
                title={t('targetHours')}
              />

              <select
                value={subjectId || ''}
                onChange={e => setSubjectId(e.target.value ? Number(e.target.value) : undefined)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-2 py-2 text-xs text-slate-300 focus:outline-none"
              >
                <option value="">{language === 'ar' ? 'بدون مادة' : 'General'}</option>
                {subjects.map(s => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="submit"
              className="px-4 py-1.5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold rounded-xl text-xs transition"
            >
              {t('save')}
            </button>
            <button
              type="button"
              onClick={() => setAddingTask(false)}
              className="px-3 py-1.5 bg-slate-800 text-slate-400 hover:text-white rounded-xl text-xs transition"
            >
              {t('cancel')}
            </button>
          </div>
        </form>
      )}

      {/* Task Items */}
      <div className="space-y-2">
        {weeklyTasks.map(task => {
          const sub = subjects.find(s => s.id === task.subjectId);

          return (
            <div
              key={task.id}
              className={`flex items-center justify-between gap-3 p-3.5 rounded-2xl border transition-all ${
                task.completed
                  ? 'bg-slate-900/40 border-slate-800/60'
                  : 'bg-[#101726] border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <button
                  onClick={() => toggleWeeklyTask(task.id)}
                  className="shrink-0 text-slate-500 hover:text-teal-400 transition"
                >
                  <CheckCircle2
                    className={`w-5 h-5 ${task.completed ? 'text-teal-400 fill-teal-400/20' : ''}`}
                  />
                </button>

                <div className="min-w-0">
                  <h4
                    onClick={() => toggleWeeklyTask(task.id)}
                    className={`text-sm font-bold truncate cursor-pointer ${
                      task.completed ? 'line-through text-slate-500' : 'text-slate-100'
                    }`}
                  >
                    {task.title}
                  </h4>

                  <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-400">
                    {sub && (
                      <span className="flex items-center gap-1 font-semibold text-slate-300">
                        <span className="w-2 h-2 rounded-full" style={{ backgroundColor: sub.color || '#2dd4bf' }} />
                        <span>{sub.name}</span>
                      </span>
                    )}

                    <span>
                      {task.targetHours} {t('hours')}
                    </span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => deleteWeeklyTask(task.id)}
                className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition shrink-0"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
