import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { ScheduleEvent, SlotType } from '../../types/academic';
import { X, Calendar, Clock, BookOpen, Tag } from 'lucide-react';

export const AddSlotModal: React.FC = () => {
  const {
    addSlotModalOpen,
    setAddSlotModalOpen,
    editingSlot,
    setEditingSlot,
    addScheduleEvent,
    updateScheduleEvent,
    subjects,
    language,
    t
  } = useApp();

  const [title, setTitle] = useState('');
  const [day, setDay] = useState(6); // Saturday default
  const [startHour, setStartHour] = useState(10);
  const [startMinute, setStartMinute] = useState(0);
  const [endHour, setEndHour] = useState(12);
  const [endMinute, setEndMinute] = useState(0);
  const [type, setType] = useState<SlotType>('study');
  const [subjectId, setSubjectId] = useState<number | undefined>(undefined);
  const [notes, setNotes] = useState('');

  const daysArabic = ['السبت', 'الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'];
  const daysEnglish = ['Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const dayIndexMap = [6, 0, 1, 2, 3, 4, 5];

  useEffect(() => {
    if (editingSlot) {
      setTitle(editingSlot.title || '');
      setDay(editingSlot.day !== undefined ? editingSlot.day : 6);
      setStartHour(editingSlot.startHour !== undefined ? editingSlot.startHour : 10);
      setStartMinute(editingSlot.startMinute !== undefined ? editingSlot.startMinute : 0);
      setEndHour(editingSlot.endHour !== undefined ? editingSlot.endHour : 12);
      setEndMinute(editingSlot.endMinute !== undefined ? editingSlot.endMinute : 0);
      setType(editingSlot.type || 'study');
      setSubjectId(editingSlot.subjectId);
      setNotes(editingSlot.notes || '');
    } else {
      setTitle('');
      setDay(6);
      setStartHour(10);
      setStartMinute(0);
      setEndHour(12);
      setEndMinute(0);
      setType('study');
      setSubjectId(undefined);
      setNotes('');
    }
  }, [editingSlot, addSlotModalOpen]);

  if (!addSlotModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    if (editingSlot && editingSlot.id) {
      updateScheduleEvent(editingSlot.id, {
        title: title.trim(),
        day,
        startHour,
        startMinute,
        endHour,
        endMinute,
        type,
        subjectId,
        notes: notes.trim()
      });
    } else {
      addScheduleEvent({
        title: title.trim(),
        day,
        startHour,
        startMinute,
        endHour,
        endMinute,
        type,
        subjectId,
        completed: false,
        notes: notes.trim()
      });
    }

    setAddSlotModalOpen(false);
    setEditingSlot(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#0e1626] border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-2xl space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center border border-teal-500/20">
              <Calendar className="w-4 h-4" />
            </div>
            <h3 className="text-base font-extrabold text-white">
              {editingSlot?.id ? (language === 'ar' ? 'تعديل الفترة المجدولة' : 'Edit Schedule Slot') : t('addSession')}
            </h3>
          </div>

          <button
            onClick={() => {
              setAddSlotModalOpen(false);
              setEditingSlot(null);
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              {language === 'ar' ? 'عنوان الفترة / المذاكرة *' : 'Session Title *'}
            </label>
            <input
              type="text"
              required
              placeholder={language === 'ar' ? 'مثال: مذاكرة تلخيص Lec 2 علم الأدوية' : 'e.g. Study Lec 2 Pharmacology'}
              value={title}
              onChange={e => setTitle(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
            />
          </div>

          {/* Day & Type */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {language === 'ar' ? 'اليوم' : 'Day'}
              </label>
              <select
                value={day}
                onChange={e => setDay(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-teal-500"
              >
                {dayIndexMap.map((dIdx, colIdx) => (
                  <option key={dIdx} value={dIdx}>
                    {language === 'ar' ? daysArabic[colIdx] : daysEnglish[colIdx]}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {language === 'ar' ? 'نوع الفترة' : 'Slot Type'}
              </label>
              <select
                value={type}
                onChange={e => setType(e.target.value as SlotType)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-teal-500"
              >
                <option value="study">{language === 'ar' ? 'مذاكرة ذاتية' : 'Self Study'}</option>
                <option value="college">{language === 'ar' ? 'محاضرة كلية' : 'College Lecture'}</option>
                <option value="review">{language === 'ar' ? 'مراجعة ذكية' : 'Smart Review'}</option>
                <option value="absent">{language === 'ar' ? 'فترة غياب' : 'Absent Time'}</option>
                <option value="exam">{language === 'ar' ? 'امتحان / كويز' : 'Exam / Quiz'}</option>
              </select>
            </div>
          </div>

          {/* Time From & To */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {language === 'ar' ? 'وقت البدء' : 'Start Time'}
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                <input
                  type="number"
                  min="0"
                  max="23"
                  value={startHour}
                  onChange={e => setStartHour(parseInt(e.target.value) || 0)}
                  className="bg-slate-900 border border-slate-700 rounded-xl px-2 py-1.5 text-xs text-white text-center"
                  title="Hour"
                />
                <input
                  type="number"
                  min="0"
                  max="59"
                  step="5"
                  value={startMinute}
                  onChange={e => setStartMinute(parseInt(e.target.value) || 0)}
                  className="bg-slate-900 border border-slate-700 rounded-xl px-2 py-1.5 text-xs text-white text-center"
                  title="Minute"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {language === 'ar' ? 'وقت الانتهاء' : 'End Time'}
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                <input
                  type="number"
                  min="0"
                  max="23"
                  value={endHour}
                  onChange={e => setEndHour(parseInt(e.target.value) || 0)}
                  className="bg-slate-900 border border-slate-700 rounded-xl px-2 py-1.5 text-xs text-white text-center"
                  title="Hour"
                />
                <input
                  type="number"
                  min="0"
                  max="59"
                  step="5"
                  value={endMinute}
                  onChange={e => setEndMinute(parseInt(e.target.value) || 0)}
                  className="bg-slate-900 border border-slate-700 rounded-xl px-2 py-1.5 text-xs text-white text-center"
                  title="Minute"
                />
              </div>
            </div>
          </div>

          {/* Related Subject */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              {language === 'ar' ? 'المادة المرتبطة (اختياري)' : 'Related Course (Optional)'}
            </label>
            <select
              value={subjectId || ''}
              onChange={e => setSubjectId(e.target.value ? Number(e.target.value) : undefined)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
            >
              <option value="">{language === 'ar' ? 'بدون مادة محددة' : 'General / None'}</option>
              {subjects.map(s => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              {language === 'ar' ? 'ملاحظات / مكان المحاضرة' : 'Notes / Location'}
            </label>
            <textarea
              rows={2}
              placeholder={language === 'ar' ? 'مثلاً: مدرج 2 أو حل تدريبات الكويز' : 'e.g. Hall 4 or solve practice questions'}
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none"
            />
          </div>

          {/* Submit */}
          <div className="pt-2 border-t border-slate-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => {
                setAddSlotModalOpen(false);
                setEditingSlot(null);
              }}
              className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-semibold"
            >
              {t('cancel')}
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold rounded-xl text-xs shadow-md"
            >
              {t('save')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
