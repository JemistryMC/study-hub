import React from 'react';
import { useApp } from '../../context/AppContext';
import { ScheduleEvent, SlotType } from '../../types/academic';
import { Plus, Clock, CheckCircle2, Calendar } from 'lucide-react';

export const WeekGrid: React.FC = () => {
  const {
    scheduleEvents,
    subjects,
    setAddSlotModalOpen,
    setEditingSlot,
    updateScheduleEvent,
    language,
    t
  } = useApp();

  const daysArabic = ['السبت', 'الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'];
  const daysEnglish = ['Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const dayIndexMap = [6, 0, 1, 2, 3, 4, 5]; // Sat to Fri

  const formatSlotTime = (h: number, m: number) => {
    const period = h >= 12 ? (language === 'ar' ? 'م' : 'PM') : language === 'ar' ? 'ص' : 'AM';
    const displayH = h % 12 || 12;
    return `${displayH}:${m < 10 ? '0' : ''}${m} ${period}`;
  };

  const getSlotTypeStyle = (type: SlotType) => {
    switch (type) {
      case 'college':
        return 'bg-sky-500/10 border-sky-500/30 text-sky-300';
      case 'study':
        return 'bg-teal-500/10 border-teal-500/30 text-teal-300';
      case 'review':
        return 'bg-indigo-500/10 border-indigo-500/30 text-indigo-300';
      case 'absent':
        return 'bg-amber-500/10 border-amber-500/30 text-amber-300';
      case 'exam':
        return 'bg-rose-500/10 border-rose-500/30 text-rose-300';
      default:
        return 'bg-slate-800 border-slate-700 text-slate-300';
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-7 gap-3">
        {dayIndexMap.map((dayIdx, colIdx) => {
          const dayEvents = scheduleEvents
            .filter(ev => ev.day === dayIdx)
            .sort((a, b) => a.startHour * 60 + a.startMinute - (b.startHour * 60 + b.startMinute));

          const isToday = new Date().getDay() === dayIdx;

          return (
            <div
              key={dayIdx}
              className={`flex flex-col min-h-[300px] bg-[#101726] border rounded-2xl p-3 shadow-lg transition ${
                isToday ? 'border-teal-500/50 ring-1 ring-teal-500/30' : 'border-slate-800'
              }`}
            >
              {/* Day Column Header */}
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2 mb-2.5">
                <div>
                  <h4 className="text-xs font-extrabold text-white">
                    {language === 'ar' ? daysArabic[colIdx] : daysEnglish[colIdx]}
                  </h4>
                  {isToday && (
                    <span className="text-[10px] text-teal-400 font-bold block">{t('subviewToday')}</span>
                  )}
                </div>

                <button
                  onClick={() => {
                    setEditingSlot({
                      id: '',
                      title: '',
                      day: dayIdx,
                      startHour: 10,
                      startMinute: 0,
                      endHour: 12,
                      endMinute: 0,
                      type: 'study'
                    });
                    setAddSlotModalOpen(true);
                  }}
                  className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                  title={t('addSession')}
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Day Events Column */}
              <div className="space-y-2 flex-1">
                {dayEvents.length === 0 ? (
                  <div className="h-full flex items-center justify-center py-8">
                    <span className="text-[11px] text-slate-600 italic">--</span>
                  </div>
                ) : (
                  dayEvents.map(event => {
                    const sub = subjects.find(s => s.id === event.subjectId);
                    const typeStyle = getSlotTypeStyle(event.type);

                    return (
                      <div
                        key={event.id}
                        onClick={() => {
                          setEditingSlot(event);
                          setAddSlotModalOpen(true);
                        }}
                        className={`p-2.5 rounded-xl border text-xs cursor-pointer transition hover:scale-[1.02] ${typeStyle}`}
                      >
                        <div className="flex items-center justify-between gap-1 mb-1">
                          <span className="text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.2 rounded bg-slate-900/80">
                            {event.type}
                          </span>
                          <button
                            onClick={e => {
                              e.stopPropagation();
                              updateScheduleEvent(event.id, { completed: !event.completed });
                            }}
                            className="text-slate-400 hover:text-teal-400"
                          >
                            <CheckCircle2
                              className={`w-3.5 h-3.5 ${
                                event.completed ? 'text-teal-400 fill-teal-400/20' : ''
                              }`}
                            />
                          </button>
                        </div>

                        <h5
                          className={`font-bold line-clamp-2 mb-1 ${
                            event.completed ? 'line-through text-slate-500' : 'text-slate-100'
                          }`}
                        >
                          {event.title}
                        </h5>

                        <div className="flex items-center gap-1 text-[10px] text-slate-400 font-mono">
                          <Clock className="w-3 h-3" />
                          <span>
                            {formatSlotTime(event.startHour, event.startMinute)}
                          </span>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
