import React from 'react';
import { useApp } from '../../context/AppContext';
import { X, Printer, FileDown, Calendar, CheckCircle2 } from 'lucide-react';

export const ExportPdfModal: React.FC = () => {
  const { exportPdfModalOpen, setExportPdfModalOpen, scheduleEvents, subjects, language, t } = useApp();

  if (!exportPdfModalOpen) return null;

  const daysArabic = ['السبت', 'الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'];
  const dayIndexMap = [6, 0, 1, 2, 3, 4, 5];

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl bg-[#0e1626] border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-2xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 mb-4 shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-sky-500/10 text-sky-400 flex items-center justify-center border border-sky-500/20">
              <FileDown className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">{t('exportSchedulePdf')}</h3>
              <p className="text-xs text-slate-400">
                {language === 'ar' ? 'معاينة جاهزة للطباعة والتصدير كملف PDF' : 'Printable Weekly Schedule Preview'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setExportPdfModalOpen(false)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Schedule Table Preview */}
        <div className="overflow-y-auto flex-1 p-4 bg-white text-slate-900 rounded-2xl shadow-inner print:p-0">
          <div className="text-center pb-4 border-b border-slate-200 mb-4">
            <h2 className="text-xl font-black text-slate-900">Exo Academic Platform</h2>
            <p className="text-xs text-slate-600 font-semibold mt-0.5">
              {language === 'ar' ? 'الجدول الدراسي والتخطيط الأسبوعي المعتمد' : 'Official Weekly Study & Academic Schedule'}
            </p>
            <span className="text-[10px] text-slate-400 font-mono mt-1 block">
              {new Date().toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })}
            </span>
          </div>

          <div className="space-y-3">
            {dayIndexMap.map((dIdx, colIdx) => {
              const dayEvs = scheduleEvents.filter(e => e.day === dIdx);
              if (dayEvs.length === 0) return null;

              return (
                <div key={dIdx} className="border border-slate-200 rounded-xl p-3 bg-slate-50">
                  <h4 className="text-xs font-bold text-slate-800 mb-2 border-b border-slate-200 pb-1 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-teal-600" />
                    <span>{daysArabic[colIdx]}</span>
                  </h4>

                  <div className="space-y-1.5">
                    {dayEvs.map(ev => {
                      const sub = subjects.find(s => s.id === ev.subjectId);
                      return (
                        <div
                          key={ev.id}
                          className="flex items-center justify-between text-xs p-2 bg-white rounded-lg border border-slate-200"
                        >
                          <div>
                            <span className="font-bold text-slate-900">{ev.title}</span>
                            {sub && <span className="text-slate-500 font-medium ml-2 mr-2">({sub.name})</span>}
                          </div>
                          <span className="font-mono text-slate-600 text-[11px] shrink-0">
                            {ev.startHour}:{ev.startMinute < 10 ? '0' : ''}{ev.startMinute} - {ev.endHour}:
                            {ev.endMinute < 10 ? '0' : ''}{ev.endMinute}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-2.5 shrink-0">
          <button
            onClick={() => setExportPdfModalOpen(false)}
            className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-semibold"
          >
            {t('cancel')}
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-5 py-2 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold rounded-xl text-xs shadow-md"
          >
            <Printer className="w-4 h-4" />
            <span>{language === 'ar' ? 'طباعة / حفظ كـ PDF' : 'Print / Save as PDF'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
