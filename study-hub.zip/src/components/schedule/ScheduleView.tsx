import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  CalendarDays,
  Calendar,
  CheckSquare,
  Plus,
  FileDown,
  Sparkles,
  Clock,
  TrendingUp,
  AlertCircle,
  GraduationCap
} from 'lucide-react';
import { DayTimeline } from './DayTimeline';
import { WeekGrid } from './WeekGrid';
import { WeeklyTasks } from './WeeklyTasks';

export const ScheduleView: React.FC = () => {
  const {
    scheduleSubView,
    setScheduleSubView,
    scheduleEvents,
    setAddSlotModalOpen,
    setEditingSlot,
    setExportPdfModalOpen,
    language,
    t
  } = useApp();

  // Calculate metrics
  let totalCollegeMins = 0;
  let totalStudyMins = 0;
  let totalReviewMins = 0;
  let totalAbsentMins = 0;

  scheduleEvents.forEach(ev => {
    const startMins = ev.startHour * 60 + ev.startMinute;
    const endMins = ev.endHour * 60 + ev.endMinute;
    const dur = Math.max(0, endMins - startMins);

    if (ev.type === 'college') totalCollegeMins += dur;
    else if (ev.type === 'study') totalStudyMins += dur;
    else if (ev.type === 'review') totalReviewMins += dur;
    else if (ev.type === 'absent') totalAbsentMins += dur;
  });

  const collegeHours = (totalCollegeMins / 60).toFixed(1);
  const studyHours = (totalStudyMins / 60).toFixed(1);
  const reviewHours = (totalReviewMins / 60).toFixed(1);
  const absentHours = (totalAbsentMins / 60).toFixed(1);

  // Review Ratio
  const reviewRatio = totalStudyMins > 0 ? Math.round((totalReviewMins / totalStudyMins) * 100) : 0;

  return (
    <div className="space-y-6 pb-20 md:pb-12 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-[#10192d] to-slate-900 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-5 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-teal-500/10 text-teal-300 border border-teal-500/30 flex items-center gap-1.5">
                <CalendarDays className="w-3.5 h-3.5 text-teal-400" />
                <span>{t('scheduleTitle')}</span>
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white mb-2">
              {t('scheduleTitle')}
            </h1>
            <p className="text-sm text-slate-400 max-w-xl leading-relaxed">
              {t('scheduleSubtitle')}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => {
                setEditingSlot(null);
                setAddSlotModalOpen(true);
              }}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-400 hover:to-teal-500 text-slate-950 font-bold text-sm shadow-lg shadow-teal-500/25 transition-all transform hover:-translate-y-0.5"
            >
              <Plus className="w-4 h-4" />
              <span>{t('addSession')}</span>
            </button>

            <button
              onClick={() => setExportPdfModalOpen(true)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 border border-slate-700/80 font-semibold text-sm transition"
            >
              <FileDown className="w-4 h-4 text-sky-400" />
              <span>{t('exportSchedulePdf')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        <div className="bg-[#101726] border border-slate-800/80 p-3.5 rounded-2xl flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-slate-400 mb-1 flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5 text-indigo-400" />
            <span>{t('smartReviewRatio')}</span>
          </span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-black text-indigo-300">{reviewRatio}%</span>
            <span className="text-[10px] text-slate-500 font-medium">
              {reviewRatio >= 25 ? 'ممتاز' : 'يُنصح بالمراجعة'}
            </span>
          </div>
        </div>

        <div className="bg-[#101726] border border-slate-800/80 p-3.5 rounded-2xl flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-slate-400 mb-1 flex items-center gap-1.5">
            <GraduationCap className="w-3.5 h-3.5 text-sky-400" />
            <span>{t('collegeHours')}</span>
          </span>
          <span className="text-xl font-black text-sky-300">
            {collegeHours} <span className="text-xs font-normal text-slate-400">{t('hours')}</span>
          </span>
        </div>

        <div className="bg-[#101726] border border-slate-800/80 p-3.5 rounded-2xl flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-slate-400 mb-1 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-teal-400" />
            <span>{t('studyHours')}</span>
          </span>
          <span className="text-xl font-black text-teal-300">
            {studyHours} <span className="text-xs font-normal text-slate-400">{t('hours')}</span>
          </span>
        </div>

        <div className="bg-[#101726] border border-slate-800/80 p-3.5 rounded-2xl flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-slate-400 mb-1 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>{t('reviewHours')}</span>
          </span>
          <span className="text-xl font-black text-indigo-300">
            {reviewHours} <span className="text-xs font-normal text-slate-400">{t('hours')}</span>
          </span>
        </div>

        <div className="col-span-2 lg:col-span-1 bg-[#101726] border border-slate-800/80 p-3.5 rounded-2xl flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-slate-400 mb-1 flex items-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
            <span>{t('absentHours')}</span>
          </span>
          <span className="text-xl font-black text-amber-300">
            {absentHours} <span className="text-xs font-normal text-slate-400">{t('hours')}</span>
          </span>
        </div>
      </div>

      {/* Sub-view Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setScheduleSubView('today')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition ${
            scheduleSubView === 'today'
              ? 'bg-teal-500 text-slate-950 shadow-md shadow-teal-500/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>{t('subviewToday')}</span>
        </button>

        <button
          onClick={() => setScheduleSubView('week')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition ${
            scheduleSubView === 'week'
              ? 'bg-teal-500 text-slate-950 shadow-md shadow-teal-500/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>{t('subviewWeek')}</span>
        </button>

        <button
          onClick={() => setScheduleSubView('tasks')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition ${
            scheduleSubView === 'tasks'
              ? 'bg-teal-500 text-slate-950 shadow-md shadow-teal-500/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <CheckSquare className="w-4 h-4" />
          <span>{t('subviewTasks')}</span>
        </button>
      </div>

      {/* Render Active Sub-View */}
      {scheduleSubView === 'today' && <DayTimeline />}
      {scheduleSubView === 'week' && <WeekGrid />}
      {scheduleSubView === 'tasks' && <WeeklyTasks />}
    </div>
  );
};
