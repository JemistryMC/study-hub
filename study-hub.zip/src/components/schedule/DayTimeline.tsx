import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ScheduleEvent, SlotType } from '../../types/academic';
import { Clock, Plus, CheckCircle2, AlertCircle, Edit, Trash2, Calendar, MapPin } from 'lucide-react';

export const DayTimeline: React.FC = () => {
  const {
    scheduleEvents,
    plannerPrefs,
    subjects,
    setAddSlotModalOpen,
    setEditingSlot,
    updateScheduleEvent,
    deleteScheduleEvent,
    language,
    t
  } = useApp();

  const [activeDay, setActiveDay] = useState<number>(() => new Date().getDay());

  const daysArabic = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  const daysEnglish = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  // 6 = Sat, 0 = Sun, 1 = Mon, 2 = Tue, 3 = Wed, 4 = Thu, 5 = Fri
  const dayOrder = [6, 0, 1, 2, 3, 4, 5];

  const currentDayEvents = scheduleEvents
    .filter(ev => ev.day === activeDay)
    .sort((a, b) => a.startHour * 60 + a.startMinute - (b.startHour * 60 + b.startMinute));

  const formatSlotTime = (h: number, m: number) => {
    const period = h >= 12 ? (language === 'ar' ? 'م' : 'PM') : language === 'ar' ? 'ص' : 'AM';
    const displayH = h % 12 || 12;
    return `${displayH}:${m < 10 ? '0' : ''}${m} ${period}`;
  };

  const getSlotTypeStyle = (type: SlotType) => {
    switch (type) {
      case 'college':
        return 'bg-sky-500/10 border-sky-500/40 text-sky-300';
      case 'study':
        return 'bg-teal-500/10 border-teal-500/40 text-teal-300';
      case 'review':
        return 'bg-indigo-500/10 border-indigo-500/40 text-indigo-300';
      case 'absent':
        return 'bg-amber-500/10 border-amber-500/40 text-amber-300';
      case 'exam':
        return 'bg-rose-500/10 border-rose-500/40 text-rose-300';
      default:
        return 'bg-slate-800 border-slate-700 text-slate-300';
    }
  };

  const getSlotTypeLabel = (type: SlotType) => {
    switch (type) {
      case 'college':
        return language === 'ar' ? 'محاضرة كلية' : 'College';
      case 'study':
        return language === 'ar' ? 'مذاكرة ذاتية' : 'Self Study';
      case 'review':
        return language === 'ar' ? 'مراجعة ذكية' : 'Smart Review';
      case 'absent':
        return language === 'ar' ? 'فترة غياب' : 'Absent';
      case 'exam':
        return language === 'ar' ? 'امتحان / كويز' : 'Exam';
      default:
        return type;
    }
  };

  return (
    <div className="space-y-5">
      {/* Day Selector Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 bg-[#0f1624] p-2 rounded-2xl border border-slate-800">
        {dayOrder.map(d => {
          const isSelected = activeDay === d;
          const isRealToday = new Date().getDay() === d;
          const dayCount = scheduleEvents.filter(e => e.day === d).length;

          return (
            <button
              key={d}
              onClick={() => setActiveDay(d)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                isSelected
                  ? 'bg-gradient-to-r from-teal-500 to-teal-600 text-slate-950 shadow-md shadow-teal-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <span>{language === 'ar' ? daysArabic[d] : daysEnglish[d]}</span>
              {isRealToday && (
                <span
                  className={`text-[9px] px-1.5 py-0.2 rounded-full ${
                    isSelected ? 'bg-slate-950/20 text-slate-950' : 'bg-teal-500/20 text-teal-300'
                  }`}
                >
                  {t('subviewToday')}
                </span>
              )}
              {dayCount > 0 && (
                <span
                  className={`text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold ${
                    isSelected ? 'bg-slate-950/20 text-slate-950' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {dayCount}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Timeline Events Container */}
      <div className="bg-[#101726] border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-teal-400" />
            <h3 className="text-base font-extrabold text-white">
              {language === 'ar' ? daysArabic[activeDay] : daysEnglish[activeDay]}
            </h3>
            <span className="text-xs text-slate-500">
              ({currentDayEvents.length} {language === 'ar' ? 'فترات مجدولة' : 'scheduled slots'})
            </span>
          </div>

          <button
            onClick={() => {
              setEditingSlot({
                id: '',
                title: '',
                day: activeDay,
                startHour: 10,
                startMinute: 0,
                endHour: 12,
                endMinute: 0,
                type: 'study'
              });
              setAddSlotModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-500/10 text-teal-300 hover:bg-teal-500/20 border border-teal-500/30 text-xs font-bold transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{t('addSession')}</span>
          </button>
        </div>

        {currentDayEvents.length === 0 ? (
          <div className="text-center py-16 px-4">
            <Clock className="w-10 h-10 text-slate-600 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-400 mb-3">{t('noSlotsToday')}</p>
            <button
              onClick={() => {
                setEditingSlot({
                  id: '',
                  title: '',
                  day: activeDay,
                  startHour: 9,
                  startMinute: 0,
                  endHour: 11,
                  endMinute: 0,
                  type: 'study'
                });
                setAddSlotModalOpen(true);
              }}
              className="px-4 py-2 bg-teal-500 text-slate-950 font-bold rounded-xl text-xs inline-flex items-center gap-1.5 shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>{t('addSession')}</span>
            </button>
          </div>
        ) : (
          <div className="relative border-l-2 rtl:border-r-2 rtl:border-l-0 border-slate-800 space-y-4 pl-4 rtl:pr-4 rtl:pl-0 my-2">
            {currentDayEvents.map(event => {
              const sub = subjects.find(s => s.id === event.subjectId);
              const typeStyle = getSlotTypeStyle(event.type);
              const typeLabel = getSlotTypeLabel(event.type);

              return (
                <div
                  key={event.id}
                  className={`relative p-4 rounded-2xl border transition-all hover:shadow-lg ${typeStyle}`}
                >
                  {/* Timeline bullet */}
                  <span
                    className="absolute -left-[23px] rtl:-right-[23px] rtl:left-auto top-5 w-3.5 h-3.5 rounded-full border-2 border-[#101726] shadow-sm"
                    style={{ backgroundColor: sub?.color || '#2dd4bf' }}
                  />

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-900/80 border border-slate-700/60">
                          {typeLabel}
                        </span>

                        {sub && (
                          <span className="text-xs font-bold text-slate-200">
                            {sub.name}
                          </span>
                        )}
                      </div>

                      <h4
                        className={`text-base font-extrabold ${
                          event.completed ? 'line-through text-slate-500' : 'text-white'
                        }`}
                      >
                        {event.title}
                      </h4>

                      <div className="flex items-center gap-2 text-xs font-semibold text-slate-400">
                        <Clock className="w-3.5 h-3.5" />
                        <span>
                          {formatSlotTime(event.startHour, event.startMinute)} —{' '}
                          {formatSlotTime(event.endHour, event.endMinute)}
                        </span>
                      </div>

                      {event.notes && (
                        <p className="text-xs text-slate-400 bg-slate-950/40 p-2 rounded-xl mt-1 border border-slate-800/40">
                          {event.notes}
                        </p>
                      )}
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-1.5 self-end sm:self-center shrink-0">
                      <button
                        onClick={() => updateScheduleEvent(event.id, { completed: !event.completed })}
                        className={`p-2 rounded-xl transition ${
                          event.completed ? 'bg-teal-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-300 hover:text-white'
                        }`}
                        title={event.completed ? t('markIncomplete') : t('markComplete')}
                      >
                        <CheckCircle2 className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => {
                          setEditingSlot(event);
                          setAddSlotModalOpen(true);
                        }}
                        className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition"
                        title={t('smartSetup')}
                      >
                        <Edit className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => {
                          if (window.confirm(t('confirmDelete'))) {
                            deleteScheduleEvent(event.id);
                          }
                        }}
                        className="p-2 rounded-xl bg-slate-800 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition"
                        title={t('delete')}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
