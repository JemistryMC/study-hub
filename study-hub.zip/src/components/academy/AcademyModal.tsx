import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Sparkles,
  BookOpen,
  CheckCircle2,
  XCircle,
  RotateCw,
  ChevronRight,
  ChevronLeft,
  Award,
  Layers,
  HelpCircle,
  Calculator,
  RefreshCw
} from 'lucide-react';
import { Flashcard, QuizQuestion } from '../../types/academic';

export const AcademyModal: React.FC = () => {
  const {
    isAcademyOpen,
    setIsAcademyOpen,
    flashcards,
    updateFlashcardScore,
    quizzes,
    t,
    currentLang,
    showToast
  } = useApp();

  const [activeTab, setActiveTab] = useState<'flashcards' | 'quiz' | 'sandbox'>('flashcards');

  // Flashcards state
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  // Quiz state
  const [currentQuizIndex, setCurrentQuizIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [answeredState, setAnsweredState] = useState<Record<number, number>>({});
  const [score, setScore] = useState(0);

  // Medical Sandbox state
  const [patientWeightKg, setPatientWeightKg] = useState<number>(70);
  const [dosePerKgMg, setDosePerKgMg] = useState<number>(15);
  const [infusionDurationHours, setInfusionDurationHours] = useState<number>(8);

  if (!isAcademyOpen) return null;

  const currentCard: Flashcard | undefined = flashcards[currentCardIndex];
  const currentQuiz: QuizQuestion | undefined = quizzes[currentQuizIndex];

  // Flashcards navigation
  const handleCardNext = () => {
    setIsFlipped(false);
    setCurrentCardIndex((i) => (i + 1) % flashcards.length);
  };

  const handleCardPrev = () => {
    setIsFlipped(false);
    setCurrentCardIndex((i) => (i - 1 + flashcards.length) % flashcards.length);
  };

  const handleRateCard = (rating: 'easy' | 'hard') => {
    if (!currentCard) return;
    updateFlashcardScore(currentCard.id, rating);
    showToast(
      rating === 'easy'
        ? (currentLang === 'ar' ? 'ممتاز! تم تثبيت المفهوم' : 'Great! Concept mastered')
        : (currentLang === 'ar' ? 'ستتم مراجعتها قريباً' : 'Scheduled for review'),
      rating === 'easy' ? 'success' : 'info'
    );
    handleCardNext();
  };

  // Quiz navigation & scoring
  const handleSelectOption = (optIndex: number) => {
    if (answeredState[currentQuizIndex] !== undefined) return;
    setSelectedAnswer(optIndex);
    const isCorrect = optIndex === currentQuiz?.correctIndex;
    setAnsweredState((prev) => ({ ...prev, [currentQuizIndex]: optIndex }));
    if (isCorrect) {
      setScore((s) => s + 1);
      showToast(currentLang === 'ar' ? 'إجابة صحيحة!' : 'Correct answer!', 'success');
    } else {
      showToast(currentLang === 'ar' ? 'إجابة خاطئة' : 'Incorrect answer', 'error');
    }
  };

  const handleNextQuiz = () => {
    setSelectedAnswer(null);
    setCurrentQuizIndex((i) => Math.min(quizzes.length - 1, i + 1));
  };

  const handleResetQuiz = () => {
    setAnsweredState({});
    setSelectedAnswer(null);
    setCurrentQuizIndex(0);
    setScore(0);
  };

  // Medical calculations
  const totalDoseMg = patientWeightKg * dosePerKgMg;
  const infusionRateMgPerHour = infusionDurationHours > 0 ? (totalDoseMg / infusionDurationHours).toFixed(1) : '0';
  const dropsPerMinStandard = infusionDurationHours > 0 ? ((totalDoseMg / 250) * 20 / (infusionDurationHours * 60)).toFixed(1) : '0';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-slate-950/80 backdrop-blur-sm animate-fadeIn"
      dir={currentLang === 'ar' ? 'rtl' : 'ltr'}
    >
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white flex items-center gap-2">
                {t('interactiveAcademy')}
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-purple-900/40 text-purple-300 border border-purple-700/50">
                  Exo AI & Spaced Repetition
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                {currentLang === 'ar' ? 'بطاقات استذكار ذكية، اختبارات تفاعلية، ومختبر المحاكاة السريرية' : 'Smart flashcards, interactive quizzes, and clinical simulation sandbox'}
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsAcademyOpen(false)}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="px-6 pt-4 border-b border-slate-800 flex items-center gap-3 bg-slate-900">
          <button
            onClick={() => setActiveTab('flashcards')}
            className={`flex items-center gap-2 pb-3 px-3 font-bold text-sm border-b-2 transition-all ${
              activeTab === 'flashcards'
                ? 'border-purple-500 text-purple-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-4 h-4" />
            {t('flashcards')} ({flashcards.length})
          </button>

          <button
            onClick={() => setActiveTab('quiz')}
            className={`flex items-center gap-2 pb-3 px-3 font-bold text-sm border-b-2 transition-all ${
              activeTab === 'quiz'
                ? 'border-purple-500 text-purple-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            {t('quizzes')} ({quizzes.length})
          </button>

          <button
            onClick={() => setActiveTab('sandbox')}
            className={`flex items-center gap-2 pb-3 px-3 font-bold text-sm border-b-2 transition-all ${
              activeTab === 'sandbox'
                ? 'border-purple-500 text-purple-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Calculator className="w-4 h-4" />
            {currentLang === 'ar' ? 'المختبر السريري' : 'Clinical Sandbox'}
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-950/40">
          {/* TAB 1: FLASHCARDS */}
          {activeTab === 'flashcards' && (
            <div className="flex flex-col items-center max-w-xl mx-auto py-4">
              {currentCard ? (
                <>
                  <div className="w-full flex items-center justify-between text-xs text-slate-400 mb-3">
                    <span>
                      {t('flashcards')} {currentCardIndex + 1} / {flashcards.length}
                    </span>
                    <span className="font-mono bg-slate-800 px-2 py-0.5 rounded-full text-purple-300">
                      Mastery: {currentCard.box || 1}/5
                    </span>
                  </div>

                  {/* 3D Interactive Flip Card */}
                  <div
                    onClick={() => setIsFlipped(!isFlipped)}
                    className="w-full min-h-[260px] bg-slate-900 border-2 border-slate-800 hover:border-purple-500/50 rounded-3xl p-8 flex flex-col justify-between cursor-pointer shadow-xl transition-all duration-300 group select-none relative overflow-hidden"
                  >
                    <div className="flex justify-between items-center text-xs text-slate-500">
                      <span className="font-bold uppercase tracking-wider text-purple-400">
                        {isFlipped ? (currentLang === 'ar' ? 'الإجابة والتفسير' : 'Answer & Rationale') : (currentLang === 'ar' ? 'سؤال البطاقة' : 'Question')}
                      </span>
                      <RotateCw className="w-4 h-4 text-slate-500 group-hover:rotate-180 transition-transform duration-500" />
                    </div>

                    <div className="my-6 text-center">
                      <p className="text-xl md:text-2xl font-black text-white leading-relaxed">
                        {isFlipped ? (currentCard.answer || currentCard.back) : (currentCard.question || currentCard.front)}
                      </p>
                    </div>

                    <div className="text-center text-xs text-slate-500 italic">
                      {isFlipped ? (currentLang === 'ar' ? 'انقر للعودة للسؤال' : 'Click to flip back') : (currentLang === 'ar' ? 'انقر لإظهار الإجابة' : 'Click to reveal answer')}
                    </div>
                  </div>

                  {/* Rating Controls & Next / Prev */}
                  <div className="w-full mt-6 flex flex-col gap-3">
                    {isFlipped && (
                      <div className="grid grid-cols-2 gap-3">
                        <button
                          onClick={() => handleRateCard('hard')}
                          className="py-3 px-4 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800 text-rose-300 rounded-2xl font-bold text-sm transition-all flex items-center justify-center gap-2"
                        >
                          <XCircle className="w-4 h-4" />
                          {t('hard')} (Repeat soon)
                        </button>
                        <button
                          onClick={() => handleRateCard('easy')}
                          className="py-3 px-4 bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-800 text-emerald-300 rounded-2xl font-bold text-sm transition-all flex items-center justify-center gap-2"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          {t('easy')} (Mastered)
                        </button>
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-2">
                      <button
                        onClick={handleCardPrev}
                        className="p-2.5 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-xl transition-all flex items-center gap-1.5 text-xs font-semibold"
                      >
                        <ChevronRight className={`w-4 h-4 ${currentLang === 'ar' ? '' : 'rotate-180'}`} />
                        {currentLang === 'ar' ? 'السابق' : 'Previous'}
                      </button>

                      <button
                        onClick={handleCardNext}
                        className="p-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl transition-all flex items-center gap-1.5 text-xs font-bold"
                      >
                        {currentLang === 'ar' ? 'التالي' : 'Next'}
                        <ChevronLeft className={`w-4 h-4 ${currentLang === 'ar' ? '' : 'rotate-180'}`} />
                      </button>
                    </div>
                  </div>
                </>
              ) : (
                <div className="text-center py-12 text-slate-400">
                  <BookOpen className="w-12 h-12 mx-auto text-slate-600 mb-3" />
                  <p>{currentLang === 'ar' ? 'لا توجد بطاقات متاحة حالياً' : 'No flashcards available.'}</p>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: QUIZZES */}
          {activeTab === 'quiz' && (
            <div className="max-w-xl mx-auto py-4">
              {currentQuiz ? (
                <div>
                  {/* Quiz Header */}
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-4">
                    <span>
                      {t('quizzes')} {currentQuizIndex + 1} / {quizzes.length}
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-purple-400">
                        Score: {score} / {Object.keys(answeredState).length}
                      </span>
                      <button
                        onClick={handleResetQuiz}
                        className="p-1 text-slate-400 hover:text-white transition-all"
                        title="Reset Quiz"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Question Box */}
                  <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 mb-5 shadow-lg">
                    <h3 className="text-lg font-bold text-white leading-relaxed">{currentQuiz.question}</h3>
                  </div>

                  {/* Multiple Choice Options */}
                  <div className="space-y-3">
                    {currentQuiz.options.map((option, idx) => {
                      const isAnswered = answeredState[currentQuizIndex] !== undefined;
                      const isUserPick = answeredState[currentQuizIndex] === idx;
                      const isCorrect = idx === currentQuiz.correctIndex;

                      let btnStyle = 'bg-slate-900 border-slate-800 hover:border-purple-500/50 text-slate-200';
                      if (isAnswered) {
                        if (isCorrect) {
                          btnStyle = 'bg-emerald-950/50 border-emerald-500 text-emerald-200';
                        } else if (isUserPick) {
                          btnStyle = 'bg-rose-950/50 border-rose-500 text-rose-200';
                        } else {
                          btnStyle = 'bg-slate-900/50 border-slate-800/50 text-slate-500 opacity-60';
                        }
                      }

                      return (
                        <button
                          key={idx}
                          onClick={() => handleSelectOption(idx)}
                          disabled={isAnswered}
                          className={`w-full text-right p-4 rounded-2xl border font-medium text-sm transition-all flex items-center justify-between gap-3 ${btnStyle} ${
                            currentLang === 'ar' ? 'text-right' : 'text-left'
                          }`}
                        >
                          <span className="flex-1">{option}</span>
                          {isAnswered && isCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />}
                          {isAnswered && isUserPick && !isCorrect && (
                            <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {/* Explanation Banner */}
                  {answeredState[currentQuizIndex] !== undefined && currentQuiz.explanation && (
                    <div className="mt-5 p-4 bg-purple-950/30 border border-purple-800/40 rounded-2xl text-xs text-purple-200 animate-fadeIn">
                      <span className="font-bold block mb-1 text-purple-300">
                        💡 {currentLang === 'ar' ? 'التفسير العلمي السريري' : 'Clinical Rationale'}:
                      </span>
                      {currentQuiz.explanation}
                    </div>
                  )}

                  {/* Next Question Button */}
                  <div className="mt-6 flex justify-end">
                    {currentQuizIndex < quizzes.length - 1 ? (
                      <button
                        onClick={handleNextQuiz}
                        disabled={answeredState[currentQuizIndex] === undefined}
                        className="px-6 py-2.5 bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-white rounded-xl font-bold text-sm transition-all flex items-center gap-2"
                      >
                        {currentLang === 'ar' ? 'السؤال التالي' : 'Next Question'}
                        <ChevronLeft className={`w-4 h-4 ${currentLang === 'ar' ? '' : 'rotate-180'}`} />
                      </button>
                    ) : (
                      <div className="flex items-center gap-3">
                        <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                          <Award className="w-4 h-4" /> {currentLang === 'ar' ? 'اكتمل الاختبار!' : 'Quiz completed!'}
                        </span>
                        <button
                          onClick={handleResetQuiz}
                          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold"
                        >
                          {currentLang === 'ar' ? 'إعادة الاختبار' : 'Retake Quiz'}
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="text-center py-12 text-slate-400">
                  <p>{currentLang === 'ar' ? 'لا توجد اختبارات متاحة' : 'No quizzes available.'}</p>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: CLINICAL SANDBOX */}
          {activeTab === 'sandbox' && (
            <div className="max-w-2xl mx-auto py-2 space-y-6">
              <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
                <h3 className="font-black text-white text-base mb-1 flex items-center gap-2">
                  <Calculator className="w-4 h-4 text-purple-400" />
                  {currentLang === 'ar' ? 'محاكي الجرعات السريرية ومعدل التسريب' : 'Clinical Dosage & Infusion Rate Calculator'}
                </h3>
                <p className="text-xs text-slate-400">
                  {currentLang === 'ar' ? 'أداة مساعدة لحساب كمية الدواء المطلوبة، معدل التسريب بالساعة، وعدد النقاط بالدقيقة.' : 'Interactive tool for calculating required drug dosage, hourly infusion rates, and IV drops.'}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
                  <label className="block text-xs font-semibold text-slate-400 mb-2">
                    {currentLang === 'ar' ? 'وزن المريض (كغ)' : 'Patient Weight (kg)'}
                  </label>
                  <input
                    type="number"
                    value={patientWeightKg}
                    onChange={(e) => setPatientWeightKg(Number(e.target.value))}
                    min={1}
                    max={300}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono font-bold outline-none focus:border-purple-500"
                  />
                </div>

                <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
                  <label className="block text-xs font-semibold text-slate-400 mb-2">
                    {currentLang === 'ar' ? 'الجرعة (ملغ / كغ)' : 'Dose (mg/kg)'}
                  </label>
                  <input
                    type="number"
                    value={dosePerKgMg}
                    onChange={(e) => setDosePerKgMg(Number(e.target.value))}
                    min={0.1}
                    max={500}
                    step={0.5}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono font-bold outline-none focus:border-purple-500"
                  />
                </div>

                <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
                  <label className="block text-xs font-semibold text-slate-400 mb-2">
                    {currentLang === 'ar' ? 'مدة التسريب (ساعات)' : 'Infusion Time (hrs)'}
                  </label>
                  <input
                    type="number"
                    value={infusionDurationHours}
                    onChange={(e) => setInfusionDurationHours(Number(e.target.value))}
                    min={0.5}
                    max={48}
                    step={0.5}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono font-bold outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              {/* Calculated Results */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-5 bg-purple-950/30 border border-purple-800/40 rounded-2xl text-center">
                  <span className="text-xs text-purple-300 font-semibold block mb-1">
                    {currentLang === 'ar' ? 'الجرعة الكلية المحسوبة' : 'Total Calculated Dose'}
                  </span>
                  <span className="text-2xl font-black text-purple-400 font-mono">{totalDoseMg} mg</span>
                </div>

                <div className="p-5 bg-blue-950/30 border border-blue-800/40 rounded-2xl text-center">
                  <span className="text-xs text-blue-300 font-semibold block mb-1">
                    {currentLang === 'ar' ? 'معدل التسريب بالساعة' : 'Hourly Infusion Rate'}
                  </span>
                  <span className="text-2xl font-black text-blue-400 font-mono">{infusionRateMgPerHour} mg/h</span>
                </div>

                <div className="p-5 bg-emerald-950/30 border border-emerald-800/40 rounded-2xl text-center">
                  <span className="text-xs text-emerald-300 font-semibold block mb-1">
                    {currentLang === 'ar' ? 'معدل التنقيط المعياري' : 'Standard IV Drips'}
                  </span>
                  <span className="text-2xl font-black text-emerald-400 font-mono">{dropsPerMinStandard} gtt/min</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
