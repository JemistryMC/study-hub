import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Sparkles, BookOpen, Calendar, Clock, Palette } from 'lucide-react';

export const SmartSubjectModal: React.FC = () => {
  const {
    smartSubjectModalOpen,
    setSmartSubjectModalOpen,
    editingSubject,
    setEditingSubject,
    addSubject,
    updateSubject,
    language,
    t
  } = useApp();

  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [creditHours, setCreditHours] = useState(3);
  const [examDate, setExamDate] = useState('');
  const [examTime, setExamTime] = useState('09:00');
  const [color, setColor] = useState('#2dd4bf');

  const colorPalette = ['#2dd4bf', '#818cf8', '#06b6d4', '#f43f5e', '#f59e0b', '#10b981', '#ec4899', '#a855f7'];

  const academicPresets = [
    { name: 'علم الأدوية (Pharmacology)', code: 'PHAR-301', color: '#2dd4bf' },
    { name: 'الكيمياء الحيوية (Biochemistry)', code: 'BIOC-202', color: '#818cf8' },
    { name: 'علم الأمراض (Pathology)', code: 'PATH-201', color: '#f43f5e' },
    { name: 'الأحياء الدقيقة (Microbiology)', code: 'MCRO-203', color: '#10b981' },
    { name: 'الصيدلانيات (Pharmaceutics)', code: 'PHTC-201', color: '#06b6d4' },
    { name: 'التشريح وعلم الوظائف (Anatomy & Physio)', code: 'ANAT-101', color: '#f59e0b' }
  ];

  useEffect(() => {
    if (editingSubject) {
      setName(editingSubject.name);
      setCode(editingSubject.code || '');
      setCreditHours(editingSubject.creditHours || 3);
      setExamDate(editingSubject.examDate || '');
      setExamTime(editingSubject.examTime || '09:00');
      setColor(editingSubject.color || '#2dd4bf');
    } else {
      setName('');
      setCode('');
      setCreditHours(3);
      setExamDate('');
      setExamTime('09:00');
      setColor('#2dd4bf');
    }
  }, [editingSubject, smartSubjectModalOpen]);

  if (!smartSubjectModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (editingSubject) {
      updateSubject(editingSubject.id, {
        name: name.trim(),
        code: code.trim(),
        creditHours,
        examDate,
        examTime,
        color
      });
    } else {
      addSubject({
        name: name.trim(),
        code: code.trim(),
        creditHours,
        examDate,
        examTime,
        color
      });
    }
    setSmartSubjectModalOpen(false);
    setEditingSubject(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#0e1626] border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-2xl space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3.5">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center border border-teal-500/20">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">
                {editingSubject ? (language === 'ar' ? 'تعديل بيانات المادة' : 'Edit Subject') : t('addSubject')}
              </h3>
              <p className="text-xs text-slate-400">{t('smartSetup')}</p>
            </div>
          </div>

          <button
            onClick={() => {
              setSmartSubjectModalOpen(false);
              setEditingSubject(null);
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Quick Presets if adding new */}
          {!editingSubject && (
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-2">
                {language === 'ar' ? 'قوالب سريعة مقترحة للتخصصات الطبية:' : 'Quick Medical Presets:'}
              </label>
              <div className="flex flex-wrap gap-1.5">
                {academicPresets.map(preset => (
                  <button
                    key={preset.code}
                    type="button"
                    onClick={() => {
                      setName(preset.name);
                      setCode(preset.code);
                      setColor(preset.color);
                    }}
                    className="text-[11px] font-medium px-2.5 py-1 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 hover:border-teal-500/40 transition"
                  >
                    {preset.name.split(' (')[0]}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Name & Code */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {language === 'ar' ? 'اسم المادة الدراسية *' : 'Subject Name *'}
              </label>
              <input
                type="text"
                required
                placeholder={language === 'ar' ? 'مثلاً: علم الأدوية (Pharmacology I)' : 'e.g. Pharmacology I'}
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {language === 'ar' ? 'كود المادة' : 'Course Code'}
              </label>
              <input
                type="text"
                placeholder="PHAR-301"
                value={code}
                onChange={e => setCode(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-teal-500 font-mono"
              />
            </div>
          </div>

          {/* Exam Target Date, Time & Credit Hours */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {language === 'ar' ? 'تاريخ الامتحان المستهدف' : 'Target Exam Date'}
              </label>
              <input
                type="date"
                value={examDate}
                onChange={e => setExamDate(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-teal-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {language === 'ar' ? 'وقت الامتحان' : 'Exam Time'}
              </label>
              <input
                type="time"
                value={examTime}
                onChange={e => setExamTime(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-teal-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {t('creditHours')}
              </label>
              <input
                type="number"
                min="1"
                max="8"
                value={creditHours}
                onChange={e => setCreditHours(parseInt(e.target.value) || 3)}
                className="w-full bg-slate-900 border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-teal-500"
              />
            </div>
          </div>

          {/* Color Picker */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">{language === 'ar' ? 'اللون المميز للمادة:' : 'Course Color Theme:'}</label>
            <div className="flex items-center gap-2">
              {colorPalette.map(c => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setColor(c)}
                  className={`w-7 h-7 rounded-full transition-transform ${
                    color === c ? 'scale-125 ring-2 ring-white shadow-lg' : 'opacity-80 hover:opacity-100'
                  }`}
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>
          </div>

          {/* Submit / Cancel */}
          <div className="pt-3 border-t border-slate-800/80 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={() => {
                setSmartSubjectModalOpen(false);
                setEditingSubject(null);
              }}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition"
            >
              {t('cancel')}
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-400 hover:to-teal-500 text-slate-950 font-bold rounded-xl text-xs shadow-md shadow-teal-500/20 transition"
            >
              {t('save')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
