import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Subject, LectureStatus, Lecture } from '../../types/academic';
import {
  ArrowRight,
  ArrowLeft,
  Plus,
  BookOpen,
  CheckCircle2,
  Clock,
  Layers,
  Music2,
  FileText,
  Trash2,
  Edit,
  AlertCircle,
  HelpCircle,
  Calendar,
  Sparkles
} from 'lucide-react';

interface Props {
  subject: Subject;
  onBack: () => void;
}

export const SubjectDetailView: React.FC<Props> = ({ subject, onBack }) => {
  const {
    language,
    t,
    deleteSubject,
    setEditingSubject,
    setSmartSubjectModalOpen,
    addLecture,
    updateLecture,
    deleteLecture,
    toggleLectureComplete,
    openLectureStudio,
    setMergedStudioSubjectId,
    setMergedAudioPlaying
  } = useApp();

  const [newGroupTitle, setNewGroupTitle] = useState('');
  const [addingGroup, setAddingGroup] = useState(false);
  const [activeNewLecGroup, setActiveNewLecGroup] = useState<number | null>(null);
  const [newLecTitle, setNewLecTitle] = useState('');
  const [newLecPath, setNewLecPath] = useState('');

  const totalLecs = subject.groups.reduce((acc, g) => acc + g.lectures.length, 0);
  const doneLecs = subject.groups.reduce((acc, g) => acc + g.lectures.filter(l => l.completed).length, 0);
  const progress = totalLecs > 0 ? Math.round((doneLecs / totalLecs) * 100) : 0;

  const handleAddGroupSubmit = () => {
    if (!newGroupTitle.trim()) return;
    const newGrp = {
      id: Date.now(),
      name: newGroupTitle.trim(),
      lectures: []
    };
    subject.groups.push(newGrp);
    setNewGroupTitle('');
    setAddingGroup(false);
  };

  const handleAddLecSubmit = (groupId: number) => {
    if (!newLecTitle.trim()) return;
    addLecture(subject.id, groupId, {
      title: newLecTitle.trim(),
      path: newLecPath.trim() || `${newLecTitle.trim().replace(/\s+/g, '_')}.pdf`
    });
    setNewLecTitle('');
    setNewLecPath('');
    setActiveNewLecGroup(null);
  };

  return (
    <div className="space-y-6 pb-20 md:pb-12 animate-in fade-in duration-300">
      {/* Top Navigation & Breadcrumbs */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <button
          onClick={onBack}
          className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 text-xs font-bold transition"
        >
          {language === 'ar' ? <ArrowRight className="w-4 h-4" /> : <ArrowLeft className="w-4 h-4" />}
          <span>{t('subjectsTitle')}</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setMergedStudioSubjectId(subject.id);
              setMergedAudioPlaying(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-500/10 text-teal-300 hover:bg-teal-500/20 border border-teal-500/30 text-xs font-bold transition"
          >
            <Music2 className="w-4 h-4" />
            <span>{t('mergedAudioStudio')}</span>
          </button>

          <button
            onClick={() => {
              setEditingSubject(subject);
              setSmartSubjectModalOpen(true);
            }}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
            title={t('smartSetup')}
          >
            <Edit className="w-4 h-4" />
          </button>

          <button
            onClick={() => {
              if (window.confirm(t('confirmDelete'))) {
                deleteSubject(subject.id);
              }
            }}
            className="p-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 transition"
            title={t('delete')}
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Subject Header Card */}
      <div className="bg-gradient-to-r from-slate-900 via-[#10182b] to-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2.5">
              <span className="w-3.5 h-3.5 rounded-full shadow-md" style={{ backgroundColor: subject.color || '#2dd4bf' }} />
              {subject.code && (
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-lg bg-slate-800 text-slate-300 border border-slate-700/60">
                  {subject.code}
                </span>
              )}
              {subject.creditHours && (
                <span className="text-xs text-slate-400 font-semibold">
                  {subject.creditHours} {t('creditHours')}
                </span>
              )}
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">{subject.name}</h1>

            {subject.examDate && (
              <div className="flex items-center gap-2 text-xs text-amber-300 font-semibold pt-1">
                <Calendar className="w-4 h-4 text-amber-400" />
                <span>
                  {t('examCountDown')}: {subject.examDate} ({subject.examTime || '09:00'})
                </span>
              </div>
            )}
          </div>

          {/* Quick Metrics */}
          <div className="flex items-center gap-4 bg-slate-900/80 p-4 rounded-2xl border border-slate-800/80">
            <div className="text-center px-2">
              <div className="text-xs text-slate-400 mb-0.5">{t('progressRate')}</div>
              <div className="text-2xl font-black text-teal-400">{progress}%</div>
            </div>
            <div className="w-px h-8 bg-slate-800" />
            <div className="text-center px-2">
              <div className="text-xs text-slate-400 mb-0.5">{t('completedCount')}</div>
              <div className="text-xl font-bold text-slate-200">
                {doneLecs} / {totalLecs}
              </div>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden mt-6">
          <div
            className="h-full bg-gradient-to-r from-teal-500 to-sky-400 rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Units & Lectures List */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-200 flex items-center gap-2">
            <Layers className="w-5 h-5 text-teal-400" />
            <span>{t('unitsCount')}</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-400">{subject.groups.length}</span>
          </h2>

          <button
            onClick={() => setAddingGroup(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700 transition"
          >
            <Plus className="w-4 h-4" />
            <span>{t('addGroup')}</span>
          </button>
        </div>

        {/* Add Group Inline Form */}
        {addingGroup && (
          <div className="bg-slate-900/90 border border-teal-500/40 rounded-2xl p-4 flex flex-col sm:flex-row items-center gap-3">
            <input
              type="text"
              placeholder={language === 'ar' ? 'اسم الوحدة / الشابتر (مثلاً: الوحدة 2: الأدوية القلبية)' : 'Unit Name'}
              value={newGroupTitle}
              onChange={e => setNewGroupTitle(e.target.value)}
              className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
            />
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={handleAddGroupSubmit}
                className="flex-1 sm:flex-none px-4 py-2 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold rounded-xl text-xs transition"
              >
                {t('save')}
              </button>
              <button
                onClick={() => setAddingGroup(false)}
                className="flex-1 sm:flex-none px-3 py-2 bg-slate-800 text-slate-400 hover:text-white rounded-xl text-xs transition"
              >
                {t('cancel')}
              </button>
            </div>
          </div>
        )}

        {/* Groups Cards */}
        {subject.groups.map(group => {
          return (
            <div key={group.id} className="bg-[#101726] border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-teal-400 shadow-sm" />
                  <h3 className="text-base font-extrabold text-white">{group.name}</h3>
                  <span className="text-xs text-slate-500 font-semibold">({group.lectures.length} محاضرات)</span>
                </div>

                <button
                  onClick={() => setActiveNewLecGroup(activeNewLecGroup === group.id ? null : group.id)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-500/10 text-teal-300 hover:bg-teal-500/20 border border-teal-500/30 text-xs font-bold transition"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{t('addLecture')}</span>
                </button>
              </div>

              {/* Add Lecture Form within Group */}
              {activeNewLecGroup === group.id && (
                <div className="bg-slate-900/90 border border-teal-500/30 rounded-xl p-3.5 space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <input
                      type="text"
                      placeholder={language === 'ar' ? 'عنوان المحاضرة (مثال: Lec 3 - ACE Inhibitors)' : 'Lecture Title'}
                      value={newLecTitle}
                      onChange={e => setNewLecTitle(e.target.value)}
                      className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
                    />
                    <input
                      type="text"
                      placeholder={language === 'ar' ? 'اسم ملف الـ PDF (مثال: Lec3_Pharmacology.pdf)' : 'PDF Filename'}
                      value={newLecPath}
                      onChange={e => setNewLecPath(e.target.value)}
                      className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
                    />
                  </div>

                  <div className="flex items-center justify-end gap-2">
                    <button
                      onClick={() => handleAddLecSubmit(group.id)}
                      className="px-3.5 py-1.5 bg-teal-500 text-slate-950 font-bold rounded-xl text-xs"
                    >
                      {t('save')}
                    </button>
                    <button
                      onClick={() => setActiveNewLecGroup(null)}
                      className="px-3 py-1.5 bg-slate-800 text-slate-400 hover:text-white rounded-xl text-xs"
                    >
                      {t('cancel')}
                    </button>
                  </div>
                </div>
              )}

              {/* Lectures List */}
              {group.lectures.length === 0 ? (
                <p className="text-xs text-slate-500 italic py-2">
                  {language === 'ar' ? 'لا توجد محاضرات في هذه الوحدة بعد' : 'No lectures added in this unit yet'}
                </p>
              ) : (
                <div className="space-y-2.5">
                  {group.lectures.map(lecture => {
                    return (
                      <div
                        key={lecture.id}
                        className={`flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-xl border transition-all ${
                          lecture.completed
                            ? 'bg-slate-900/40 border-slate-800/60'
                            : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        {/* Status Toggle & Title */}
                        <div className="flex items-start gap-3 min-w-0">
                          <button
                            onClick={() => toggleLectureComplete(subject.id, lecture.id)}
                            className="mt-0.5 shrink-0 text-slate-400 hover:text-teal-400 transition"
                            title={lecture.completed ? t('markIncomplete') : t('markComplete')}
                          >
                            <CheckCircle2
                              className={`w-5 h-5 ${
                                lecture.completed ? 'text-teal-400 fill-teal-400/20' : 'text-slate-600'
                              }`}
                            />
                          </button>

                          <div className="min-w-0">
                            <h4
                              className={`text-sm font-bold truncate cursor-pointer hover:text-teal-300 transition ${
                                lecture.completed ? 'line-through text-slate-500' : 'text-slate-200'
                              }`}
                              onClick={() => openLectureStudio(subject, lecture)}
                            >
                              {lecture.title}
                            </h4>

                            <div className="flex flex-wrap items-center gap-2 mt-1 text-[11px] text-slate-400">
                              <span className="flex items-center gap-1 font-mono text-slate-500">
                                <FileText className="w-3 h-3" />
                                <span>{lecture.path}</span>
                              </span>

                              {lecture.durationMinutes && (
                                <span className="flex items-center gap-1 text-slate-500">
                                  <Clock className="w-3 h-3" />
                                  <span>
                                    {lecture.durationMinutes} {t('minutes')}
                                  </span>
                                </span>
                              )}

                              {lecture.status === 'review_needed' && (
                                <span className="px-1.5 py-0.2 rounded-md bg-indigo-500/10 text-indigo-300 border border-indigo-500/30 text-[10px] font-bold">
                                  {t('filterReview')}
                                </span>
                              )}
                            </div>

                            {lecture.notes && (
                              <p className="text-[11px] text-slate-400 bg-slate-950/40 p-1.5 rounded-lg border border-slate-800/40 mt-1.5 line-clamp-2">
                                {lecture.notes}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                          {/* Status changer select */}
                          <select
                            value={lecture.status || (lecture.completed ? 'completed' : 'not_started')}
                            onChange={e => {
                              const nextStatus = e.target.value as LectureStatus;
                              updateLecture(subject.id, lecture.id, {
                                status: nextStatus,
                                completed: nextStatus === 'completed'
                              });
                            }}
                            className="bg-slate-800 border border-slate-700/80 rounded-lg px-2 py-1 text-[11px] text-slate-300 font-semibold focus:outline-none cursor-pointer"
                          >
                            <option value="not_started">{t('filterNotStarted')}</option>
                            <option value="in_progress">{t('filterInProgress')}</option>
                            <option value="completed">{t('filterCompleted')}</option>
                            <option value="review_needed">{t('filterReview')}</option>
                          </select>

                          {/* Open in PDF Studio */}
                          <button
                            onClick={() => openLectureStudio(subject, lecture)}
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-500/15 hover:bg-teal-500/25 text-teal-300 border border-teal-500/30 text-xs font-bold transition"
                            title={t('openDocument')}
                          >
                            <FileText className="w-3.5 h-3.5" />
                            <span>{t('openDocument')}</span>
                          </button>

                          {/* Delete Lecture */}
                          <button
                            onClick={() => {
                              if (window.confirm(t('confirmDelete'))) {
                                deleteLecture(subject.id, lecture.id);
                              }
                            }}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition"
                            title={t('delete')}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
