import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Subject } from '../../types/academic';
import {
  BookOpen,
  Plus,
  Compass,
  Search,
  CheckCircle2,
  Clock,
  Sparkles,
  Calendar,
  Layers,
  Music2,
  FileText,
  ChevronRight,
  ChevronLeft,
  GraduationCap
} from 'lucide-react';
import { SubjectDetailView } from './SubjectDetailView';

export const SubjectsView: React.FC = () => {
  const {
    subjects,
    selectedSubjectId,
    setSelectedSubjectId,
    setSmartSubjectModalOpen,
    setEditingSubject,
    setExamRadarModalOpen,
    setMergedStudioSubjectId,
    setMergedAudioPlaying,
    openLectureStudio,
    language,
    t
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'completed' | 'in_progress' | 'review'>('all');

  // If a subject is currently selected for detail inspection, render SubjectDetailView
  if (selectedSubjectId) {
    const activeSub = subjects.find(s => s.id === selectedSubjectId);
    if (activeSub) {
      return <SubjectDetailView subject={activeSub} onBack={() => setSelectedSubjectId(null)} />;
    }
  }

  // Filter subjects by search query
  const filteredSubjects = subjects.filter(sub => {
    const matchesSearch =
      sub.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (sub.code && sub.code.toLowerCase().includes(searchQuery.toLowerCase())) ||
      sub.groups.some(g => g.lectures.some(l => l.title.toLowerCase().includes(searchQuery.toLowerCase())));

    if (!matchesSearch) return false;

    if (statusFilter === 'all') return true;

    const allLecs = sub.groups.flatMap(g => g.lectures);
    if (statusFilter === 'completed') {
      return allLecs.length > 0 && allLecs.every(l => l.completed);
    }
    if (statusFilter === 'in_progress') {
      return allLecs.some(l => l.status === 'in_progress' || (!l.completed && l.status !== 'review_needed'));
    }
    if (statusFilter === 'review') {
      return allLecs.some(l => l.status === 'review_needed');
    }

    return true;
  });

  const getDaysUntilExam = (dateStr?: string) => {
    if (!dateStr) return null;
    const examTime = new Date(dateStr).getTime();
    const now = new Date().setHours(0, 0, 0, 0);
    const diffDays = Math.ceil((examTime - now) / 86400000);
    return diffDays;
  };

  return (
    <div className="space-y-6 pb-20 md:pb-12 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-[#10192d] to-slate-900 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-60 h-60 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -mb-10 -ml-10 w-60 h-60 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-teal-500/10 text-teal-300 border border-teal-500/30 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-teal-400" />
                <span>{t('subjectsTitle')}</span>
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white mb-2">
              {t('subjectsTitle')}
            </h1>
            <p className="text-sm text-slate-400 max-w-xl leading-relaxed">
              {t('subjectsSubtitle')}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => {
                setEditingSubject(null);
                setSmartSubjectModalOpen(true);
              }}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-400 hover:to-teal-500 text-slate-950 font-bold text-sm shadow-lg shadow-teal-500/25 transition-all transform hover:-translate-y-0.5 active:translate-y-0"
            >
              <Plus className="w-4 h-4" />
              <span>{t('addSubject')}</span>
            </button>

            <button
              onClick={() => setExamRadarModalOpen(true)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-rose-300 border border-rose-500/30 font-semibold text-sm transition shadow-sm"
            >
              <Compass className="w-4 h-4 text-rose-400" />
              <span>{t('examRadar')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-[#0f1624]/90 p-3 rounded-2xl border border-slate-800">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute top-3.5 left-3 rtl:right-3 rtl:left-auto" />
          <input
            type="text"
            placeholder={t('searchLectures')}
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900/80 border border-slate-700/60 rounded-xl pl-9 pr-4 rtl:pr-9 rtl:pl-4 py-2 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-teal-500/60 transition"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
              statusFilter === 'all'
                ? 'bg-teal-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            {t('filterAll')}
          </button>
          <button
            onClick={() => setStatusFilter('in_progress')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
              statusFilter === 'in_progress'
                ? 'bg-teal-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            {t('filterInProgress')}
          </button>
          <button
            onClick={() => setStatusFilter('review')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
              statusFilter === 'review'
                ? 'bg-indigo-500 text-white font-bold shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            {t('filterReview')}
          </button>
          <button
            onClick={() => setStatusFilter('completed')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
              statusFilter === 'completed'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            {t('filterCompleted')}
          </button>
        </div>
      </div>

      {/* Subjects Grid */}
      {filteredSubjects.length === 0 ? (
        <div className="text-center py-16 px-4 bg-[#0e1424]/60 rounded-3xl border border-slate-800/80">
          <GraduationCap className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-slate-300 mb-1">{t('noSubjectsFound')}</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto mb-4">
            {language === 'ar'
              ? 'يمكنك البدء بإضافة المواد الدراسية الخاصة بفصلك الحالي وتحديد مواعيد الامتحانات.'
              : 'Start by adding your current academic courses and setting exam target dates.'}
          </p>
          <button
            onClick={() => {
              setEditingSubject(null);
              setSmartSubjectModalOpen(true);
            }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-teal-500 text-slate-950 font-bold text-sm shadow-md"
          >
            <Plus className="w-4 h-4" />
            <span>{t('addSubject')}</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-6">
          {filteredSubjects.map(subject => {
            const totalLecs = subject.groups.reduce((acc, g) => acc + g.lectures.length, 0);
            const doneLecs = subject.groups.reduce((acc, g) => acc + g.lectures.filter(l => l.completed).length, 0);
            const progress = totalLecs > 0 ? Math.round((doneLecs / totalLecs) * 100) : 0;
            const daysToExam = getDaysUntilExam(subject.examDate);

            return (
              <div
                key={subject.id}
                className="group relative flex flex-col justify-between bg-[#11192a] hover:bg-[#141f34] border border-slate-800 hover:border-teal-500/40 rounded-3xl p-5 sm:p-6 shadow-xl transition-all duration-300 hover:shadow-teal-500/5 hover:-translate-y-1"
              >
                {/* Top Badge & Code */}
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <div className="flex items-center gap-2">
                      <span
                        className="w-3 h-3 rounded-full shadow-sm"
                        style={{ backgroundColor: subject.color || '#2dd4bf' }}
                      />
                      {subject.code && (
                        <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded-lg bg-slate-800 text-slate-300 border border-slate-700/60">
                          {subject.code}
                        </span>
                      )}
                    </div>

                    {subject.creditHours && (
                      <span className="text-[10px] font-semibold text-slate-400">
                        {subject.creditHours} {t('creditHours')}
                      </span>
                    )}
                  </div>

                  {/* Course Title */}
                  <h3
                    onClick={() => setSelectedSubjectId(subject.id)}
                    className="text-lg sm:text-xl font-extrabold text-white group-hover:text-teal-300 cursor-pointer transition line-clamp-1 mb-2"
                  >
                    {subject.name}
                  </h3>

                  {/* Exam Countdown Badge */}
                  <div className="flex items-center gap-2 mb-4 text-xs font-semibold">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    {daysToExam !== null ? (
                      daysToExam === 0 ? (
                        <span className="text-rose-400 font-extrabold animate-pulse">{t('todayExamAlert')}</span>
                      ) : daysToExam > 0 ? (
                        <span
                          className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
                            daysToExam <= 7
                              ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                              : 'bg-amber-500/10 text-amber-300 border border-amber-500/30'
                          }`}
                        >
                          {daysToExam} {t('examCountDown')} ({subject.examDate})
                        </span>
                      ) : (
                        <span className="text-slate-500">{t('passedExam')}</span>
                      )
                    ) : (
                      <span className="text-slate-500">{t('noExamDate')}</span>
                    )}
                  </div>

                  {/* Units & Lectures Stats */}
                  <div className="grid grid-cols-2 gap-2 text-center bg-slate-900/60 p-2.5 rounded-2xl border border-slate-800/80 mb-4">
                    <div>
                      <div className="text-[11px] text-slate-400 mb-0.5 flex items-center justify-center gap-1">
                        <Layers className="w-3.5 h-3.5 text-sky-400" />
                        <span>{t('unitsCount')}</span>
                      </div>
                      <span className="text-sm font-extrabold text-slate-200">{subject.groups.length}</span>
                    </div>

                    <div>
                      <div className="text-[11px] text-slate-400 mb-0.5 flex items-center justify-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        <span>{t('completedCount')}</span>
                      </div>
                      <span className="text-sm font-extrabold text-slate-200">
                        {doneLecs} / {totalLecs}
                      </span>
                    </div>
                  </div>

                  {/* Progress bar */}
                  <div className="mb-4">
                    <div className="flex justify-between items-center text-xs mb-1.5">
                      <span className="text-slate-400 font-medium">{t('progressRate')}</span>
                      <span className="font-extrabold text-teal-400">{progress}%</span>
                    </div>
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-teal-500 to-sky-400 rounded-full transition-all duration-500"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Bottom Action Buttons */}
                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                  <button
                    onClick={() => setSelectedSubjectId(subject.id)}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-teal-500/10 hover:bg-teal-500/20 text-teal-300 border border-teal-500/30 text-xs font-bold transition"
                  >
                    <span>{t('openSubject')}</span>
                    {language === 'ar' ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                  </button>

                  <button
                    onClick={() => {
                      setMergedStudioSubjectId(subject.id);
                      setMergedAudioPlaying(true);
                    }}
                    className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-teal-400 transition"
                    title={t('mergedAudioStudio')}
                  >
                    <Music2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
