import React from 'react';
import { useApp } from '../../context/AppContext';
import { X, Compass, Calendar, AlertTriangle, CheckCircle2, Clock, BookOpen, ChevronRight, ChevronLeft } from 'lucide-react';

export const ExamRadarModal: React.FC = () => {
  const { examRadarModalOpen, setExamRadarModalOpen, subjects, setSelectedSubjectId, setCurrentView, language, t } = useApp();

  if (!examRadarModalOpen) return null;

  // Calculate days remaining and sort
  const subjectsWithExams = subjects
    .map(sub => {
      const allLecs = sub.groups.flatMap(g => g.lectures);
      const doneLecs = allLecs.filter(l => l.completed).length;
      const progress = allLecs.length > 0 ? Math.round((doneLecs / allLecs.length) * 100) : 0;

      let days = 999;
      if (sub.examDate) {
        const examTime = new Date(sub.examDate).getTime();
        const now = new Date().setHours(0, 0, 0, 0);
        days = Math.ceil((examTime - now) / 86400000);
      }

      return {
        ...sub,
        daysToExam: days,
        progress,
        totalLecs: allLecs.length,
        doneLecs
      };
    })
    .sort((a, b) => a.daysToExam - b.daysToExam);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-[#0e1626] border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-2xl max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3.5 mb-4 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-rose-500/10 text-rose-400 flex items-center justify-center border border-rose-500/20">
              <Compass className="w-5 h-5 animate-spin-slow" />
            </div>
            <div>
              <h3 className="text-lg font-extrabold text-white">{t('examRadar')}</h3>
              <p className="text-xs text-slate-400">
                {language === 'ar' ? 'متابعة العد التنازلي للاختبارات وجاهزية المراجعة الذكية' : 'Countdown radar & exam readiness'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setExamRadarModalOpen(false)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content list */}
        <div className="space-y-3 overflow-y-auto flex-1 pr-1">
          {subjectsWithExams.length === 0 ? (
            <p className="text-center py-10 text-xs text-slate-500">{t('noSubjectsFound')}</p>
          ) : (
            subjectsWithExams.map(sub => {
              const hasDate = sub.daysToExam !== 999;
              const isUrgent = hasDate && sub.daysToExam <= 7;
              const isModerate = hasDate && sub.daysToExam > 7 && sub.daysToExam <= 14;

              return (
                <div
                  key={sub.id}
                  className={`p-4 rounded-2xl border transition-all ${
                    isUrgent
                      ? 'bg-rose-950/20 border-rose-500/40 hover:bg-rose-950/30'
                      : isModerate
                      ? 'bg-amber-950/20 border-amber-500/40 hover:bg-amber-950/30'
                      : 'bg-slate-900/60 border-slate-800 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-2.5">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: sub.color || '#2dd4bf' }} />
                        <h4 className="text-base font-bold text-white">{sub.name}</h4>
                        {sub.code && (
                          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-300">
                            {sub.code}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-3 text-xs text-slate-400 font-medium">
                        {hasDate ? (
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5 text-slate-400" />
                            <span>
                              {sub.examDate} ({sub.examTime || '09:00'})
                            </span>
                          </span>
                        ) : (
                          <span>{t('noExamDate')}</span>
                        )}

                        <span>
                          {sub.doneLecs}/{sub.totalLecs} {t('completedCount')}
                        </span>
                      </div>
                    </div>

                    {/* Countdown Pill & Action */}
                    <div className="flex items-center gap-2 shrink-0">
                      {hasDate && (
                        <div
                          className={`px-3 py-1 rounded-xl text-xs font-black flex items-center gap-1.5 ${
                            isUrgent
                              ? 'bg-rose-500 text-slate-950 shadow-md shadow-rose-500/20'
                              : isModerate
                              ? 'bg-amber-400 text-slate-950'
                              : 'bg-slate-800 text-slate-300'
                          }`}
                        >
                          <Clock className="w-3.5 h-3.5" />
                          <span>
                            {sub.daysToExam === 0
                              ? t('todayExamAlert')
                              : sub.daysToExam > 0
                              ? `${sub.daysToExam} ${language === 'ar' ? 'يوم' : 'days'}`
                              : t('passedExam')}
                          </span>
                        </div>
                      )}

                      <button
                        onClick={() => {
                          setSelectedSubjectId(sub.id);
                          setCurrentView('subjects');
                          setExamRadarModalOpen(false);
                        }}
                        className="px-3 py-1 rounded-xl bg-teal-500/10 hover:bg-teal-500/20 text-teal-300 border border-teal-500/30 text-xs font-bold transition flex items-center gap-1"
                      >
                        <span>{t('openSubject')}</span>
                        {language === 'ar' ? <ChevronLeft className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  {/* Readiness Progress Bar */}
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        sub.progress >= 80 ? 'bg-emerald-400' : sub.progress >= 50 ? 'bg-amber-400' : 'bg-rose-500'
                      }`}
                      style={{ width: `${sub.progress}%` }}
                    />
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
