import React, { createContext, useContext, useState, useEffect, ReactNode, useMemo } from 'react';
import {
  Subject,
  Lecture,
  ScheduleEvent,
  PlannerPrefs,
  WeeklyTask,
  StudyLog,
  Flashcard,
  QuizQuestion,
  UserAccount,
  CanvasStroke,
  TextAnnotation,
  AppView,
  ScheduleSubView,
  ThemeMode,
  AppLang
} from '../types/academic';
import {
  INITIAL_SUBJECTS,
  INITIAL_PLANNER_PREFS,
  INITIAL_SCHEDULE_EVENTS,
  INITIAL_TASKS,
  INITIAL_LOGS,
  INITIAL_FLASHCARDS,
  INITIAL_QUIZZES
} from '../utils/initialData';
import { deriveSecurePBKDF2Hash, verifyAndUpgradePassword } from '../utils/crypto';
import { t } from '../i18n/translations';

interface ToastItem {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

interface AppContextType {
  // Views & layout
  currentView: AppView;
  setCurrentView: (view: AppView) => void;
  activeView: AppView;
  setActiveView: (view: AppView) => void;
  scheduleSubView: ScheduleSubView;
  setScheduleSubView: (sub: ScheduleSubView) => void;
  selectedSubjectId: number | null;
  setSelectedSubjectId: (id: number | null) => void;
  activeSubject: Subject | null;
  sidebarCollapsed: boolean;
  toggleSidebar: () => void;
  language: AppLang;
  currentLang: AppLang;
  toggleLanguage: () => void;
  theme: ThemeMode;
  setTheme: (t: ThemeMode) => void;
  t: (key: string) => string;

  // Subjects & Lectures
  subjects: Subject[];
  addSubject: (data: Partial<Subject>) => void;
  updateSubject: (id: number, patch: Partial<Subject>) => void;
  deleteSubject: (id: number) => void;
  addLecture: (subjectId: number, groupId: number, lecture: Partial<Lecture>) => void;
  updateLecture: (subjectId: number, lectureId: number, patch: Partial<Lecture>) => void;
  deleteLecture: (subjectId: number, lectureId: number) => void;
  toggleLectureComplete: (subjectId: number, lectureId: number) => void;
  updateLectureStatus: (lectureId: number, status: string) => void;

  // Schedule & Tasks
  scheduleEvents: ScheduleEvent[];
  addScheduleEvent: (event: Omit<ScheduleEvent, 'id'>) => void;
  updateScheduleEvent: (id: string | number, patch: Partial<ScheduleEvent>) => void;
  deleteScheduleEvent: (id: string | number) => void;
  plannerPrefs: PlannerPrefs;
  updatePlannerPrefs: (patch: Partial<PlannerPrefs>) => void;
  weeklyTasks: WeeklyTask[];
  addWeeklyTask: (task: Omit<WeeklyTask, 'id'>) => void;
  toggleWeeklyTask: (id: string | number) => void;
  deleteWeeklyTask: (id: string | number) => void;

  // Tracker & Logs
  studyLogs: StudyLog[];
  addStudyLog: (log: Omit<StudyLog, 'id'>) => void;
  deleteStudyLog: (id: string | number) => void;

  // Studio & Audio
  activeStudioSubject: Subject | null;
  activeStudioLecture: Lecture | null;
  activePdfLecture: Lecture | null;
  setActivePdfLecture: (lec: Lecture | null) => void;
  openLectureStudio: (subject: Subject, lecture: Lecture) => void;
  closeLectureStudio: () => void;
  mergedStudioSubjectId: number | null;
  setMergedStudioSubjectId: (id: number | null) => void;
  mergedAudioPlaying: boolean;
  setMergedAudioPlaying: (p: boolean) => void;
  mergedAudioSpeed: number;
  setMergedAudioSpeed: (s: number) => void;
  mergedAudioVolume: number;
  setMergedAudioVolume: (v: number) => void;
  audioState: {
    isPlaying: boolean;
    currentTime: number;
    duration: number;
    playbackRate: number;
    lecture?: Lecture | null;
  };
  playAudio: (lec?: Lecture) => void;
  pauseAudio: () => void;
  togglePlayPause: () => void;
  seekAudio: (seconds: number) => void;
  setAudioSpeed: (speed: number) => void;
  savePageAnnotations: (lectureId: number, page: number, strokes: CanvasStroke[], notes: TextAnnotation[]) => void;
  getPageAnnotations: (lectureId: number, page: number) => { strokes: CanvasStroke[]; notes: TextAnnotation[] };

  // Academy & Cards
  flashcards: Flashcard[];
  quizzes: QuizQuestion[];
  addFlashcard: (card: Omit<Flashcard, 'id'>) => void;
  updateFlashcardScore: (id: number, rating: 'easy' | 'hard') => void;

  // Cloud & Accounts
  activeAccount: UserAccount | null;
  currentAccount: UserAccount | null;
  accounts: UserAccount[];
  switchAccount: (id: string) => void;
  loginUser: (email: string, pass: string) => Promise<boolean>;
  signupUser: (email: string, pass: string, name: string) => Promise<boolean>;
  logoutUser: () => void;
  exportWorkspaceJson: () => string;
  importWorkspaceJson: (json: string) => boolean;

  // Modals state
  smartSubjectModalOpen: boolean;
  setSmartSubjectModalOpen: (open: boolean) => void;
  editingSubject: Subject | null;
  setEditingSubject: (s: Subject | null) => void;
  examRadarModalOpen: boolean;
  setExamRadarModalOpen: (open: boolean) => void;
  addSlotModalOpen: boolean;
  setAddSlotModalOpen: (open: boolean) => void;
  editingSlot: ScheduleEvent | null;
  setEditingSlot: (slot: ScheduleEvent | null) => void;
  exportPdfModalOpen: boolean;
  setExportPdfModalOpen: (open: boolean) => void;
  logSessionModalOpen: boolean;
  setLogSessionModalOpen: (open: boolean) => void;
  cloudAuthModalOpen: boolean;
  setCloudAuthModalOpen: (open: boolean) => void;
  isCloudModalOpen: boolean;
  setIsCloudModalOpen: (open: boolean) => void;
  helpModalOpen: boolean;
  setHelpModalOpen: (open: boolean) => void;
  isHelpModalOpen: boolean;
  setIsHelpModalOpen: (open: boolean) => void;
  academyModalOpen: boolean;
  setAcademyModalOpen: (open: boolean) => void;
  isAcademyOpen: boolean;
  setIsAcademyOpen: (open: boolean) => void;

  // Toasts
  toasts: ToastItem[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  removeToast: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Navigation & Preferences
  const [currentView, setCurrentView] = useState<AppView>('subjects');
  const [scheduleSubView, setScheduleSubView] = useState<ScheduleSubView>('today');
  const [selectedSubjectId, setSelectedSubjectId] = useState<number | null>(null);
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(() => {
    return localStorage.getItem('exo_sidebar_collapsed') === 'true';
  });
  const [language, setLanguage] = useState<AppLang>(() => {
    return (localStorage.getItem('exoAppLang') as AppLang) || 'ar';
  });
  const [theme, setTheme] = useState<ThemeMode>(() => {
    return (localStorage.getItem('pharmaAppearancePrefsV1') as ThemeMode) || 'dark';
  });

  // Subjects state
  const [subjects, setSubjects] = useState<Subject[]>(() => {
    try {
      const stored = localStorage.getItem('pharmaSubjectsV4');
      return stored ? JSON.parse(stored) : INITIAL_SUBJECTS;
    } catch {
      return INITIAL_SUBJECTS;
    }
  });

  // Schedule & Tasks
  const [scheduleEvents, setScheduleEvents] = useState<ScheduleEvent[]>(() => {
    try {
      const stored = localStorage.getItem('pharmaScheduleV4');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) return parsed;
        if (parsed?.events && Array.isArray(parsed.events)) return parsed.events;
      }
      return INITIAL_SCHEDULE_EVENTS;
    } catch {
      return INITIAL_SCHEDULE_EVENTS;
    }
  });

  const [plannerPrefs, setPlannerPrefs] = useState<PlannerPrefs>(() => {
    try {
      const stored = localStorage.getItem('pharmaPlannerPrefsV1');
      return stored ? { ...INITIAL_PLANNER_PREFS, ...JSON.parse(stored) } : INITIAL_PLANNER_PREFS;
    } catch {
      return INITIAL_PLANNER_PREFS;
    }
  });

  const [weeklyTasks, setWeeklyTasks] = useState<WeeklyTask[]>(() => {
    try {
      const stored = localStorage.getItem('pharmaScheduleBacklogV1');
      return stored ? JSON.parse(stored) : INITIAL_TASKS;
    } catch {
      return INITIAL_TASKS;
    }
  });

  // Tracker state
  const [studyLogs, setStudyLogs] = useState<StudyLog[]>(() => {
    try {
      const stored = localStorage.getItem('pharmaLogsV4');
      return stored ? JSON.parse(stored) : INITIAL_LOGS;
    } catch {
      return INITIAL_LOGS;
    }
  });

  // Academy state
  const [flashcards, setFlashcards] = useState<Flashcard[]>(() => {
    try {
      const stored = localStorage.getItem('pharmaAcademyProgressV1');
      return stored ? JSON.parse(stored) : INITIAL_FLASHCARDS;
    } catch {
      return INITIAL_FLASHCARDS;
    }
  });
  const [quizzes] = useState<QuizQuestion[]>(INITIAL_QUIZZES);

  // Accounts & Cloud
  const [accounts, setAccounts] = useState<UserAccount[]>(() => {
    try {
      const stored = localStorage.getItem('pharmaAccountsRegistryV1');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const [activeAccount, setActiveAccount] = useState<UserAccount | null>(() => {
    try {
      const stored = localStorage.getItem('pharmaActiveAccountSessionV1');
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  // PDF Studio & Annotation
  const [activeStudioSubject, setActiveStudioSubject] = useState<Subject | null>(null);
  const [activeStudioLecture, setActiveStudioLecture] = useState<Lecture | null>(null);
  const [annotationsMap, setAnnotationsMap] = useState<Record<string, { strokes: CanvasStroke[]; notes: TextAnnotation[] }>>(() => {
    try {
      const stored = localStorage.getItem('exo_annotations_map');
      return stored ? JSON.parse(stored) : {};
    } catch {
      return {};
    }
  });

  // Merged Audio Player
  const [mergedStudioSubjectId, setMergedStudioSubjectId] = useState<number | null>(null);
  const [mergedAudioPlaying, setMergedAudioPlaying] = useState<boolean>(false);
  const [mergedAudioSpeed, setMergedAudioSpeed] = useState<number>(1);
  const [mergedAudioVolume, setMergedAudioVolume] = useState<number>(100);

  // Modals
  const [smartSubjectModalOpen, setSmartSubjectModalOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null);
  const [examRadarModalOpen, setExamRadarModalOpen] = useState(false);
  const [addSlotModalOpen, setAddSlotModalOpen] = useState(false);
  const [editingSlot, setEditingSlot] = useState<ScheduleEvent | null>(null);
  const [exportPdfModalOpen, setExportPdfModalOpen] = useState(false);
  const [logSessionModalOpen, setLogSessionModalOpen] = useState(false);
  const [cloudAuthModalOpen, setCloudAuthModalOpen] = useState(false);
  const [helpModalOpen, setHelpModalOpen] = useState(false);
  const [academyModalOpen, setAcademyModalOpen] = useState(false);

  // Toasts
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  // Apply Theme & Direction
  useEffect(() => {
    document.documentElement.setAttribute('dir', language === 'ar' ? 'rtl' : 'ltr');
    document.documentElement.setAttribute('lang', language);
    localStorage.setItem('exoAppLang', language);
  }, [language]);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('pharmaAppearancePrefsV1', theme);
  }, [theme]);

  // Persist State
  useEffect(() => {
    localStorage.setItem('pharmaSubjectsV4', JSON.stringify(subjects));
    localStorage.setItem('pharmaWorkspaceDirty', 'true');
  }, [subjects]);

  useEffect(() => {
    localStorage.setItem('pharmaScheduleV4', JSON.stringify(scheduleEvents));
  }, [scheduleEvents]);

  useEffect(() => {
    localStorage.setItem('pharmaPlannerPrefsV1', JSON.stringify(plannerPrefs));
  }, [plannerPrefs]);

  useEffect(() => {
    localStorage.setItem('pharmaScheduleBacklogV1', JSON.stringify(weeklyTasks));
  }, [weeklyTasks]);

  useEffect(() => {
    localStorage.setItem('pharmaLogsV4', JSON.stringify(studyLogs));
  }, [studyLogs]);

  useEffect(() => {
    localStorage.setItem('pharmaAcademyProgressV1', JSON.stringify(flashcards));
  }, [flashcards]);

  useEffect(() => {
    localStorage.setItem('exo_annotations_map', JSON.stringify(annotationsMap));
  }, [annotationsMap]);

  useEffect(() => {
    localStorage.setItem('pharmaAccountsRegistryV1', JSON.stringify(accounts));
  }, [accounts]);

  useEffect(() => {
    if (activeAccount) {
      localStorage.setItem('pharmaActiveAccountSessionV1', JSON.stringify(activeAccount));
      localStorage.setItem('pharmaLastActiveUserIdV1', activeAccount.id);
    } else {
      localStorage.removeItem('pharmaActiveAccountSessionV1');
    }
  }, [activeAccount]);

  // Helper translations
  const translate = (key: string) => t(key, language);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = `${Date.now()}-${Math.random()}`;
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 3500);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const toggleSidebar = () => {
    setSidebarCollapsed(prev => {
      const next = !prev;
      localStorage.setItem('exo_sidebar_collapsed', String(next));
      return next;
    });
  };

  const toggleLanguage = () => {
    setLanguage(prev => (prev === 'ar' ? 'en' : 'ar'));
  };

  // Subjects CRUD
  const addSubject = (data: Partial<Subject>) => {
    const newSub: Subject = {
      id: Date.now(),
      name: data.name || (language === 'ar' ? 'مادة جديدة' : 'New Subject'),
      code: data.code || '',
      color: data.color || '#2dd4bf',
      creditHours: data.creditHours || 3,
      examDate: data.examDate || '',
      examTime: data.examTime || '09:00',
      groups: [
        {
          id: Date.now() + 1,
          name: language === 'ar' ? 'الوحدة 1: الأساسيات' : 'Unit 1: Fundamentals',
          lectures: []
        }
      ]
    };
    setSubjects(prev => [newSub, ...prev]);
    showToast(translate('successToast'));
  };

  const updateSubject = (id: number, patch: Partial<Subject>) => {
    setSubjects(prev => prev.map(s => (s.id === id ? { ...s, ...patch } : s)));
    showToast(translate('successToast'));
  };

  const deleteSubject = (id: number) => {
    setSubjects(prev => prev.filter(s => s.id !== id));
    if (selectedSubjectId === id) setSelectedSubjectId(null);
    showToast(translate('successToast'));
  };

  const addLecture = (subjectId: number, groupId: number, lecture: Partial<Lecture>) => {
    const newLec: Lecture = {
      id: Date.now(),
      title: lecture.title || (language === 'ar' ? 'محاضرة جديدة' : 'New Lecture'),
      path: lecture.path || 'document.pdf',
      completed: false,
      status: 'not_started',
      durationMinutes: lecture.durationMinutes || 45,
      pageCount: lecture.pageCount || 20,
      currentPage: 1,
      notes: lecture.notes || ''
    };
    setSubjects(prev =>
      prev.map(sub => {
        if (sub.id !== subjectId) return sub;
        return {
          ...sub,
          groups: sub.groups.map(grp => {
            if (grp.id !== groupId) return grp;
            return { ...grp, lectures: [...grp.lectures, newLec] };
          })
        };
      })
    );
    showToast(translate('successToast'));
  };

  const updateLecture = (subjectId: number, lectureId: number, patch: Partial<Lecture>) => {
    setSubjects(prev =>
      prev.map(sub => {
        if (sub.id !== subjectId) return sub;
        return {
          ...sub,
          groups: sub.groups.map(grp => ({
            ...grp,
            lectures: grp.lectures.map(lec => (lec.id === lectureId ? { ...lec, ...patch } : lec))
          }))
        };
      })
    );
  };

  const deleteLecture = (subjectId: number, lectureId: number) => {
    setSubjects(prev =>
      prev.map(sub => {
        if (sub.id !== subjectId) return sub;
        return {
          ...sub,
          groups: sub.groups.map(grp => ({
            ...grp,
            lectures: grp.lectures.filter(lec => lec.id !== lectureId)
          }))
        };
      })
    );
    showToast(translate('successToast'));
  };

  const toggleLectureComplete = (subjectId: number, lectureId: number) => {
    setSubjects(prev =>
      prev.map(sub => {
        if (sub.id !== subjectId) return sub;
        return {
          ...sub,
          groups: sub.groups.map(grp => ({
            ...grp,
            lectures: grp.lectures.map(lec => {
              if (lec.id !== lectureId) return lec;
              const nextCompleted = !lec.completed;
              return {
                ...lec,
                completed: nextCompleted,
                status: nextCompleted ? 'completed' : 'in_progress',
                lastStudied: new Date().toISOString()
              };
            })
          }))
        };
      })
    );
    showToast(translate('successToast'));
  };

  // Schedule Events
  const addScheduleEvent = (event: Omit<ScheduleEvent, 'id'>) => {
    const newEvent: ScheduleEvent = {
      ...event,
      id: `slot-${Date.now()}`
    };
    setScheduleEvents(prev => [...prev, newEvent]);
    showToast(translate('successToast'));
  };

  const updateScheduleEvent = (id: string | number, patch: Partial<ScheduleEvent>) => {
    setScheduleEvents(prev => prev.map(ev => (ev.id === id ? { ...ev, ...patch } : ev)));
    showToast(translate('successToast'));
  };

  const deleteScheduleEvent = (id: string | number) => {
    setScheduleEvents(prev => prev.filter(ev => ev.id !== id));
    showToast(translate('successToast'));
  };

  const updatePlannerPrefs = (patch: Partial<PlannerPrefs>) => {
    setPlannerPrefs(prev => ({ ...prev, ...patch }));
    showToast(translate('successToast'));
  };

  // Weekly Tasks
  const addWeeklyTask = (task: Omit<WeeklyTask, 'id'>) => {
    const newTask: WeeklyTask = {
      ...task,
      id: `task-${Date.now()}`
    };
    setWeeklyTasks(prev => [...prev, newTask]);
    showToast(translate('successToast'));
  };

  const toggleWeeklyTask = (id: string | number) => {
    setWeeklyTasks(prev =>
      prev.map(t => (t.id === id ? { ...t, completed: !t.completed, completedHours: !t.completed ? t.targetHours : 0 } : t))
    );
  };

  const deleteWeeklyTask = (id: string | number) => {
    setWeeklyTasks(prev => prev.filter(t => t.id !== id));
  };

  // Study Logs
  const addStudyLog = (log: Omit<StudyLog, 'id'>) => {
    const newLog: StudyLog = {
      ...log,
      id: `log-${Date.now()}`
    };
    setStudyLogs(prev => [newLog, ...prev]);
    showToast(translate('successToast'));
  };

  const deleteStudyLog = (id: string | number) => {
    setStudyLogs(prev => prev.filter(l => l.id !== id));
  };

  // Studio & Annotation
  const openLectureStudio = (subject: Subject, lecture: Lecture) => {
    setActiveStudioSubject(subject);
    setActiveStudioLecture(lecture);
    // Mark as in progress if not started
    if (!lecture.completed && lecture.status === 'not_started') {
      updateLecture(subject.id, lecture.id, { status: 'in_progress', lastStudied: new Date().toISOString() });
    }
  };

  const closeLectureStudio = () => {
    setActiveStudioSubject(null);
    setActiveStudioLecture(null);
  };

  const savePageAnnotations = (lectureId: number, page: number, strokes: CanvasStroke[], notes: TextAnnotation[]) => {
    const key = `${lectureId}_p${page}`;
    setAnnotationsMap(prev => ({
      ...prev,
      [key]: { strokes, notes }
    }));
  };

  const getPageAnnotations = (lectureId: number, page: number) => {
    const key = `${lectureId}_p${page}`;
    return annotationsMap[key] || { strokes: [], notes: [] };
  };

  // Flashcards
  const addFlashcard = (card: Omit<Flashcard, 'id'>) => {
    const newCard: Flashcard = {
      ...card,
      id: Date.now()
    };
    setFlashcards(prev => [newCard, ...prev]);
    showToast(translate('successToast'));
  };

  // Workspace backup / restore
  const exportWorkspaceJson = () => {
    const data = {
      version: '1.4.2-react',
      exportDate: new Date().toISOString(),
      subjects,
      schedule: scheduleEvents,
      tasks: weeklyTasks,
      plannerPrefs,
      logs: studyLogs,
      flashcards,
      annotations: annotationsMap
    };
    return JSON.stringify(data, null, 2);
  };

  const importWorkspaceJson = (jsonStr: string): boolean => {
    try {
      const data = JSON.parse(jsonStr);
      if (data.subjects && Array.isArray(data.subjects)) setSubjects(data.subjects);
      if (data.schedule && Array.isArray(data.schedule)) setScheduleEvents(data.schedule);
      if (data.tasks && Array.isArray(data.tasks)) setWeeklyTasks(data.tasks);
      if (data.logs && Array.isArray(data.logs)) setStudyLogs(data.logs);
      if (data.flashcards && Array.isArray(data.flashcards)) setFlashcards(data.flashcards);
      if (data.plannerPrefs) setPlannerPrefs(prev => ({ ...prev, ...data.plannerPrefs }));
      if (data.annotations) setAnnotationsMap(data.annotations);
      showToast(translate('successToast'));
      return true;
    } catch {
      showToast(translate('errorToast'), 'error');
      return false;
    }
  };

  // Auth & Cloud Accounts
  const loginUser = async (email: string, pass: string): Promise<boolean> => {
    const existing = accounts.find(a => a.email.toLowerCase() === email.toLowerCase());
    if (!existing || !existing.passwordHash) {
      showToast(language === 'ar' ? 'الحساب غير موجود' : 'Account not found', 'error');
      return false;
    }
    const verified = await verifyAndUpgradePassword(pass, existing.passwordHash);
    if (verified.valid) {
      if (verified.upgradedHash) {
        existing.passwordHash = verified.upgradedHash;
        setAccounts(prev => prev.map(a => (a.id === existing.id ? existing : a)));
      }
      setActiveAccount(existing);
      showToast(language === 'ar' ? 'تم تسجيل الدخول بنجاح' : 'Logged in successfully');
      setCloudAuthModalOpen(false);
      return true;
    } else {
      showToast(language === 'ar' ? 'كلمة المرور غير صحيحة' : 'Incorrect password', 'error');
      return false;
    }
  };

  const signupUser = async (email: string, pass: string, name: string): Promise<boolean> => {
    const existing = accounts.find(a => a.email.toLowerCase() === email.toLowerCase());
    if (existing) {
      showToast(language === 'ar' ? 'البريد مسجل بالفعل' : 'Email already registered', 'error');
      return false;
    }
    const { hash } = await deriveSecurePBKDF2Hash(pass);
    const newAcc: UserAccount = {
      id: `usr_${Date.now()}`,
      email: email.trim(),
      displayName: name.trim() || email.split('@')[0],
      passwordHash: hash,
      isCloudActive: true,
      isVip: true,
      createdAt: new Date().toISOString()
    };
    setAccounts(prev => [...prev, newAcc]);
    setActiveAccount(newAcc);
    showToast(language === 'ar' ? 'تم إنشاء الحساب وتفعيل المزامنة' : 'Account created & sync activated');
    setCloudAuthModalOpen(false);
    return true;
  };

  const logoutUser = () => {
    setActiveAccount(null);
    showToast(language === 'ar' ? 'تم تسجيل الخروج' : 'Logged out');
  };

  return (
    <AppContext.Provider
      value={{
        currentView,
        setCurrentView,
        scheduleSubView,
        setScheduleSubView,
        selectedSubjectId,
        setSelectedSubjectId,
        sidebarCollapsed,
        toggleSidebar,
        language,
        toggleLanguage,
        theme,
        setTheme,
        t: translate,

        subjects,
        addSubject,
        updateSubject,
        deleteSubject,
        addLecture,
        updateLecture,
        deleteLecture,
        toggleLectureComplete,

        scheduleEvents,
        addScheduleEvent,
        updateScheduleEvent,
        deleteScheduleEvent,
        plannerPrefs,
        updatePlannerPrefs,
        weeklyTasks,
        addWeeklyTask,
        toggleWeeklyTask,
        deleteWeeklyTask,

        studyLogs,
        addStudyLog,
        deleteStudyLog,

        activeStudioSubject,
        activeStudioLecture,
        openLectureStudio,
        closeLectureStudio,
        mergedStudioSubjectId,
        setMergedStudioSubjectId,
        mergedAudioPlaying,
        setMergedAudioPlaying,
        mergedAudioSpeed,
        setMergedAudioSpeed,
        mergedAudioVolume,
        setMergedAudioVolume,
        savePageAnnotations,
        getPageAnnotations,

        flashcards,
        quizzes,
        addFlashcard,

        activeAccount,
        accounts,
        loginUser,
        signupUser,
        logoutUser,
        exportWorkspaceJson,
        importWorkspaceJson,

        smartSubjectModalOpen,
        setSmartSubjectModalOpen,
        editingSubject,
        setEditingSubject,
        examRadarModalOpen,
        setExamRadarModalOpen,
        addSlotModalOpen,
        setAddSlotModalOpen,
        editingSlot,
        setEditingSlot,
        exportPdfModalOpen,
        setExportPdfModalOpen,
        logSessionModalOpen,
        setLogSessionModalOpen,
        cloudAuthModalOpen,
        setCloudAuthModalOpen,
        helpModalOpen,
        setHelpModalOpen,
        academyModalOpen,
        setAcademyModalOpen,

        activeView: currentView,
        setActiveView: setCurrentView,
        activeSubject: subjects.find(s => s.id === selectedSubjectId) || null,
        currentLang: language,

        updateLectureStatus: (lecId: number, status: string) => {
          const s = subjects.find(sub => sub.groups.some(g => g.lectures.some(l => l.id === lecId)));
          if (s) {
            updateLecture(s.id, lecId, { status: status as any, completed: status === 'completed' });
          }
        },

        activePdfLecture: activeStudioLecture,
        setActivePdfLecture: (lec: Lecture | null) => {
          if (lec) {
            const sub = subjects.find(s => s.groups.some(g => g.lectures.some(l => l.id === lec.id))) || subjects[0];
            openLectureStudio(sub, lec);
          } else {
            closeLectureStudio();
          }
        },
        audioState: {
          isPlaying: mergedAudioPlaying,
          currentTime: 145,
          duration: 2400,
          playbackRate: mergedAudioSpeed,
          lecture: activeStudioLecture
        },
        playAudio: () => setMergedAudioPlaying(true),
        pauseAudio: () => setMergedAudioPlaying(false),
        togglePlayPause: () => setMergedAudioPlaying(!mergedAudioPlaying),
        seekAudio: () => {},
        setAudioSpeed: (s: number) => setMergedAudioSpeed(s),

        updateFlashcardScore: (_id: number, rating: 'easy' | 'hard') => {
          showToast(rating === 'easy' ? (language === 'ar' ? 'تم التثبيت' : 'Mastered') : (language === 'ar' ? 'تمت الجدولة' : 'Scheduled'), 'info');
        },

        currentAccount: activeAccount,
        switchAccount: (id: string) => {
          const acc = accounts.find(a => a.id === id);
          if (acc) {
            setActiveAccount(acc);
            showToast(language === 'ar' ? `تم التبديل إلى ${acc.displayName}` : `Switched to ${acc.displayName}`, 'success');
          }
        },

        isCloudModalOpen: cloudAuthModalOpen,
        setIsCloudModalOpen: setCloudAuthModalOpen,
        isHelpModalOpen: helpModalOpen,
        setIsHelpModalOpen: setHelpModalOpen,
        isAcademyOpen: academyModalOpen,
        setIsAcademyOpen: setAcademyModalOpen,

        toasts,
        showToast,
        removeToast
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
