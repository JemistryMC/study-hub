export type LectureStatus = 'not_started' | 'in_progress' | 'completed' | 'review_needed';

export interface Lecture {
  id: number;
  title: string;
  path: string;
  completed: boolean;
  status?: LectureStatus;
  notes?: string;
  audioPath?: string;
  audioUrl?: string;
  durationMinutes?: number;
  durationMin?: number;
  lastStudied?: string;
  pageCount?: number;
  totalPages?: number;
  currentPage?: number;
}

export interface LectureGroup {
  id: number;
  name: string;
  lectures: Lecture[];
}

export interface Subject {
  id: number;
  name: string;
  nameAr?: string;
  code?: string;
  color?: string;
  examDate?: string;
  examTime?: string;
  creditHours?: number;
  groups: LectureGroup[];
}

export type SlotType = 'college' | 'study' | 'absent' | 'review' | 'exam' | 'personal';

export interface ScheduleEvent {
  id: string | number;
  title: string;
  day: number; // 0=Sunday, 1=Monday, ..., 6=Saturday
  startHour: number;
  startMinute: number;
  endHour: number;
  endMinute: number;
  type: SlotType;
  subjectId?: number;
  lectureId?: number;
  completed?: boolean;
  notes?: string;
}

export interface PlannerPrefs {
  weekStartDay: number; // 6 = Saturday (default in Arabic academia)
  dayStartHour: number; // 6
  dayEndHour: number; // 23
  autoCompletePct: number; // 75
  currentWeekStartIso: string;
}

export interface WeeklyTask {
  id: string | number;
  title: string;
  targetHours: number;
  completedHours: number;
  completed: boolean;
  subjectId?: number;
  weekStartIso?: string;
}

export type LogType = 'pomodoro' | 'manual' | 'pdf_session';

export interface StudyLog {
  id: string | number;
  subjectId?: number;
  subjectName: string;
  lectureTitle?: string;
  date: string;
  durationMinutes: number;
  type: LogType;
  notes?: string;
  rating?: number; // 1-5 stars
}

export interface WeeklyReport {
  id: string | number;
  weekStartIso: string;
  totalStudyMinutes: number;
  collegeMinutes: number;
  absentMinutes: number;
  reviewRatio: number;
  grade: string;
  notes: string;
}

export interface Flashcard {
  id: number;
  subjectId: number;
  question: string;
  answer: string;
  difficulty: 'easy' | 'medium' | 'hard';
  lastReviewed?: string;
  front?: string;
  back?: string;
  box?: number;
}

export interface QuizQuestion {
  id: number;
  subjectId: number;
  question: string;
  options: string[];
  correctIndex: number;
  explanation?: string;
}

export interface UserAccount {
  id: string;
  email: string;
  displayName: string;
  username?: string;
  passwordHash?: string;
  isCloudActive?: boolean;
  isVip?: boolean;
  createdAt: string;
}

export interface CanvasStroke {
  id?: string;
  tool?: 'pen' | 'highlighter' | 'eraser';
  type?: 'pen' | 'highlighter' | 'eraser';
  color: string;
  width: number;
  points: { x: number; y: number }[];
  pageNumber?: number;
}

export interface TextAnnotation {
  id: string;
  text: string;
  x: number;
  y: number;
  color: string;
  pageNumber?: number;
  page?: number;
}

export type AppView = 'subjects' | 'schedule' | 'tracker';
export type ScheduleSubView = 'today' | 'week' | 'tasks';
export type ThemeMode = 'dark' | 'light' | 'eye_comfort';
export type AppLang = 'ar' | 'en';
