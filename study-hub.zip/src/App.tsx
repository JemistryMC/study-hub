import React from 'react';
import { useApp } from './context/AppContext';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { MobileBottomNav } from './components/layout/MobileBottomNav';
import { BottomAudioBar } from './components/layout/BottomAudioBar';

// Views
import { SubjectsView } from './components/subjects/SubjectsView';
import { SubjectDetailView } from './components/subjects/SubjectDetailView';
import { ScheduleView } from './components/schedule/ScheduleView';
import { TrackerView } from './components/tracker/TrackerView';

// Modals
import { SmartSubjectModal } from './components/subjects/SmartSubjectModal';
import { ExamRadarModal } from './components/subjects/ExamRadarModal';
import { AddSlotModal } from './components/schedule/AddSlotModal';
import { LogSessionModal } from './components/tracker/LogSessionModal';
import { PdfStudioModal } from './components/pdfStudio/PdfStudioModal';
import { AcademyModal } from './components/academy/AcademyModal';
import { CloudAuthModal } from './components/cloud/CloudAuthModal';
import { HelpModal } from './components/common/HelpModal';
import { ToastContainer } from './components/common/Toast';

export const App: React.FC = () => {
  const {
    activeView,
    activeSubject,
    setSelectedSubjectId,
    theme,
    currentLang
  } = useApp();

  return (
    <div
      className={`min-h-screen flex flex-col ${theme === 'dark' ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}
      dir={currentLang === 'ar' ? 'rtl' : 'ltr'}
    >
      {/* Top Navigation */}
      <Navbar />

      {/* Main Container with Sidebar + View */}
      <div className="flex-1 flex overflow-hidden">
        {/* Desktop Collapsible Sidebar */}
        <Sidebar />

        {/* Dynamic View Area */}
        <main className="flex-1 overflow-y-auto pb-24 md:pb-16 focus:outline-none">
          {activeView === 'subjects' && (
            activeSubject ? (
              <SubjectDetailView
                subject={activeSubject}
                onBack={() => setSelectedSubjectId(null)}
              />
            ) : (
              <SubjectsView />
            )
          )}

          {activeView === 'schedule' && <ScheduleView />}

          {activeView === 'tracker' && <TrackerView />}
        </main>
      </div>

      {/* Persistent Audio Player Bar */}
      <BottomAudioBar />

      {/* Mobile Bottom Navigation */}
      <MobileBottomNav />

      {/* Global Modals */}
      <SmartSubjectModal />
      <ExamRadarModal />
      <AddSlotModal />
      <LogSessionModal />
      <PdfStudioModal />
      <AcademyModal />
      <CloudAuthModal />
      <HelpModal />
      <ToastContainer />
    </div>
  );
};

export default App;
