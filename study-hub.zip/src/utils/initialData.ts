import { Subject, ScheduleEvent, PlannerPrefs, WeeklyTask, StudyLog, Flashcard, QuizQuestion } from '../types/academic';

export const INITIAL_SUBJECTS: Subject[] = [
  {
    id: 101,
    name: 'علم الأدوية (Pharmacology I)',
    code: 'PHAR-301',
    color: '#2dd4bf',
    creditHours: 3,
    examDate: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
    examTime: '09:00',
    groups: [
      {
        id: 201,
        name: 'الوحدة 1: Autonomic Nervous System',
        lectures: [
          {
            id: 301,
            title: 'Lec 1 - Cholinergic Agonists & Muscarinic Receptors',
            path: 'Lec1_ANS.pdf',
            completed: true,
            status: 'completed',
            durationMinutes: 45,
            notes: 'تمت دراسة آلية عمل الأستيل كولين والمستقبلات الكولينية بتركيز عالي.',
            lastStudied: new Date(Date.now() - 86400000).toISOString(),
            pageCount: 24,
            currentPage: 1
          },
          {
            id: 302,
            title: 'Lec 2 - Adrenergic Antagonists & Beta Blockers',
            path: 'Lec2_Adrenergic.pdf',
            completed: false,
            status: 'in_progress',
            durationMinutes: 30,
            notes: 'التركيز على الفروقات بين Propranolol و Metoprolol.',
            lastStudied: new Date().toISOString(),
            pageCount: 32,
            currentPage: 8
          }
        ]
      },
      {
        id: 202,
        name: 'الوحدة 2: Cardiovascular Pharmacology',
        lectures: [
          {
            id: 303,
            title: 'Lec 3 - Antihypertensive Agents (ACEIs & ARBs)',
            path: 'Lec3_Antihypertensives.pdf',
            completed: false,
            status: 'not_started',
            durationMinutes: 0,
            notes: '',
            pageCount: 28,
            currentPage: 1
          }
        ]
      }
    ]
  },
  {
    id: 102,
    name: 'الكيمياء الحيوية (Biochemistry)',
    code: 'BIOC-202',
    color: '#818cf8',
    creditHours: 3,
    examDate: new Date(Date.now() + 21 * 86400000).toISOString().split('T')[0],
    examTime: '11:00',
    groups: [
      {
        id: 203,
        name: 'الوحدة 1: Carbohydrate Metabolism',
        lectures: [
          {
            id: 304,
            title: 'Lec 1 - Glycolysis Cycle & Energy Yield',
            path: 'Biochem_Lec1.pdf',
            completed: true,
            status: 'completed',
            durationMinutes: 50,
            notes: 'حساب الـ ATP الناتج في الظروف الهوائية واللاهوائية.',
            lastStudied: new Date(Date.now() - 2 * 86400000).toISOString(),
            pageCount: 20,
            currentPage: 20
          },
          {
            id: 305,
            title: 'Lec 2 - Krebs Citric Acid Cycle',
            path: 'Biochem_Lec2.pdf',
            completed: false,
            status: 'review_needed',
            durationMinutes: 40,
            notes: 'مراجعة الإنزيمات المحددة للسرعة مثل Isocitrate Dehydrogenase.',
            lastStudied: new Date(Date.now() - 3 * 86400000).toISOString(),
            pageCount: 26,
            currentPage: 12
          }
        ]
      }
    ]
  },
  {
    id: 103,
    name: 'الصيدلانيات (Pharmaceutics)',
    code: 'PHTC-201',
    color: '#06b6d4',
    creditHours: 2,
    examDate: new Date(Date.now() + 28 * 86400000).toISOString().split('T')[0],
    examTime: '10:00',
    groups: [
      {
        id: 204,
        name: 'الوحدة 1: Liquid Dosage Forms',
        lectures: [
          {
            id: 306,
            title: 'Lec 1 - Solutions & Suspensions Stability',
            path: 'Pharmaceutics_1.pdf',
            completed: false,
            status: 'in_progress',
            durationMinutes: 35,
            notes: 'قانون ستوكس لسرعة الترسيب في المعلقات.',
            pageCount: 18,
            currentPage: 5
          }
        ]
      }
    ]
  },
  {
    id: 104,
    name: 'علم التشريح والوظائف (Anatomy & Physiology)',
    code: 'ANAT-101',
    color: '#f43f5e',
    creditHours: 3,
    examDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
    examTime: '08:30',
    groups: [
      {
        id: 205,
        name: 'الوحدة 1: Cardiovascular System',
        lectures: [
          {
            id: 307,
            title: 'Lec 1 - Cardiac Electrophysiology & ECG',
            path: 'Anat_Lec1.pdf',
            completed: true,
            status: 'completed',
            durationMinutes: 60,
            notes: 'موجات تخطيط القلب P, QRS, T ومعانيها الإكلينيكية.',
            pageCount: 30,
            currentPage: 30
          }
        ]
      }
    ]
  }
];

export const INITIAL_PLANNER_PREFS: PlannerPrefs = {
  weekStartDay: 6, // السبت
  dayStartHour: 6, // 6:00 AM
  dayEndHour: 23, // 11:00 PM
  autoCompletePct: 75,
  currentWeekStartIso: new Date().toISOString()
};

export const INITIAL_SCHEDULE_EVENTS: ScheduleEvent[] = [
  {
    id: 'slot-1',
    title: 'محاضرة كلية: علم الأدوية (Pharmacology)',
    day: 6, // السبت
    startHour: 9,
    startMinute: 0,
    endHour: 11,
    endMinute: 0,
    type: 'college',
    subjectId: 101,
    completed: true,
    notes: 'مدرج 2 - مناقشة أدوية الجهاز العصبي المستقل'
  },
  {
    id: 'slot-2',
    title: 'مذاكرة مركزة: تلخيص Lec 1 ANS',
    day: 6, // السبت
    startHour: 14,
    startMinute: 0,
    endHour: 16,
    endMinute: 0,
    type: 'study',
    subjectId: 101,
    lectureId: 301,
    completed: true,
    notes: 'حل أسئلة الكويز وتدوين الملاحظات'
  },
  {
    id: 'slot-3',
    title: 'محاضرة كلية: الكيمياء الحيوية (Biochem)',
    day: 0, // الأحد
    startHour: 10,
    startMinute: 0,
    endHour: 12,
    endMinute: 0,
    type: 'college',
    subjectId: 102,
    completed: true,
    notes: 'قاعة 4'
  },
  {
    id: 'slot-4',
    title: 'مراجعة ذكية: إنزيمات حلقة كريبس',
    day: 0, // الأحد
    startHour: 17,
    startMinute: 0,
    endHour: 18,
    endMinute: 30,
    type: 'review',
    subjectId: 102,
    lectureId: 305,
    completed: false,
    notes: 'تكرار متباعد لحفظ خطوات الدورة'
  },
  {
    id: 'slot-5',
    title: 'محاضرة كلية: الصيدلانيات (Pharmaceutics)',
    day: 1, // الإثنين
    startHour: 8,
    startMinute: 30,
    endHour: 10,
    endMinute: 30,
    type: 'college',
    subjectId: 103,
    completed: false,
    notes: 'معمل الصيدلانيات الفيزيائية'
  },
  {
    id: 'slot-6',
    title: 'مذاكرة واستوديو PDF: Lec 1 Solutions',
    day: 1, // الإثنين
    startHour: 15,
    startMinute: 0,
    endHour: 17,
    endMinute: 0,
    type: 'study',
    subjectId: 103,
    lectureId: 306,
    completed: false
  },
  {
    id: 'slot-7',
    title: 'فترة غياب مسجلة: تأخر عن معمل التشريح',
    day: 2, // الثلاثاء
    startHour: 11,
    startMinute: 0,
    endHour: 12,
    endMinute: 30,
    type: 'absent',
    subjectId: 104,
    completed: false,
    notes: 'يتطلب تعويض سريع للمنهج المشروح'
  }
];

export const INITIAL_TASKS: WeeklyTask[] = [
  { id: 't-1', title: 'إتمام قراءة وتلخيص Lec 2 Adrenergic Antagonists', targetHours: 3, completedHours: 2, completed: false, subjectId: 101 },
  { id: 't-2', title: 'مراجعة خريطة تفاعلات Glycolysis وحفظ الـ Rate-limiting steps', targetHours: 2, completedHours: 2, completed: true, subjectId: 102 },
  { id: 't-3', title: 'حل بنك أسئلة الـ Multiple Choice لكويز التشريح', targetHours: 2.5, completedHours: 1, completed: false, subjectId: 104 },
  { id: 't-4', title: 'كتابة تقرير معمل الصيدلانيات وحساب المعلقات', targetHours: 1.5, completedHours: 1.5, completed: true, subjectId: 103 }
];

export const INITIAL_LOGS: StudyLog[] = [
  {
    id: 'log-1',
    subjectId: 101,
    subjectName: 'علم الأدوية (Pharmacology I)',
    lectureTitle: 'Lec 1 - Cholinergic Agonists',
    date: new Date(Date.now() - 86400000 * 2).toISOString(),
    durationMinutes: 45,
    type: 'pomodoro',
    notes: 'جلسة تركيز كاملة على أدوية الجهاز العصبي المستقل',
    rating: 5
  },
  {
    id: 'log-2',
    subjectId: 102,
    subjectName: 'الكيمياء الحيوية (Biochemistry)',
    lectureTitle: 'Lec 1 - Glycolysis Cycle',
    date: new Date(Date.now() - 86400000).toISOString(),
    durationMinutes: 50,
    type: 'pdf_session',
    notes: 'قراءة الملف وكتابة التظليلات بالاستوديو',
    rating: 4
  },
  {
    id: 'log-3',
    subjectId: 104,
    subjectName: 'علم التشريح والوظائف (Anatomy & Physiology)',
    lectureTitle: 'Lec 1 - Cardiac Electrophysiology',
    date: new Date().toISOString(),
    durationMinutes: 60,
    type: 'manual',
    notes: 'مذاكرة متعمقة لمخطط كهربية القلب ECG',
    rating: 5
  }
];

export const INITIAL_FLASHCARDS: Flashcard[] = [
  {
    id: 1,
    subjectId: 101,
    question: 'ما هو الدواء المفضل (Drug of Choice) في علاج الصدمة التأقية (Anaphylactic Shock)؟',
    answer: 'الأدرينالين (Epinephrine) بالحقن العضلي الفوري؛ لأنه يعاكس توسع الأوعية الدموية وتضيق القصبات الهوائية بفاعلية عبر مستقبلات ألفا وبيتا.',
    difficulty: 'easy',
    lastReviewed: new Date().toISOString()
  },
  {
    id: 2,
    subjectId: 101,
    question: 'ما هو الترياق المباشر لحالات التسمم بمثبطات الكولينستريز (Organophosphate Poisoning)؟',
    answer: 'الأتروبين (Atropine) لغلق المستقبلات المسكارينية، متبوعاً بـ Pralidoxime (2-PAM) لإعادة تنشيط إنزيم الأسيتيل كولينستريز قبل تقادمه (Aging).',
    difficulty: 'medium',
    lastReviewed: new Date().toISOString()
  },
  {
    id: 3,
    subjectId: 102,
    question: 'ما هو الإنزيم الرئيسي المحدد لمعدل سرعة مسار التحلل السكري (Rate-limiting enzyme of Glycolysis)؟',
    answer: 'Phosphofructokinase-1 (PFK-1)، ويتم تثبيطه بواسطة ATP و Citrate، بينما يُنشطه Fructose 2,6-bisphosphate و AMP.',
    difficulty: 'hard',
    lastReviewed: new Date().toISOString()
  },
  {
    id: 4,
    subjectId: 104,
    question: 'ماذا تمثل موجة P في تخطيط كهربية القلب (ECG)؟',
    answer: 'إزالة استقطاب الأذينين (Atrial Depolarization) الناتجة عن انتقال الشارة الكهربية من العقدة الجيبية الأذينية (SA Node).',
    difficulty: 'easy',
    lastReviewed: new Date().toISOString()
  }
];

export const INITIAL_QUIZZES: QuizQuestion[] = [
  {
    id: 1,
    subjectId: 101,
    question: 'أي من الأدوية التالية يعتبر حاصراً انتقائياً لمستقبلات بيتا-1 (Selective Beta-1 Blocker)؟',
    options: ['Propranolol', 'Metoprolol', 'Timolol', 'Carvedilol'],
    correctIndex: 1,
    explanation: 'Metoprolol (Atenolol أيضاً) انتقائي للقلب (Cardioselective Beta-1)، بعكس Propranolol غير الانتقائي.'
  },
  {
    id: 2,
    subjectId: 102,
    question: 'كم عدد جزيئات ATP الصافية الناتجة من أكسدة جزيء جلوكوز واحد في التحلل السكري اللاهوائي (Anaerobic)؟',
    options: ['2 ATP', '4 ATP', '32 ATP', '38 ATP'],
    correctIndex: 0,
    explanation: 'في الظروف اللاهوائية ينتهي التحلل السكري بإنتاج اللاكتات مع صافي ربح 2 ATP فقط.'
  },
  {
    id: 3,
    subjectId: 103,
    question: 'وفقاً لقانون ستوكس (Stokes Law)، لتقليل سرعة ترسيب الجسيمات في المعلقات يجب:',
    options: ['زيادة حجم الجسيمات', 'تقليل لزوجة وسط الانتشار', 'تقليل حجم الجسيمات أو زيادة اللزوجة', 'زيادة فرق الكثافة'],
    correctIndex: 2,
    explanation: 'سرعة الترسيب تتناسب طردياً مع مربع نصف قطر الجسيمات وعكسياً مع لزوجة الوسط.'
  }
];
