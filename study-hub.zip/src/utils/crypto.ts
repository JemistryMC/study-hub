// Production Web Crypto PBKDF2 & SHA-256 for Exo Academic Platform

export async function hashPasswordSHA256(password: string): Promise<string> {
  const enc = new TextEncoder();
  const data = enc.encode(password);
  const hashBuf = await crypto.subtle.digest('SHA-256', data);
  const hashArr = Array.from(new Uint8Array(hashBuf));
  return hashArr.map(b => b.toString(16).padStart(2, '0')).join('');
}

export async function deriveSecurePBKDF2Hash(password: string, saltHex?: string, iterations = 100000): Promise<{ hash: string; salt: string }> {
  const enc = new TextEncoder();
  let saltBytes: Uint8Array;
  if (saltHex) {
    const pairs = saltHex.match(/.{1,2}/g) || [];
    saltBytes = new Uint8Array(pairs.map(byte => parseInt(byte, 16)));
  } else {
    saltBytes = new Uint8Array(16);
    crypto.getRandomValues(saltBytes as any);
  }

  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveBits']
  );

  const derivedBits = await crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: saltBytes as unknown as BufferSource,
      iterations,
      hash: 'SHA-256'
    },
    keyMaterial,
    256
  );

  const hashHex = Array.from(new Uint8Array(derivedBits))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
  const saltOutHex = Array.from(saltBytes)
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');

  return { hash: `pbkdf2:${iterations}:${saltOutHex}:${hashHex}`, salt: saltOutHex };
}

export async function verifyAndUpgradePassword(plainPassword: string, storedHash: string): Promise<{ valid: boolean; upgradedHash?: string }> {
  if (!storedHash) return { valid: false };

  // Format: pbkdf2:<iterations>:<salt>:<hash>
  if (storedHash.startsWith('pbkdf2:')) {
    const parts = storedHash.split(':');
    if (parts.length === 4) {
      const iters = parseInt(parts[1], 10) || 100000;
      const salt = parts[2];
      const expectedHash = parts[3];
      const result = await deriveSecurePBKDF2Hash(plainPassword, salt, iters);
      const computedHash = result.hash.split(':')[3];
      return { valid: computedHash === expectedHash };
    }
  }

  // Legacy SHA-256 check
  const sha = await hashPasswordSHA256(plainPassword);
  if (sha === storedHash) {
    // Automatically upgrade to PBKDF2
    const upgraded = await deriveSecurePBKDF2Hash(plainPassword);
    return { valid: true, upgradedHash: upgraded.hash };
  }

  return { valid: false };
}
